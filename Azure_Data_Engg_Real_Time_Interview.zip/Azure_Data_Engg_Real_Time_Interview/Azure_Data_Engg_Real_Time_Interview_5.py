# Databricks notebook source
# MAGIC %md
# MAGIC ##### It contain question from 61 to 94 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 61- Write a Python program to convert a list of characters into a string?

# COMMAND ----------

list1 = ['a', 'b', 'c', 'd']

string1 = ''.join(list1)

print("The string is:", string1)


# COMMAND ----------

# SOLUTION 2 Using for loop
list1 = ['a', 'b', 'c', 'd']
string1 = ''
for i in list1:
    string1 = string1 +i
print(list1)
print(string1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 62- Write a Python program to find the index of an item in a specified list?

# COMMAND ----------

num =[10, 30, 4, -6]
print(num.index(30))
print(num.index(4))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 63- Write a Python program to get the frequency of elements in a list?

# COMMAND ----------

from collections import Counter
my_list = [10,10,10,10,20,20,20,20,40,40,50,50,30]
result = Counter(my_list)
print(result)

# COMMAND ----------

import collections
my_list = [10,10,10,10,20,20,20,20,40,40,50,50,30]
result = collections.Counter(my_list)
print(result)

# COMMAND ----------

my_list = [10, 10, 10, 10, 20, 20, 20, 20, 40, 40, 50, 50, 30]

dicti = {}

# Count the frequency of elements
for i in my_list:
    if i in dicti:
        dicti[i] += 1
    else:
        dicti[i] = 1

# Print the dicti
print(dicti)


# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 64 Write a Python program to find common items in two lists?

# COMMAND ----------

color1 = "Red", "Green", "Orange", "White"
color2 = "Black", "Green", "White", "Pink"
print(set(color1) & set(color2))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 65- Write a Python program to sort (ascending and descending) a dictionary by value?
# MAGIC

# COMMAND ----------

d = {1: 2, 3: 4, 4: 3, 2: 1, 0: 0}

ascending = sorted(d.items(), key=lambda x: x[1])
descending = sorted(d.items(), key=lambda x: x[1], reverse=True)

print("The dictionary sorted by value in ascending order is:", dict(ascending))
print("The dictionary sorted by value in descending order is:", dict(descending))

#d.items() (a view object that provides access to the dictionary's key-value pairs) based on the values. We use a lambda function as the key parameter to specify that we want to sort the dictionary by its values (item[1]). For ascending order, we don't need to specify the reverse parameter (it is False by default). For descending order, we set reverse=True.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 66- Write a Python program to add a key to a dictionary?

# COMMAND ----------

# Using update() method
d = {0:10, 1:20}
d.update({2:30})
print(d)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 67-  Write a Python script to concatenate the following dictionaries to create a new one?

# COMMAND ----------

# Using update method() update() method to add the key-value pairs one by one to the new dictionary
dic1 = {1: 10, 2: 20}
dic2 = {3: 30, 4: 40}
dic3 = {5: 50, 6: 60}

# Create a new dictionary and update it with the contents of dic1, dic2, and dic3
concatenated_dict = {}
concatenated_dict.update(dic1)
concatenated_dict.update(dic2)
concatenated_dict.update(dic3)

print("Concatenated Dictionary (Using update()):", concatenated_dict)

# COMMAND ----------

# SOLUTION 2 
dic1 = {1:10, 2:20}
dic2 = {3:30, 4:40}
dic3 = {5:50, 6:60}
dic4 = {}
for d in (dic1, dic2, dic3):
    dic4.update(d)
print(dic4)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 68-  Write a Python program to iterate over dictionaries using for loops?

# COMMAND ----------

d = {'x': 10, 'y': 20, 'z': 30} 
for dict_key, dict_value in d.items():
    print(dict_key,'->',dict_value)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 69-Write a Python script to merge two Python dictionaries?

# COMMAND ----------

d1 = {'a': 100, 'b': 200}
d2 = {'x': 300, 'y': 200}
d3 = d1.copy()
d3.update(d2)
print(d3)

#we first define two dictionaries d1 and d2. Then we create a new dictionary d3 by copying the key-value pairs from d1. We then use the update() method to add the key-value pairs from d2 to d3

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 70-Write a Python program to map two lists into a dictionary?

# COMMAND ----------

keys = ['red', 'green', 'blue']
values = ['#FF0000','#008000', '#0000FF']
myDict = dict(zip(keys, values))
print(myDict)

#We use the zip() function to combine the two lists into a list of tuples. 
# We then pass this list of tuples to the dict() constructor to create a dictionary.


# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 71- Write a Python program to add an item to a tuple? 

# COMMAND ----------

#create a tuple
tuplex = (4, 6, 2, 8, 3, 1) 
print(tuplex)

#tuples are immutable, so you can not add new elements
#using merge of tuples with the + operator you can add an element and it will create a new tuple
tuplex = tuplex + (9,)
print(tuplex)

#Note that we need to include a comma after the item to create a tuple with a single element.
#Concatenate the tuple with a single-element tuple

# COMMAND ----------

#SOLUTION 2 Convert the tuple to a list, append the item, then convert back to a tuple

tuplex = (4, 6, 2, 8, 3, 1)
lst = list(tuplex)          # Convert the tuple to a list to modify it
lst.append(5)               # Add the item to the list
tuplex = tuple(lst)         # Convert the list back to a tuple
print(tuplex)               #print output

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 72- Write a Python program to convert a tuple to a string?

# COMMAND ----------

tup = ('e', 'x', 'e', 'r', 'c', 'i', 's', 'e', 's')
str = ''.join(tup)
print(str)

#use the join() method to concatenate the elements of the tuple into a single string. 
# Note that we pass an empty string '' as the separator between the elements.

# COMMAND ----------

tup = ('e', 'x', 'e', 'r', 'c', 'i', 's', 'e', 's')
str1 = ''
for i in tup:
    str1 = str1 + i
print(str1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 73- Write a Python program to convert a tuple to a dictionary?

# COMMAND ----------

#create a tuple   -- conversion of tuple to dictionary is straight forward methods
tuplex = ((2, "w"),(3, "r"))
dic = dict(tuplex)
print(dic)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 74- Write a Python program to iterate over sets?

# COMMAND ----------

num_set = set([0, 1, 2, 3, 4, 5])       # Creating set() using number
for num in num_set:
    print(num)

char_set = set("Gaurav Kurhekar")       # Creating set using string
for char in char_set:
    print(char)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Questiton 75- Write a Python program to find the most common elements and their counts in a specified text?

# COMMAND ----------

from collections import Counter
s = 'adfdshfjhiuhaskfjdskjhfdahsfknsdajkh'
print(Counter(s).most_common(4))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 76- - Write a Python program to find the occurrences of the 10 most common words in a given text?

# COMMAND ----------

from collections import Counter
import re
text = """The Python Software Foundation (PSF) is a 501(c)(3) non-profit 
corporation that holds the intellectual property rights behind
the Python programming language. We manage the open source licensing 
for Python version 2.1 and later and own and protect the trademarks 
associated with Python. We also run the North American PyCon conference 
annually, support other Python conferences around the world, and 
fund Python related development with our grants program and by funding 
special projects."""
words = re.findall('\w+',text)
print(Counter(words).most_common(5))

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 77- Write a Python program to find those numbers which are divisible by 7 and multiples of 5, between 1500 and 2700 (both included)?

# COMMAND ----------

nl = []
for x in range(1500, 2701):
    if (x % 7 == 0) and (x % 5 == 0):
        nl.append(str(x))
print(','.join(nl))


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 78- Write a Python function to find the maximum of three numbers?

# COMMAND ----------

def find_max(a, b, c):
    if a > b and a > c:
        return a
    elif b > a and b > c:
        return b
    else:
        return c

print(find_max(1, 2, 3)) # Output: 3
print(find_max(4, 2, 3)) # Output: 4
print(find_max(1, 5, 3)) # Output: 5

#This function takes three arguments (a, b, and c) and returns the maximum of the three numbers. It does this by using a series of if and elif statements to compare each number to the other two. If a is greater than both b and c, it returns a. If b is greater than both a and c, it returns b. Otherwise, it returns c.

# COMMAND ----------

# SOLUTION 2 Using lambda
find_max = lambda a, b, c: max(a, b, c)

print(find_max(1, 2, 3)) # Output: 3
print(find_max(4, 3, 2)) # Output: 4
print(find_max(5, 5, 5)) # Output: 5

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 79- Write a Python function to sum all the numbers in a list?

# COMMAND ----------

def sum(numbers):
    total = 0
    for number in numbers:
        total += number
    return total

numbers = [1, 2, 3, 4, 5]
print(sum(numbers))     # OR print(sum(1,2,3,4,5)) 


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 80- Write a Python function to multiply all the numbers in a list?

# COMMAND ----------

def multiply(numbers):
    total = 1
    for i in numbers:
        total = total*i
    return total
numbers = [1,2,3,4,5]
print(multiply(numbers))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 81- Write a Python function to check whether a number falls within a given range?

# COMMAND ----------

def test_range(n):
    if n in range(3,9):
        print( " %s is in the range"%str(n))
    else :
        print("The number is outside the given range.")
test_range(5)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 82- Write a Python program using lambda function that adds two numbers?

# COMMAND ----------

add = lambda x, y: x + y
print(add(2, 3)) # Output: 5

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 83 -create a lambda function that multiplies argument x with argument y and prints the result.

# COMMAND ----------

mul = lambda x,y:x*y
print(mul(4,5))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 84- Write a Python program to sort a list of tuples using Lambda?

# COMMAND ----------

subject_marks = [('English', 88), ('Science', 90), ('Maths', 97), ('Social sciences', 82)]

# Sort the list of tuples based on the second element of each tuple (marks)
sorted_subject_marks = sorted(subject_marks, key=lambda x: x[1])

# Print the sorted list
print(sorted_subject_marks)

#key=lambda x: x[1]: The lambda function takes one argument x, which represents each tuple in the list. 
# The function returns the second element of the tuple x[1], which is the marks. 
# This lambda function will be used as the key to determine the sorting order.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 85- Find the length of a given string without using the len() function?

# COMMAND ----------

string = 'Gaurav'

# Method 1: Using a loop
count = 0
for char in string:
    count += 1

print("Length of the string:", count)


# COMMAND ----------

a = input('Enter the string: ')
count = 0
for char in a:
    count = count + 1
print('The number of characters is:', count)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 86- Write a program to make the first character as upper case and rest is lower?
# MAGIC * initcap - it is used in dataframe to capatilize the first letter
# MAGIC * title() - it is used in python to capatilize the first letter

# COMMAND ----------

a = 'hELLO gAUrav kURHEkar'
a = a.title()
print(a)

# The title() method capitalizes the first character of each word in the string and converts the rest of the characters to lowercase

# COMMAND ----------

a = 'hELLO gAUrav kURHEkar'

# Split the string into words
words = a.split()

# Capitalize the first character and convert the rest to lowercase for each word
capitalized_words = [word.capitalize() for word in words]

# Join the words back into a single string
result = ' '.join(capitalized_words)

print(result)


# COMMAND ----------

a = 'hELLO gAUrav kURHEkar'

# Split the string into words
words = a.split()
capitalized_words = []

for i in words:
    capitalized_words.append(i.capitalize())

result = ' '.join(capitalized_words)
print(result)


# COMMAND ----------

a = 'hELLO gAUrav kURHEkar'
r = ''
y = a.split()

for i in y:
    r = r + i[0].upper() + i[1:].lower() + ' '
print(r)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 87- Write simple program to reverse the list, L = [1, 2, 3, 4, 5]?

# COMMAND ----------

L = [1, 2, 3, 4, 5]
L.reverse()

print("Reversed List:", L)


# COMMAND ----------

L = [1, 2, 3, 4, 5]
rev = []
for i in range(len(L)-1,-1,-1):
    rev.append(L[i])
print(rev)

# # for i in range(len(L)-1, -1, -1): This is a for loop that iterates over the indices of the list L in reverse order. 
# The range function is used with three arguments: start (length of L - 1), stop (-1, exclusive), and step (-1). 
# This ensures that the loop iterates backward through the indices of L.

# COMMAND ----------

L = [1, 2, 3, 4, 5]
reversed_list = L[::-1]

print("Reversed List:", reversed_list)


# COMMAND ----------

L = [1, 2, 3, 4, 5]
rev = []
for i in L[::-1]:
        rev.append(i)
print(rev)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 88- Write a python program to make square of number, L1 = [1,2,3,4,5]

# COMMAND ----------

L1 = [1,2,3,4,5]
L2 = []
for i in L1:
    L2.append(i*i) # or i**2
print(L2)

# COMMAND ----------

L1 = [1, 2, 3, 4, 5]
squares = [x ** 2 for x in L1]
print(squares)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 89- Write a program to count the length of string?

# COMMAND ----------

a = 'Gaurav'

# Using len() function to get the length of the string
string_length = len(a)
print("Length of the string:", string_length)


# COMMAND ----------

a = 'Gaurav'
count = 0
for i in a:
    count = count + 1
print('count is:', count)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 90- Write a program to count the occurance of any character in a string?

# COMMAND ----------

a = 'Gaurav'

# Using count() method to count occurrences of a specific character
count_of_a = a.count('a')

print("Count of 'a' in the string:", count_of_a)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 91- write a Program in python to check if list is sorted or not, my_list = [1, 2, 3, 4, 5]?

# COMMAND ----------

my_list = [1, 2, 3, 4, 5]
if my_list == sorted(my_list):
    print("The list is sorted.")
else:
    print("The list is not sorted.")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 92- Write a program to separate odd and even number from list?

# COMMAND ----------

def odd_even(original):
    odd = []
    even = []

    for i in original:
        if i % 2 == 0:
            even.append(i)
        else:
            odd.append(i)

    return odd, even

original = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
odd, even = odd_even(original)

print("Original list:", original)
print("Odd numbers list:", odd)
print("Even numbers list:", even)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 93- Write a program to join two list?

# COMMAND ----------

L1 = [1,2,3,4]
L2= [5,6,7,8]
join_list = L1+ L2
print(join_list)

# COMMAND ----------

L1 = [1,2,3,4]
L2= [5,6,7,8]
L = []
for i in L1:
    L.append(i)
for j in L2:
    L.append(j)
print(L)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 94- How to merge two directories?

# COMMAND ----------

D1 = {'a': 1, 'b': 2}
D2 = {'c': 3, 'd': 4}

# Merge D2 into D1 using update() method
D1.update(D2)

# Display the merged dictionary
print("Merged dictionary:", D1)