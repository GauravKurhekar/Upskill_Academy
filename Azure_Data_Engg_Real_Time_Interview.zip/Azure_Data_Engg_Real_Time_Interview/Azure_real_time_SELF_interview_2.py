# Databricks notebook source
# MAGIC %md
# MAGIC ##### Question 31- Write SQL query to remove the duplicates across rows?
# MAGIC * 1- By using Case when method and distinct
# MAGIC * 2- By using CTE with case when and distinct
# MAGIC * 3- By using CTE with Row_Number() and delete method

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Sample table structure
# MAGIC drop table if exists CityDistances;
# MAGIC CREATE TABLE CityDistances (
# MAGIC     City1 VARCHAR(100),
# MAGIC     City2 VARCHAR(100),
# MAGIC     Distance INT
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records (including duplicates)
# MAGIC INSERT INTO CityDistances (City1, City2, Distance)
# MAGIC VALUES
# MAGIC     ('Bangalore', 'Chennai', 350),
# MAGIC     ('chennai', 'bangalore', 350),
# MAGIC     ('hyderabad', 'chennai', 450),
# MAGIC     ('hyderabad', 'bangalore', 500),
# MAGIC     ('bangalore', 'hyderabad', 500);
# MAGIC
# MAGIC select * from CityDistances;
# MAGIC

# COMMAND ----------

# MAGIC %sql -- 1- By using Case When method
# MAGIC select distinct
# MAGIC case when city1 < city2 then city1 else city2 end as city1,
# MAGIC case when city1 < city2 then city2 else city1 end as city2, distance
# MAGIC from CityDistances;
# MAGIC

# COMMAND ----------

# MAGIC %sql -- 1- By using CTE with Case When and distinct
# MAGIC
# MAGIC WITH CTE AS (
# MAGIC     SELECT DISTINCT
# MAGIC         (CASE WHEN City1 < City2 THEN City1 ELSE City2 END) AS CityA,
# MAGIC         (CASE WHEN City1 < City2 THEN City2 ELSE City1 END) AS CityB,
# MAGIC         Distance
# MAGIC     FROM CityDistances
# MAGIC )
# MAGIC SELECT CityA, CityB, Distance
# MAGIC FROM CTE;

# COMMAND ----------

# MAGIC %sql -- Using CTE with row_number and delete
# MAGIC WITH CTE AS (
# MAGIC   SELECT *, ROW_NUMBER() OVER (PARTITION BY City1, City2, Distance ORDER BY City1) AS RowNum
# MAGIC   FROM CityDistances
# MAGIC )
# MAGIC DELETE FROM CTE
# MAGIC WHERE RowNum > 1;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 32- input is lst= [ 1,2,3,4,5 ] -->desire output= [ 1,4,9,16,25 ] find square of each number?

# COMMAND ----------

lst = [1, 2, 3, 4, 5]
squared_lst = []

# Loop through the list and square each element
for i in lst:
    squared_lst.append(i**2)

print(squared_lst)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 33- input is lst= [ 1,2,3,4,5 ] -->desire output= [ 1,8,27,64,125 ] find cube of each number?

# COMMAND ----------

lst = [1, 2, 3, 4, 5]
cube_lst = []
for i in lst:
    cube_lst.append(i**3)
print(sq_lst)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 34- Write a query in python to perform addition of all numbers present in the list?

# COMMAND ----------

lst = [1, 2, 3, 4, 5]
total = 0

for num in lst:
    total += num

print("Sum of the numbers in the list:", total)

# COMMAND ----------

lst = [1, 2, 3, 4, 5]
addition_sum = sum(lst)
print(lst)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 35- We have .csv files having some records, write a dataframe 
# MAGIC * 1-to read the .csv files using pyspark,
# MAGIC * 2-remove the delimiter from that file,
# MAGIC * 3-then separate the text using comma(,) separator,
# MAGIC * 4-make third letter of each word into as Upper letter,
# MAGIC * 5-save this dataframe,
# MAGIC * 6-finally display or show this dataframe.

# COMMAND ----------

from pyspark.sql.functions import col, udf
from pyspark.sql.types import StringType

# Step 2: Read the CSV file
df = spark.read.csv("your_csv_file.csv", header=True)  # Assuming header is present

# No need to remove delimiter if delimiter is a comma by default
# Step 3: Remove the delimiter, (assuming the delimiter is ",")
df = df.withColumn("text", udf(lambda s: s.replace(",", ""), StringType())(col("text")))

# Step 4: Separate the text using comma separator and make the third letter of each word uppercase
def capitalize_third_letter(word):
    if len(word) >= 3:
        return word[:2] + word[2].upper() + word[3:]
    else:
        return word

capitalize_third_letter_udf = udf(capitalize_third_letter, StringType())

# Apply the UDF to each column
for column in df.columns:
    df = df.withColumn(column, capitalize_third_letter_udf(col(column)))

# Step 5: Save the modified DataFrame
df.write.mode('overwrite').csv("output_directory")

# Step 6: Show the DataFrame
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 36- How to write partition in RDD?
# MAGIC * 1-repartition(): This method shuffles the data across a specified number of partitions.
# MAGIC * 2-partitionBy(): This method is used to partition a PairRDD by a key. It's commonly used with PairRDDs (RDDs of key-value pairs).

# COMMAND ----------

# Create an RDD
rdd = sc.parallelize(range(1000))

# Repartition the RDD into 10 partitions
rdd = rdd.repartition(10)

# COMMAND ----------

# Create a PairRDD
pair_rdd = sc.parallelize([(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd'), (5, 'e')])

# Partition the PairRDD by the key modulo 3
partitioned_rdd = pair_rdd.partitionBy(3)

# COMMAND ----------

file_path = "/path/to/your/file.csv"
df = spark.read.format('csv').options(inferSchema=True, header=True).load("file_path")

OR

file_path = "/path/to/your/file.csv"
df = spark.read.options(inferSchema=True, header=True).csv(file_path)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 37- We have a below list, write a code in pyspark to find distinct value?
# MAGIC *	1-by using set and 
# MAGIC * 2-by using for loop?

# COMMAND ----------

# By using set operator
lst = ['a', 'b', 'c', 'd', 'd', 'e', 'e', 'f', 'a']
new_lst = list(set(lst))
print(new_lst)


# COMMAND ----------

# By using loop but it will not show distinct value
lst = ['a', 'b', 'c', 'd', 'd', 'e', 'e', 'f', 'a']
new_lst = []
for i in lst:
    new_lst.append(i)
print(new_lst)

# COMMAND ----------

# By Initialize an empty set, Note- set does not support append, it wil support .add
lst = ['a', 'b', 'c', 'd', 'd', 'e', 'e', 'f', 'a']

# Initialize an empty set to store distinct values
distinct_values = set()

# Iterate through the list and add each element to the set
for i in lst:
    distinct_values.add(i)

# Convert the set back to a list
distinct_list = list(distinct_values)

# Print the distinct values
print("Distinct values:", distinct_list)


# COMMAND ----------

# by using for and if statement
lst = ['a', 'b', 'c', 'd', 'd', 'e', 'e', 'f', 'a']
distinct_values = []

for i in lst:
    if i not in distinct_values:
        distinct_values.append(i)

print(distinct_values)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 38- Find the distinct count from below table?
# MAGIC * -- 1- by using distinct function
# MAGIC * -- 2 by using count function

# COMMAND ----------

# MAGIC %sql
# MAGIC create table TableAA (value int);
# MAGIC
# MAGIC INSERT INTO TableAA (Value)
# MAGIC VALUES (1), (1), (1), (2), (2), (3), (3), (3), (3), (4), (4);
# MAGIC
# MAGIC select * from TableAA

# COMMAND ----------

# MAGIC %sql   -- 1- by using distinct function
# MAGIC select distinct value from tableAA

# COMMAND ----------

# MAGIC %sql -- 2 by using count function
# MAGIC select value, count(*) as distinct_value
# MAGIC from TableAA
# MAGIC group by value
# MAGIC having count(*)>=1

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 39- We have a table  having two columns date and flag, find the records where 1 and 1 flags occurs consecutively two times?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create TableDate_Flag table
# MAGIC CREATE TABLE Date_Flag (
# MAGIC     Date INT,
# MAGIC     Flag INT
# MAGIC );
# MAGIC -- Insert records into the TableDate_Flag table
# MAGIC INSERT INTO Date_Flag (Date, Flag)
# MAGIC VALUES 
# MAGIC     (1, 1),
# MAGIC     (2, 1),
# MAGIC     (3, 0),
# MAGIC     (4, 1),
# MAGIC     (5, 1),
# MAGIC     (6, 0),
# MAGIC     (7, 0),
# MAGIC     (8, 0),
# MAGIC     (9, 0),
# MAGIC     (10,1);
# MAGIC
# MAGIC select * from Date_Flag;

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH ConsecutiveFlags AS (
# MAGIC     SELECT
# MAGIC         date,
# MAGIC         flag,
# MAGIC         LAG(flag) OVER (ORDER BY date) AS prev_flag
# MAGIC     FROM Date_Flag
# MAGIC )
# MAGIC SELECT
# MAGIC     date,
# MAGIC     flag
# MAGIC FROM ConsecutiveFlags
# MAGIC WHERE flag = 1 AND prev_flag = 1;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 40- Write a query in Pyspark to find avg salary for each department?

# COMMAND ----------

from pyspark.sql.functions import avg
# Sample data
data = [(1, 20000, 1),
        (2, 50000, 2),
        (3, 60000, 3),
        (4, 70000, 1),
        (5, 10000, 2),
        (6, 35000, 3),
        (7, 60000, 1),
        (8, 85000, 2),
        (9, 11000, 3)]

# Define schema
schema = ["ID", "Salary", "Dept"]

# Create DataFrame
df = spark.createDataFrame(data, schema)
df.show()
# Calculate average salary by department
avg_salary_by_dept = df.groupBy("Dept").agg(avg("Salary").alias("AvgSalary"))

# Show results
avg_salary_by_dept.show()


# COMMAND ----------

# MAGIC %sql -- Method 2- by using SQL
# MAGIC df.createOrReplaceTempView('new')
# MAGIC select * from new
# MAGIC SELECT dept, AVG(salary) AS avg_salary
# MAGIC FROM new
# MAGIC GROUP BY dept;

# COMMAND ----------

# MAGIC %md
# MAGIC #### Question 41- Write a query in SQL to find avg salary for each department?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create table
# MAGIC CREATE TABLE EmployeeSal (
# MAGIC     ID INT,
# MAGIC     Salary INT,
# MAGIC     Dept INT
# MAGIC );
# MAGIC
# MAGIC -- Insert records
# MAGIC INSERT INTO EmployeeSal (ID, Salary, Dept) VALUES
# MAGIC (1, 20000, 1),
# MAGIC (2, 50000, 2),
# MAGIC (3, 60000, 3),
# MAGIC (4, 70000, 1),
# MAGIC (5, 10000, 2),
# MAGIC (6, 35000, 3),
# MAGIC (7, 60000, 1),
# MAGIC (8, 85000, 2),
# MAGIC (9, 11000, 3);
# MAGIC select * from EmployeeSal

# COMMAND ----------

# MAGIC %sql
# MAGIC --group by dept, avg(sal)
# MAGIC -- Query for average salary by department
# MAGIC
# MAGIC SELECT Dept, AVG(Salary) AS AvgSalary
# MAGIC FROM EmployeeSal
# MAGIC GROUP BY Dept;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 42- We have 4 teams namely India, Australia, Newzeland,Shrilanka, every team is playing with other team for example India is playing with Australia, Newzeland,Shrilanka and so on, Write a query in sql to find match list against every team and filter out that India is not playing with India itself?
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Cricket_teams12 (
# MAGIC     team_name VARCHAR(255)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO Cricket_teams12 (team_name) VALUES ('India'), ('Australia'), ('Newzeland'), ('Shrilanka');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Cricket_teams12

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC t1.team_name as team1, 
# MAGIC t2.team_name as team2
# MAGIC from Cricket_teams12 t1
# MAGIC join Cricket_teams12 t2
# MAGIC on
# MAGIC t1.team_name != t2.team_name    --- t1.team_name <> t2.team_name
# MAGIC order by team1, team2

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     t1.team_name AS Team1,
# MAGIC     t2.team_name AS Team2
# MAGIC FROM 
# MAGIC     Cricket_teams12 t1
# MAGIC JOIN 
# MAGIC     Cricket_teams12 t2 ON t1.team_name <> t2.team_name;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 43- We have 5 columns in pyspark dataframe having some data -ID, First_Name, Last_Name	Birth	and Death, write a query in pyspark to concat users firstname and last name and find the difference between birth and death date?

# COMMAND ----------

from pyspark.sql.functions import concat, datediff, to_date

# Sample data
data = [
    (1, "Arthur", "Morgen", "12-October-1812", "27-July-1841"),
    (2, "John", "Marston", "23-August-1819", "11-November-1853"),
    (3, "Dutch", "Van Der Lin", "10-January-1799", "08-September-1851"),
    (4, "Micah", "Bell", "02-November-1812", "22-November-1848"),
    (5, "Hosea", "Matthews", "29-October-1796", "20-July-1836")
]

# Define schema
schema = ["ID", "First_Name", "Last_Name", "Birth", "Death"]

# Create DataFrame
df = spark.createDataFrame(data, schema)
df.show()

# COMMAND ----------


df = df.withColumn("Life_Span_Day", datediff("Death", "Birth"))                     # Method1- find difference in Days
df = df.withColumn("Life_Span_Months", floor(months_between("Death", "Birth")))     # Method2- find difference in Months
df = df.withColumn("Life_Span_Year", floor(datediff("Death", "Birth") / 365))       # Method3- find difference in Years

# COMMAND ----------

# Method 1- use datediff("Death", "Birth")) to find the difference, but it shows difference in day

from pyspark.sql.functions import concat, datediff, to_date

# Concatenate first name and last name
df = df.withColumn("Full_Name", concat("First_Name", "Last_Name"))

# Convert Birth and Death columns to date type
df = df.withColumn("Birth", to_date("Birth", "dd-MMMM-yyyy")) \
       .withColumn("Death", to_date("Death", "dd-MMMM-yyyy"))

# Calculate the difference between birth and death
df = df.withColumn("Life_Span", datediff("Death", "Birth"))

# Show results
df.select("ID", "Full_Name", "Life_Span").show()

# COMMAND ----------

# Method 2- use floor(datediff("Death", "Birth") / 365)) to find the difference in years
floor(datediff("Death", "Birth") / 365) calculates the difference between death and birth dates in years.
* The floor function is used to round down the result to the nearest whole number.

# COMMAND ----------

from pyspark.sql.functions import concat, datediff, expr, to_date, floor

# Calculate the difference between birth and death in years
df = df.withColumn("Life_Span", floor(datediff("Death", "Birth") / 365))
df.show()

# COMMAND ----------

# Method 3- Use year function to find the difference in years

# Extract year from birth and death dates
df = df.withColumn("Birth_Year", year("Birth")) \
       .withColumn("Death_Year", year("Death"))

# Calculate the difference between death and birth years
df = df.withColumn("Life_Span", col("Death_Year") - col("Birth_Year"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 44- Write a query in SQL to concat users firstname and last name and find the difference between birth and death date?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create table
# MAGIC CREATE TABLE Person1 (
# MAGIC     ID INT,
# MAGIC     First_Name VARCHAR(50),
# MAGIC     Last_Name VARCHAR(50),
# MAGIC     Birth DATE,
# MAGIC     Death DATE
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records
# MAGIC INSERT INTO Person1 (ID, First_Name, Last_Name, Birth, Death) VALUES
# MAGIC (1, 'Arthur', 'Morgen', '1812-10-12', '1841-07-27'),
# MAGIC (2, 'John', 'Marston', '1819-08-23', '1853-11-11'),
# MAGIC (3, 'Dutch', 'Van Der Lin', '1799-01-10', '1851-09-08'),
# MAGIC (4, 'Micah', 'Bell', '1812-11-02', '1848-11-22'),
# MAGIC (5, 'Hosea', 'Matthews', '1796-10-29', '1836-07-20');
# MAGIC select * from Person1;

# COMMAND ----------

# Method 1- DATEDIFF(YEAR, Birth, Death) to find the difference in year
# Method 2- DATEDIFF(Month, Birth, Death) to find the difference in Month
# Method 3- DATEDIFF(DAY, Birth, Death) to find the difference in Day

# COMMAND ----------

# MAGIC %sql --Method 1- DATEDIFF(YEAR, Birth, Death) to find the difference in year
# MAGIC -- Query to concatenate first name and last name and find the difference between birth and death dates
# MAGIC SELECT 
# MAGIC     ID,
# MAGIC     CONCAT(First_Name, ' ', Last_Name) AS Full_Name,
# MAGIC     DATEDIFF(YEAR, Birth, Death) AS Life_Span
# MAGIC FROM 
# MAGIC     Person1;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 45- Write a pyspark code in dataframe to find the employee whose salary is greater than 60000? 

# COMMAND ----------

# Sample data
data = [
    (1, "Alice", "HR", 55000),
    (2, "Bob", "IT", 70000),
    (3, "Charlie", "Finance", 60000),
    (4, "David", "HR", 65000),
    (5, "Eve", "IT", 75000),
    (6, "Frank", "Finance", 58000)
]

# Define schema
schema = ["EId", "EName", "Department", "Salary"]

# Create DataFrame
df = spark.createDataFrame(data, schema)
df.show()
# Find employees whose salary is greater than 60000
result = df.filter(df["Salary"] > 60000)

# Show results
result.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 46- Write a code in SQL to find the employee whose salary is greater than 60000? 

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create Employee table
# MAGIC CREATE TABLE Employyy (
# MAGIC     EId INT,
# MAGIC     EName VARCHAR(50),
# MAGIC     Department VARCHAR(50),
# MAGIC     Salary DECIMAL(10, 2)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records
# MAGIC INSERT INTO Employyy (EId, EName, Department, Salary) VALUES
# MAGIC (1, 'Alice', 'HR', 55000),
# MAGIC (2, 'Bob', 'IT', 70000),
# MAGIC (3, 'Charlie', 'Finance', 60000),
# MAGIC (4, 'David', 'HR', 65000),
# MAGIC (5, 'Eve', 'IT', 75000),
# MAGIC (6, 'Frank', 'Finance', 58000);
# MAGIC select * from Employyy;
# MAGIC -- Query to find employees whose salary is greater than 60000
# MAGIC select * from Employyy where Salary>60000;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 47-We have two tables Emp123 having three columns Eid, EName and Dept and Salary123 columns having Eid and Salary, write a query in pyspark dataframe to find the Employes whose salary >60000?

# COMMAND ----------

# Sample data for Emp123 and Salary123 tables
emp_data = [
    (1, "Alice", "HR"),
    (2, "Bob", "IT"),
    (3, "Charlie", "Finance"),
    (4, "David", "HR"),
    (5, "Eve", "IT"),
    (6, "Frank", "Finance")
]

salary_data = [
    (1, 55000),
    (2, 70000),
    (3, 60000),
    (4, 65000),
    (5, 75000),
    (6, 58000)
]

# Define schema for Emp123 and Salary123 tables
emp_schema = ["Eid", "EName", "Dept"]
salary_schema = ["Eid", "Salary"]

# Create DataFrame for Emp123 and Salary123 tables
emp_df = spark.createDataFrame(emp_data, emp_schema)
salary_df = spark.createDataFrame(salary_data, salary_schema)

emp_df.show()
salary_df.show()
# Perform inner join on Eid column
joined_df = emp_df.join(salary_df, emp_df["Eid"] == salary_df["Eid"], "inner")

# Filter employees whose salary > 60000
result = joined_df.filter(joined_df["Salary"] > 60000)

# Show results
result.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 48-Write a query in SQL from two tables to find the Employes whose salary >60000?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create Emp123 table
# MAGIC CREATE TABLE Emp123 (
# MAGIC     Eid INT,
# MAGIC     EName VARCHAR(50),
# MAGIC     Dept VARCHAR(50)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into Emp123 table
# MAGIC INSERT INTO Emp123 (Eid, EName, Dept) VALUES
# MAGIC (1, 'Alice', 'HR'),
# MAGIC (2, 'Bob', 'IT'),
# MAGIC (3, 'Charlie', 'Finance'),
# MAGIC (4, 'David', 'HR'),
# MAGIC (5, 'Eve', 'IT'),
# MAGIC (6, 'Frank', 'Finance');
# MAGIC
# MAGIC -- Create Salary123 table
# MAGIC CREATE TABLE Salary123 (
# MAGIC     Eid INT,
# MAGIC     Salary DECIMAL(10, 2)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into Salary123 table
# MAGIC INSERT INTO Salary123 (Eid, Salary) VALUES
# MAGIC (1, 55000),
# MAGIC (2, 70000),
# MAGIC (3, 60000),
# MAGIC (4, 65000),
# MAGIC (5, 75000),
# MAGIC (6, 58000);
# MAGIC
# MAGIC select * from Emp123;
# MAGIC select * from Salary123;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to find employees whose salary is greater than 60000
# MAGIC SELECT e.Eid, e.EName, e.Dept, s.Salary
# MAGIC FROM Emp123 e
# MAGIC JOIN Salary123 s ON e.Eid = s.Eid
# MAGIC WHERE s.Salary > 60000;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Q49- Write a program in python that if employee salary>60000 then add bonus amount = 0.5, if employee salary<60000 then add bonus amount = 1.5

# COMMAND ----------

def calculate_bonus(salary):
    if salary>60000:
        return salary + (0.5 * salary)
    else:
        return salary + (1.5 * salary)

salary = float(input('enter salary'))
print(calculate_bonus(salary))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question Q50- Write a Pyspark in python that if employee salary>60000 then add bonus amount = 0.5, if employee salary<60000 then add bonus amount = 1.5

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import when, col

# Create a Spark session
spark = SparkSession.builder.appName("EmployeeBonus").getOrCreate()

# Sample data: Employee salaries
data = [
    ("John", 55000),
    ("Alice", 62000),
    ("Bob", 58000),
    ("Eva", 70000)
]

# Create a DataFrame from the sample data
columns = ["employee_name", "salary"]
df = spark.createDataFrame(data, columns)

# Calculate bonus based on salary
df_with_bonus = df.withColumn("bonus", 
                              when(col("salary") > 60000, 0.5 * col("salary"))
                              .otherwise(1.5 * col("salary")))

# Show the result
df_with_bonus.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Q51- Write a program in SQL that if employee salary>60000 then add bonus amount = 0.5, if employee salary<60000 then add bonus amount = 1.5

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     EmployeeName,
# MAGIC     Salary,
# MAGIC     CASE
# MAGIC       when salary > 60000 then salary + (salary * 0.5)
# MAGIC       else (salary + salary * 1.5)
# MAGIC       end as employee_salary from table_name
# MAGIC       

# COMMAND ----------

-- Example query to find duplicates in a single table
SELECT column1, column2, COUNT(*)
FROM your_table
GROUP BY column1, column2
HAVING COUNT(*) > 1;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 51- We have three tables namely Customers, Orders and Shipping, 
# MAGIC * 1-customers having columns- customer_id, firstName, lastName, age, country, 
# MAGIC * 2- Orders having column- OrderID, Item, Amount, CustomerID, and 
# MAGIC * 3- Shipping having column- ShippingID, Status, Customer, Write a query in sql server 
# MAGIC * 1-to find second higest amounts from orders? and 
# MAGIC * 2-based on customer_id, we require to find customer information?

# COMMAND ----------

with cte as(
    select OrderId, amount, row_number() over (order by amount) as second_hig_amt 
    from customer c join orders o
    on c.customerId = o.customerID
)
select customer_id from cte where orders =2

select * from customer where customer_id =1

# COMMAND ----------

# 1-to find second higest amounts from orders?
# Method 1-
WITH CTE AS (
    SELECT
        order_id,
        amount,
        ROW_NUMBER() OVER (ORDER BY amount DESC) AS RowNum
    FROM Orders
)
SELECT amount
FROM CTE
WHERE RowNum = 2;

# COMMAND ----------

# Method 2
SELECT MAX(Amount) AS SecondHighestAmount
FROM Orders
WHERE Amount < (
    SELECT MAX(Amount)
    FROM Orders
);

# COMMAND ----------

# 2-based on customer_id, we require to find customer information?
SELECT *
FROM Customers
WHERE customer_id = 1;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 52- Merge two dataframe having different schemas?

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType

# Create DataFrames from the given lists
df1_data = [('a',),('b',)]
df2_data = [('c',), ('d',), ('e',)]

# Define schema for both DataFrames
schema = StructType([StructField('value', StringType(), True)])

# Create DataFrames with defined schema
df1 = spark.createDataFrame(df1_data, schema)
df2 = spark.createDataFrame(df2_data, schema)

# Union the DataFrames using unionByName with allowMissingColumns=True
union_df = df1.unionByName(df2, allowMissingColumns=True)

# Show the result
union_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 53-Merge two Tables in SQL having different schemas?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create sample tables with different schemas
# MAGIC CREATE TABLE diff_schema1 (
# MAGIC     Name VARCHAR(50),
# MAGIC     Age INT
# MAGIC );
# MAGIC
# MAGIC CREATE TABLE diff_schema2 (
# MAGIC     FirstName VARCHAR(50),
# MAGIC     LastName VARCHAR(50),
# MAGIC     City VARCHAR(50)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data into Table1
# MAGIC INSERT INTO diff_schema1 (Name, Age)
# MAGIC VALUES ('John', 25),
# MAGIC        ('Alice', 30);
# MAGIC
# MAGIC -- Insert sample data into Table2
# MAGIC INSERT INTO diff_schema2 (FirstName, LastName, City)
# MAGIC VALUES ('Bob', 'Doe', 'New York'),
# MAGIC        ('Eve', 'Smith', 'San Francisco');
# MAGIC
# MAGIC select * from diff_schema1;
# MAGIC select * from diff_schema2;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT Name AS FirstName, NULL AS LastName, NULL AS City, Age
# MAGIC FROM diff_schema1
# MAGIC UNION ALL
# MAGIC SELECT FirstName, LastName, City, NULL AS Age
# MAGIC FROM diff_schema2;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Merge the tables using UNION ALL with NULL values to align the columns
# MAGIC SELECT Eno, EName, ESal, Gender FROM Emp
# MAGIC UNION ALL
# MAGIC SELECT Eno, EName, NULL AS ESal, Gender FROM Emp2;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 54- We have some data in python, data is in dictionary format having some records like first name, middle name, last name and i want to convert middle name as null to blank and convert this dictionary back to list? 

# COMMAND ----------

# Sample data in dictionary format
data = [
    {"first_name": "John", "middle_name": "Doe", "last_name": "Smith"},
    {"first_name": "Alice", "middle_name": None, "last_name": "Johnson"},
    {"first_name": "Bob", "middle_name": "David", "last_name": "Brown"}
]

# Convert middle name from None to blank
for record in data:
    if record["middle_name"] is None:
        record["middle_name"] = ""

# Convert the modified dictionary back to a list
modified_list = list(data)

# Print the modified list
print(modified_list)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 55-We have three tables-Emp : EMPID,DEPTID,SAL Write a query in sql to find third highest salary from each department?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Emp table: contains employee details including EMPID, DEPTID, and SAL
# MAGIC CREATE TABLE Empp (
# MAGIC     EMPID INT,
# MAGIC     DEPTID INT,
# MAGIC     SAL DECIMAL(10, 2)
# MAGIC );
# MAGIC
# MAGIC -- Sample records for Emp table
# MAGIC INSERT INTO Empp (EMPID, DEPTID, SAL)
# MAGIC VALUES 
# MAGIC     (1, 101, 50000.00),
# MAGIC     (2, 101, 60000.00),
# MAGIC     (3, 101, 45000.00),
# MAGIC     (4, 102, 70000.00),
# MAGIC     (5, 102, 55000.00),
# MAGIC     (6, 103, 80000.00),
# MAGIC     (7, 103, 65000.00);
# MAGIC
# MAGIC -- Dept table: contains department details including DEPTID and DEPNAME
# MAGIC CREATE TABLE Deptt (
# MAGIC     DEPTID INT,
# MAGIC     DEPNAME VARCHAR(50)
# MAGIC );
# MAGIC
# MAGIC -- Sample records for Dept table
# MAGIC INSERT INTO Deptt (DEPTID, DEPNAME)
# MAGIC VALUES 
# MAGIC     (101, 'HR'),
# MAGIC     (102, 'Finance'),
# MAGIC     (103, 'IT');
# MAGIC
# MAGIC -- Emp_Info table: contains employee information including EMPID, EMPNAME, DOJ, and MANAGERID
# MAGIC CREATE TABLE Emp_Infoo (
# MAGIC     EMPID INT,
# MAGIC     EMPNAME VARCHAR(50),
# MAGIC     DOJ DATE,
# MAGIC     MANAGERID INT
# MAGIC );
# MAGIC
# MAGIC -- Sample records for Emp_Info table
# MAGIC INSERT INTO Emp_Infoo (EMPID, EMPNAME, DOJ, MANAGERID)
# MAGIC VALUES 
# MAGIC     (1, 'John', '2022-01-01', NULL),
# MAGIC     (2, 'Alice', '2022-02-01', 1),
# MAGIC     (3, 'Bob', '2022-03-01', 1),
# MAGIC     (4, 'Diana', '2022-04-01', 3),
# MAGIC     (5, 'Eve', '2022-05-01', 3),
# MAGIC     (6, 'Frank', '2022-06-01', NULL),
# MAGIC     (7, 'Gina', '2022-07-01', 6);
# MAGIC
# MAGIC select * from Empp;
# MAGIC select * from Deptt;
# MAGIC select * from Emp_Infoo;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Empp;
# MAGIC select * from Deptt;
# MAGIC select * from Emp_Infoo;

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH RankedSalaries AS (
# MAGIC     SELECT E.EMPID,E.DEPTID,E.SAL,D.DEPNAME,
# MAGIC         ROW_NUMBER() OVER (PARTITION BY E.DEPTID ORDER BY E.SAL DESC) AS SalaryRank
# MAGIC     FROM 
# MAGIC         Empp E
# MAGIC     JOIN 
# MAGIC         Deptt D ON E.DEPTID = D.DEPTID
# MAGIC )
# MAGIC SELECT 
# MAGIC     R.DEPTID,R.DEPNAME,R.SAL AS ThirdHighestSalary
# MAGIC FROM 
# MAGIC     RankedSalaries R
# MAGIC WHERE 
# MAGIC     R.SalaryRank = 3;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 56-We have three tables-Emp : EMPID,DEPTID,SAL Write a query in sql to find third highest salary from each department? Out put should contain EMPNAME, DEPNAME, MANAGERName,SAL?

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH RankedSalaries AS (
# MAGIC     SELECT 
# MAGIC         E.EMPID,E.DEPTID,E.SAL,D.DEPNAME,EI.EMPNAME,EI.MANAGERID,
# MAGIC         ROW_NUMBER() OVER (PARTITION BY E.DEPTID ORDER BY E.SAL DESC) AS SalaryRank
# MAGIC     FROM 
# MAGIC         Empp E
# MAGIC     JOIN 
# MAGIC         DEPTT D ON E.DEPTID = D.DEPTID
# MAGIC     JOIN 
# MAGIC         EMP_INFOO EI ON E.EMPID = EI.EMPID
# MAGIC )
# MAGIC SELECT 
# MAGIC     RS.EMPNAME,RS.DEPNAME,M.EMPNAME AS MANAGERName,RS.SAL
# MAGIC FROM 
# MAGIC     RankedSalaries RS
# MAGIC JOIN 
# MAGIC     EMP_INFOO M ON RS.MANAGERID = M.EMPID
# MAGIC WHERE 
# MAGIC     RS.SalaryRank = 3;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 57- I have a table called Emp_table having Eid, Ename, Sal, DeptID, can you find DeptID wise total sal and show only those dept in output whose sal> 1000000?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Table structure for Emp_table
# MAGIC CREATE TABLE Emp_table11 (
# MAGIC     Eid INT,
# MAGIC     Ename VARCHAR(50),
# MAGIC     Sal DECIMAL(10, 2),
# MAGIC     DeptID INT
# MAGIC );
# MAGIC
# MAGIC -- Sample records for Emp_table
# MAGIC INSERT INTO Emp_table11 (Eid, Ename, Sal, DeptID)
# MAGIC VALUES 
# MAGIC     (1, 'John', 50000.00, 101),
# MAGIC     (2, 'Alice', 60000.00, 101),
# MAGIC     (3, 'Bob', 70000.00, 102),
# MAGIC     (4, 'Diana', 80000.00, 102),
# MAGIC     (5, 'Eve', 90000.00, 103),
# MAGIC     (6, 'Frank', 100000.00, 103),
# MAGIC     (7, 'Gina', 1100000.00, 104),
# MAGIC     (8, 'Harry', 1200000.00, 104),
# MAGIC     (9, 'Ivy', 1300000.00, 105),
# MAGIC     (10, 'Jack', 1400000.00, 105);
# MAGIC select * from Emp_table11;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DeptID, SUM(Sal) AS TotalSalary
# MAGIC FROM Emp_table11
# MAGIC GROUP BY DeptID
# MAGIC HAVING TotalSalary > 1000000;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 58- We have table having some columns including Email id column, write a dataframe in pyspark to filter the email id so that gov.in will not show?

# COMMAND ----------

from pyspark.sql.functions import col
# Sample DataFrame with email IDs
data = [("John", "john@example.com"),
        ("Alice", "alice@gov.in"),
        ("Bob", "bob123@yahoo.com")]

columns = ["Name", "Email"]

df = spark.createDataFrame(data, columns)
df.show()
# Filter out email IDs ending with "gov.in"
filtered_df = df.filter(~df["Email"].endswith("gov.in"))    #filtered_df = df.filter(~col("Email").like("%gov.in"))

# Show filtered DataFrame
filtered_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 59- We have table having some columns including Email id column, write a SQL query to filter the email id so that gov.in will not show?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create table
# MAGIC CREATE TABLE Employee_filter (
# MAGIC     EmpID INT,
# MAGIC     Name VARCHAR(100),
# MAGIC     Email VARCHAR(100)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data
# MAGIC INSERT INTO Employee_filter (EmpID, Name, Email)
# MAGIC VALUES 
# MAGIC     (1, 'John', 'john@example.com'),
# MAGIC     (2, 'Alice', 'alice@gov.in'),
# MAGIC     (3, 'Bob', 'bob123@yahoo.com');
# MAGIC select * from Employee_filter;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Employee_filter where Email not like '%gov.in'

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 60- I have table having current_cost which is average cost, I want to find prior cost,  post cost, average cost and rolling average in sql server?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create table
# MAGIC CREATE TABLE CostHistory (
# MAGIC     ID INT,
# MAGIC     Date DATE,
# MAGIC     Cost DECIMAL(10, 2)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data
# MAGIC INSERT INTO CostHistory (ID, Date, Cost)
# MAGIC VALUES 
# MAGIC     (1, '2023-01-01', 100.00),
# MAGIC     (2, '2023-01-02', 110.00),
# MAGIC     (3, '2023-01-03', 120.00),
# MAGIC     (4, '2023-01-04', 130.00),
# MAGIC     (5, '2023-01-05', 140.00),
# MAGIC     (6, '2023-01-06', 150.00),
# MAGIC     (7, '2023-01-07', 160.00),
# MAGIC     (8, '2023-01-08', 170.00),
# MAGIC     (9, '2023-01-09', 180.00),
# MAGIC     (10, '2023-01-10', 190.00);
# MAGIC
# MAGIC select * from CostHistory;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     id, cost,
# MAGIC     LAG(cost) OVER (ORDER BY id) AS prior_cost,
# MAGIC     LEAD(cost) OVER (ORDER BY id) AS post_cost,
# MAGIC     AVG(cost) OVER () AS average_cost,
# MAGIC     AVG(cost) OVER (ORDER BY id ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS rolling_average
# MAGIC FROM
# MAGIC     CostHistory;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 61- Write a query to find the minimum and maximum sequences for each group in SQL?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Table_Sequence (
# MAGIC     group_col VARCHAR(10),
# MAGIC     seq_col INT
# MAGIC );
# MAGIC
# MAGIC INSERT INTO Table_Sequence (group_col, seq_col) VALUES
# MAGIC ('A', 1),
# MAGIC ('A', 2),
# MAGIC ('A', 3),
# MAGIC ('A', 5),
# MAGIC ('A', 6),
# MAGIC ('A', 8),
# MAGIC ('A', 9),
# MAGIC ('B', 11),
# MAGIC ('C', 1),
# MAGIC ('C', 2),
# MAGIC ('C', 3);
# MAGIC select * from Table_Sequence;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     group_col AS GroupColumn,
# MAGIC     MIN(seq_col) AS MinSequence,
# MAGIC     MAX(seq_col) AS MaxSequence
# MAGIC FROM 
# MAGIC     Table_Sequence
# MAGIC GROUP BY 
# MAGIC     group_col;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 62- We have a table name called input_table having two columns -balance and dates with some below records. write a query in sql server to get three column in output- balance, startdate, enddate and output like 26000, 01-Jan-24, 02-Jan-24 then 30000, 03-Jan-24, 04-Jan-24?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE input_table (
# MAGIC     balance INT,
# MAGIC     dates DATE
# MAGIC );
# MAGIC
# MAGIC INSERT INTO input_table (balance, dates) VALUES
# MAGIC (26000, '2024-01-01'),
# MAGIC (26000, '2024-01-02'),
# MAGIC (30000, '2024-01-03'),
# MAGIC (30000, '2024-01-04');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT balance, MIN(dates) AS startdate, MAX(dates) AS enddate
# MAGIC FROM input_table
# MAGIC GROUP BY balance;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 63-We have file in csv format which is saved in some bucket in databricks, write the dataframe in pyspark to- 
# MAGIC * 1-read the file,
# MAGIC * 2-load it to landing zone with .parquet format, 
# MAGIC * 3-save it to a externaltable,
# MAGIC * 4-again read the files, 
# MAGIC * 5-do some nullcheck and 
# MAGIC * 6-do some duplicate check and 
# MAGIC * 7-write again into any process folder?

# COMMAND ----------

# 1- Read the CSV file
file_path = "dbfs:/filestore/file.csv"
df = spark.read.csv(file_path, header=True, inferSchema=True)

# 2-load it to landing zone with .parquet format
landing_zone_path = "/path/to/landing/zone"
df.write.parquet(landing_zone_path)

# 3-save it to a externaltable-
external_table_name = "my_external_table"
df.write.mode("overwrite").saveAsTable(external_table_name)

# 4-again read the files-
external_df = spark.table(external_table_name)

# 5-do some nullcheck and 
null_count = df.filter(df.isNull()).count()
print("Number of null values:", null_count)

# 6-do some duplicate check and 
duplicate_count = df.dropDuplicates()

# 7-write again into any process folder?
process_folder_path = "/path/to/process/folder"
external_df.write.parquet(process_folder_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 64- We have a table having columns- CUSTOMERID, ORDERID, ORDERDATE, write a query to retrieve top 3 most recent orders for each customer using PySpark dataframe?

# COMMAND ----------

w = Window.partitionBy('customerId').orderBy('orderid')
df = df.withColumn('top_three', row_number().over(w))
df1 = df.filter(df['top_three']<=3)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

# Sample data (replace with your actual data)
data = [
    (1, 101, "2022-01-01"),
    (1, 102, "2022-01-05"),
    (1, 103, "2022-01-10"),
    (1, 104, "2022-01-15"),
    (2, 201, "2022-02-01"),
    (2, 202, "2022-02-05")
]

# Create a DataFrame from the sample data
columns = ["CUSTOMERID", "ORDERID", "ORDERDATE"]
df = spark.createDataFrame(data, columns)

# Convert ORDERDATE to date type
df = df.withColumn("ORDERDATE", df["ORDERDATE"].cast("date"))

# Create a window specification partitioned by CUSTOMERID and ordered by ORDERDATE in descending order
window_spec = Window.partitionBy("CUSTOMERID").orderBy(df["ORDERDATE"].desc())

# Add a row number column to the DataFrame
df = df.withColumn("row_num", row_number().over(window_spec))

# Filter rows with row number <= 3
result_df = df.filter(df["row_num"] <= 3)

# Drop the row number column
result_df = result_df.drop("row_num")

# Show the result
result_df.show()