# Databricks notebook source
# MAGIC %md
# MAGIC ##### It contain question from 87 to 114

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 87- Write a pyspark code to extract data from .csv and create table on top on that and then save the table in parquet format?

# COMMAND ----------

from pyspark.sql import SparkSession

# Create a Spark session
spark = SparkSession.builder.appName("CSVtoParquet").getOrCreate()

# Read data from CSV file into a DataFrame
csv_path = "dbfs:/FileStore/tables/employee1.csv"
df = spark.read.csv(csv_path, header=True, inferSchema=True)

# Display the DataFrame
df.show()

# Register the DataFrame as a temporary table
df.createOrReplaceTempView("my_table")

# Save the table in Parquet format
parquet_output_path = "dbfs:/FileStore/tables/employee1/parquet_data"
spark.sql("SELECT * FROM my_table").write.parquet(parquet_output_path)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 94- We have three column in pyspark dataframe namely Name, Department and Salary- Read the dataframe, define the schema then filter out the employee name who is earning less than 20000, add new column called 'Bonus' and increase 10% salary of each employee and calculate the total salary after bonus, save the final result in parquet?

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1- Read the DataFrame:

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Define the schema
schema = StructType([
    StructField("Name", StringType(), True),
    StructField("Department", StringType(), True),
    StructField("Salary", IntegerType(), True)
])

# Read the DataFrame with the defined schema
df = spark.read.csv("dbfs:/FileStore/tables/EmployeeBonus.csv", header=True, schema=schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2- Filter Employees Earning Less than 20000:

# COMMAND ----------

df_filtered = df.filter(df["Salary"] < 20000)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3- Add a New Column 'Bonus' and Increase Salary:

# COMMAND ----------

# Add a new column 'Bonus' and increase 10% salary
df_bonus = df_filtered.withColumn("Bonus", df_filtered["Salary"] * 0.10).withColumn("TotalSalaryAfterBonus", df_filtered["Salary"] * 1.10)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4- Save the Final Result in Parquet:

# COMMAND ----------

# Save the result in Parquet format
df_bonus.write.parquet("dbfs:/FileStore/tables/EmployeeBonus.parquet", mode="overwrite")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 95- We have some name and last name in dataframe and some of the last name contain !$#@ symbol, write a program in pyspark to replace this character with empty space?

# COMMAND ----------

# MAGIC %md
# MAGIC ##### solve this by using regexp_replace method

# COMMAND ----------

from pyspark.sql.functions import regexp_replace

# Sample DataFrame with Name and LastName
data = [("John", "Doe$#@"),
        ("Alice", "Smith"),
        ("Bob", "Johnson$#@")]

columns = ["Name", "LastName"]

df = spark.createDataFrame(data, columns)

# Replace special characters in the 'LastName' column
df_cleaned = df.withColumn("LastName", regexp_replace("LastName", "[!@$#]", ""))

# Show the updated DataFrame
df_cleaned.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### # solve this by using when - otherwise method

# COMMAND ----------

# Replace special characters in the 'LastName' column using when-otherwise
df_cleaned = df.withColumn(
    "LastName",
    when(col("LastName").contains("!@$#"), regexp_replace(col("LastName"), "[!@$#]", ""))
    .otherwise(col("LastName"))

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE students (
# MAGIC   ID INT,
# MAGIC   Mark INT
# MAGIC );
# MAGIC
# MAGIC INSERT INTO students (ID, Mark) VALUES
# MAGIC (1, 85),
# MAGIC (1, 92),
# MAGIC (1, 78),
# MAGIC (1, 96),
# MAGIC (2, 88),
# MAGIC (2, 75),
# MAGIC (2, 90),
# MAGIC (2, 85),
# MAGIC (3, 95),
# MAGIC (3, 89),
# MAGIC (3, 93),
# MAGIC (3, 91);
# MAGIC select * from students;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 99- We have student table in sql, from student table based on ID find best of 3 marks using sql and average of that for best of three?

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH RankedMarks AS (
# MAGIC   SELECT
# MAGIC     ID,
# MAGIC     Mark,
# MAGIC     ROW_NUMBER() OVER (PARTITION BY ID ORDER BY Mark DESC) AS RowNum
# MAGIC   FROM
# MAGIC     students
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   ID,
# MAGIC   AVG(Mark) AS AverageOfBestThree
# MAGIC FROM
# MAGIC   RankedMarks
# MAGIC WHERE
# MAGIC   RowNum <= 3
# MAGIC GROUP BY
# MAGIC   ID;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 100- how to handle null in pyspark can you explain me with sample code with example?
# MAGIC Handling null values in PySpark can be done using various functions and methods provided by PySpark's DataFrame API
# MAGIC 1. Dropping Null Values:            df = df.dropna()
# MAGIC 2. Filling Null Values:             df = df.fillna({"Age": 0, "Score": -1})
# MAGIC 3. Replacing Null Values:           df = df.na.replace(None, {"Age": 0, "Score": -1})
# MAGIC 4. Handling Nulls in Expressions:   df = df.withColumn("Age", coalesce(df["Age"], 0))
# MAGIC 5. Conditional Replacement:         df = df.withColumn("Score", when(df["Score"].isNull(), 0).otherwise(df["Score"]))
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1- Dropping Null Values:
# MAGIC You can use the **dropna** method to remove rows containing null values.

# COMMAND ----------

# Sample DataFrame with null values
data = [("John", 25, None),
        ("Alice", None, 30),
        (None, 22, 35)]

columns = ["Name", "Age", "Score"]

df = spark.createDataFrame(data, columns)
display(df)
# Drop rows with any null values
df_no_null = df.dropna()

display(df_no_null)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2. Filling Null Values:
# MAGIC You can use the fillna method to fill null values with a specified default value.

# COMMAND ----------

# Fill null values with a default value
df_filled = df.fillna({"Age": 0, "Score": -1})

df_filled.show()


# COMMAND ----------

# MAGIC %md
# MAGIC #####  3. Replacing Null Values:
# MAGIC You can use the na.replace method to replace null values with a specified value.

# COMMAND ----------

# Replace null values with a specified value
df_replaced = df.na.replace(None, {"Age": 0, "Score": -1})

df_replaced.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4. Handling Nulls in Expressions:
# MAGIC You can use PySpark SQL functions to handle nulls within expressions.

# COMMAND ----------

from pyspark.sql.functions import coalesce

# Use coalesce to replace null values in a specific column
df_coalesce = df.withColumn("Age", coalesce(df["Age"], 0))

df_coalesce.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 5. Conditional Replacement:
# MAGIC You can use the when and otherwise functions for conditional replacement.

# COMMAND ----------

from pyspark.sql.functions import when

# Conditional replacement of null values
df_conditional = df.withColumn("Score", when(df["Score"].isNull(), 0).otherwise(df["Score"]))

df_conditional.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question- How to convert scd0 to scd1 in pyspark?
# MAGIC to convert from SCD0 (where no history is maintained) to SCD1 (which overwrites existing data).

# COMMAND ----------

# MAGIC %md
# MAGIC #####1- Understanding SCD1:
# MAGIC
# MAGIC In SCD1, we directly update the data in dimensions without preserving historical changes.
# MAGIC
# MAGIC It’s suitable when you don’t need to track historical context and only care about the current state.

# COMMAND ----------

# MAGIC %md
# MAGIC #####2- Implementation Steps:
# MAGIC
# MAGIC Assume you have a customer dimension table with attributes like customer_id, name, and address.
# MAGIC
# MAGIC When a new record is initiated in the operational database, it may have empty or null attributes.
# MAGIC
# MAGIC Once these attributes are filled in the operational databases, they need to be updated in the data warehouse.

# COMMAND ----------

# MAGIC %md
# MAGIC #####3- Example Code Snippet (using PySpark and Delta Lake):

# COMMAND ----------

# Read source data (e.g., from a parquet file)
source_df = spark.read.parquet("/path/to/source_data")

# Create a Delta table for the target (SCD1)
deltaTable = DeltaTable.forName(spark, "scdType1")

# Merge new data into the existing table
deltaTable.alias("original").merge(
    source_df.alias("updates"),
    "original.customer_id = updates.customer_id"
).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question- How to convert scd0 to scd2 in pyspark?
# MAGIC Converting from SCD0 (where no history is maintained) to SCD2 (which tracks historical changes) in PySpark involves several steps. Let’s dive into the process:

# COMMAND ----------

# MAGIC %md
# MAGIC #####1- Understanding SCD2:
# MAGIC
# MAGIC SCD2 stands for Slowly Changing Dimension Type 2.
# MAGIC -It handles changes in dimensions that are slow and unpredictable, such as customer information (e.g., mobile number, email, zip code).
# MAGIC
# MAGIC -In SCD2, a new record is inserted with the latest values, and previous records are marked as invalid.
# MAGIC
# MAGIC -To maintain validity, additional columns like **effective_date, expiration_date, and current_flag** are used.

# COMMAND ----------

# MAGIC %md
# MAGIC #####2- Implementation Steps:
# MAGIC
# MAGIC **Natural Key**: Identify the natural key column(s) (e.g., customer_id) in your dimension table.
# MAGIC
# MAGIC **Surrogate Key**: Create a surrogate key (e.g., sk_customer_id) to maintain a link between fact and dimension tables.
# MAGIC
# MAGIC Additional Columns:
# MAGIC
# MAGIC **1-effective_date**: Set to the current date when a new record is inserted.
# MAGIC
# MAGIC **2-expiration_date**: Set to a future date (e.g., ‘9999-12-31’) for new records.
# MAGIC
# MAGIC **3-current_flag**: Indicates whether the record is currently valid (True/False).

# COMMAND ----------

# MAGIC %md
# MAGIC #####4- Example Code Snippet:

# COMMAND ----------

# Define variables (you can also use a config file)
SOURCE_PATH = "/path/to/source_data"
DEST_PATH = "/path/to/destination_table"
key_list = ["customer_id"]  # Natural key column(s)
type2_cols = ["mobile_number", "email", "zip_code"]  # Columns for SCD2 handling

# Read source data
source_df = spark.read.parquet(SOURCE_PATH)

# Create a staging DataFrame for merge
df_initial = source_df.withColumn("is_current", lit(1))
df_initial = df_initial.withColumn("effective_date", current_date())
df_initial = df_initial.withColumn("expiration_date", lit("9999-12-31"))

# Save initial table as a Delta table
df_initial.write.format("delta").save(DEST_PATH)

# Merge new data into the existing table (SCD2 handling)
deltaTable = DeltaTable.forPath(spark, DEST_PATH)
deltaTable.alias("original").merge(
    source_df.alias("updates"),
    "original.customer_id = updates.customer_id"
).whenMatchedUpdate(
    set={
        "original.expiration_date": current_date(),
        "original.is_current": False
    }
).whenNotMatchedInsertAll().execute()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Explanation:
# MAGIC
# MAGIC The code snippet initializes a Delta table, creates a staging DataFrame, and performs a merge operation.
# MAGIC
# MAGIC For matched records, it updates the expiration date and sets the current flag to False.
# MAGIC
# MAGIC For new records, it inserts them with the current date as the effective date.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 101- How to convert scd0 to scd2 with simple example?
# MAGIC SCD0 (Slowly Changing Dimension Type 0) and SCD2 (Slowly Changing Dimension Type 2) are techniques used in data warehousing to manage changes to dimension data over time.
# MAGIC
# MAGIC SCD0: In SCD0, changes to data are not tracked, and the old data is simply overwritten with the new data.
# MAGIC
# MAGIC SCD2: In SCD2, historical changes to the data are preserved by creating new records for each change.
# MAGIC
# MAGIC Example Data:
# MAGIC Let's assume you have a DataFrame representing a simple dimension table with SCD0 changes:

# COMMAND ----------

from pyspark.sql import functions as F
# Sample DataFrame representing SCD0 changes
data = [("John", "Marketing", "2021-01-01"),
        ("John", "Sales", "2021-02-01"),
        ("Alice", "HR", "2021-01-01")]

columns = ["Name", "Department", "EffectiveDate"]

df_scd0 = spark.createDataFrame(data, columns)

df_scd0.show()


# COMMAND ----------

# MAGIC %md
# MAGIC Convert to SCD2:
# MAGIC Now, let's convert this SCD0 DataFrame to SCD2:

# COMMAND ----------

from pyspark.sql.window import Window

# Assume today's date for simplicity
current_date = "2023-11-22"

# Add a surrogate key and effective end date for each record
df_scd2 = df_scd0.withColumn("SurrogateKey", F.monotonically_increasing_id())
df_scd2 = df_scd2.withColumn("EffectiveEndDate", F.lead("EffectiveDate").over(Window.partitionBy("Name").orderBy("EffectiveDate")).cast("date"))

# If EffectiveEndDate is null, set it to the current date
df_scd2 = df_scd2.withColumn("EffectiveEndDate", F.coalesce("EffectiveEndDate", F.lit(current_date).cast("date")))

df_scd2.show()

# In this example, we use the monotonically_increasing_id() function to create a surrogate key, and the lead window function is used to determine the end date of the current record.

# The resulting df_scd2 DataFrame represents the SCD2 version of the dimension table:

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 102- How to convert scd0 to scd3 in pyspark with simple example?

# COMMAND ----------

SCD3 (Slowly Changing Dimension Type 3) is another technique used in data warehousing to manage changes to dimension data over time. In SCD3, instead of creating a new record for each change, the existing record is updated with the new data, and additional columns are added to store historical information.

# COMMAND ----------

from pyspark.sql import functions as F
# Sample DataFrame representing SCD0 changes
data = [("John", "Marketing", "2021-01-01"),
        ("John", "Sales", "2021-02-01"),
        ("Alice", "HR", "2021-01-01")]

columns = ["Name", "Department", "EffectiveDate"]

df_scd0 = spark.createDataFrame(data, columns)

df_scd0.show()


# COMMAND ----------

# MAGIC %md
# MAGIC Convert to SCD3:
# MAGIC Now, let's convert this SCD0 DataFrame to SCD3:

# COMMAND ----------

from pyspark.sql import Window

# Assume today's date for simplicity
current_date = "2023-11-22"

# Add version column
df_scd3 = df_scd0.withColumn("Version", F.row_number().over(Window.partitionBy("Name").orderBy("EffectiveDate")))

# Add effective end date for the current record
df_scd3 = df_scd3.withColumn("EffectiveEndDate", F.lead("EffectiveDate").over(Window.partitionBy("Name").orderBy("EffectiveDate")).cast("date"))

# If EffectiveEndDate is null, set it to the current date
df_scd3 = df_scd3.withColumn("EffectiveEndDate", F.coalesce("EffectiveEndDate", F.lit(current_date).cast("date")))

# Fill null values for EffectiveEndDate in the last record with a distant future date
df_scd3 = df_scd3.withColumn("EffectiveEndDate", F.when(F.col("Version") == F.max("Version").over(Window.partitionBy("Name")), F.lit("9999-12-31").cast("date")).otherwise(F.col("EffectiveEndDate")))

df_scd3.show()

# In this example, we use the row_number() function to add a version number to each record. The lead window function is used to determine the effective end date of the current record. We then fill null values for the effective end date in the last record with a distant future date.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 110- lst = [12,3,27,5,4,9,4] find the 3 numbers which will give 180 as multiplication of that 3 numbers in python?

# COMMAND ----------

# Example usage
lst = [12, 3, 27, 5, 4, 9, 4]
target = 180

def find_three_numbers(lst, target):
    for i in range(len(lst) - 2):                         # for i in range(len(lst)):
        for j in range(i + 1, len(lst) - 1):              # for j in range(i + 1, len(lst)):
            for k in range(j + 1, len(lst)):              # for k in range(j + 1, len(lst)):
                if lst[i] * lst[j] * lst[k] == target:
                    return [lst[i], lst[j], lst[k]]
    return None

result = find_three_numbers(lst, target)

if result:
    print(f"The three numbers are: {result}")
else:
    print("No three numbers found that multiply to 180.")


# COMMAND ----------

Function Definition:
def find_three_numbers(lst, target):
This line defines a function named find_three_numbers that takes two parameters: lst (a list of numbers) and target (the desired multiplication result).

First Loop (i Loop):
for i in range(len(lst) - 2):
This line initiates the first loop, iterating over the indices of the input list lst from 0 to len(lst) - 3. The loop variable i represents the index of the first number in the triplet.

Second Loop (j Loop):
for j in range(i + 1, len(lst) - 1):
This line initiates the second loop, iterating over the indices from i + 1 to len(lst) - 2. The loop variable j represents the index of the second number in the triplet. This ensures that the second number is always to the right of the first.

Third Loop (k Loop):
for k in range(j + 1, len(lst)):
This line initiates the third loop, iterating over the indices from j + 1 to the end of the list. The loop variable k represents the index of the third number in the triplet. This ensures that the third number is always to the right of the second.

Condition Check:
if lst[i] * lst[j] * lst[k] == target:
This line checks if the product of the numbers at indices i, j, and k in the list is equal to the target value. If it is, a triplet has been found that meets the condition.

Return Statement:
return [lst[i], lst[j], lst[k]]
If a triplet is found, this line returns a list containing the three numbers that multiply to the target value.

Default Return:
return None
If no triplet is found after exhausting all possible combinations in the loops, the function returns None.

# COMMAND ----------

# Given list of numbers
lst = [12, 3, 27, 5, 4, 9, 4]

# Initialize variables to store the three numbers
num1, num2, num3 = None, None, None

# Iterate through all combinations of three numbers
for i in range(len(lst)):
    for j in range(i + 1, len(lst)):
        for k in range(j + 1, len(lst)):
            if lst[i] * lst[j] * lst[k] == 180:
                num1, num2, num3 = lst[i], lst[j], lst[k]
                break

# Check if valid numbers were found
if num1 is not None:
    print(f"The three numbers are: {num1}, {num2}, {num3}")
else:
    print("No combination of three numbers gives a product of 180.")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 111- lst = [18,6,7,43,67,43,6] write a simple python program to insert and delete an element from list?

# COMMAND ----------

lst =  [18,6,7,43,67,43,6]

# Insert an element at index 2
lst.insert(2, 20)
print("List after inserting an element:", lst)

# Delete an element at index 4
del lst[2]
print("List after deleting an element:", lst)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 111- lst = [18,6,7,43,67,43,6] write a simple python program to insert and delete an element from list?

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Add an element to the list
# MAGIC ##### Adding an element to a list can be done in a number of ways:
# MAGIC ##### 1- list.insert(index, element): This method adds the element in the list at any index.
# MAGIC ##### 2- list.append(): This method adds the element at the end of the list.
# MAGIC ##### 3- list.extend(): This method adds more than one element to the list.

# COMMAND ----------

# 1- insert(index, element): This method adds the element in the list at any index.
# This function inserts an element at the position mentioned in its arguments. 
# It takes 2 arguments, position and element to be added at respective position.

# initializing list  
lis = [2, 1, 3, 5, 3, 8] 
  
# using insert() to insert 4 at 3rd pos 
lis.insert(3, 4) 
print(lis)

# COMMAND ----------

# MAGIC %md
# MAGIC 1- insert(index, element): This method adds the element in the list at any index.

# COMMAND ----------

c = [2,4,"vik",76]
c.insert(0,"python")
print(c)

# COMMAND ----------

# MAGIC %md
# MAGIC 2- list.append(): This method adds the element at the end of the list.

# COMMAND ----------

a = [25,"vinay",45,217]
a.append("rohit")
print(a)

# COMMAND ----------

# MAGIC %md
# MAGIC 3 - list.extend(): This method adds more than one element to the list.

# COMMAND ----------

b = [2,45,101]
b.extend(["sunny","sandeep","shashanka"])
print(b)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Remove an element from the list
# MAGIC ##### Removing an element from a list can be done in a number of ways:
# MAGIC
# MAGIC ##### 1- list.pop(): This method removes the last element from the list.
# MAGIC ##### 2- list.pop(index) If the index is mentioned, it removes the mentioned item from the list.
# MAGIC ##### 3- list.clear() This deletes all elements in the list. The list is then called an empty list.
# MAGIC ##### 4- remove() :- This function is used to delete the first occurrence of number mentioned in its arguments.
# MAGIC ##### 5- del[a : b] :- This method deletes all the elements in range starting from index ‘a’ till ‘b’ mentioned in arguments.
# MAGIC ##### 6- del[]:- This method deletes the elements from specific index

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1- list.pop(): This method removes the last element from the list.

# COMMAND ----------

d = [12,34,56,78,89,0]
d.pop()
print(d)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2- list.pop(index) If the index is mentioned, it removes the mentioned item from the list.

# COMMAND ----------

e = [2,4,'vik',76]
e.pop(2)
print(e)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3- list.clear() This deletes all elements in the list. The list is then called an empty list.

# COMMAND ----------

f = [2,4,"data ",45,217,"structure"]
f.clear()
print(f)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4- remove() :- This function is used to delete the first occurrence of number mentioned in its arguments.

# COMMAND ----------

lis = [2, 1, 3, 5, 3, 8] 
lis.remove(3) 
print(lis)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 5- del[a : b] :- This method deletes all the elements in range starting from index ‘a’ till ‘b’ mentioned in arguments.

# COMMAND ----------

lis = [2, 1, 3, 5, 4, 3, 8] 
  
# using del to delete elements from pos. 2 to 5 
# deletes 3,5,4 
del lis[2 : 5]
print(lis)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 6- del[]:- This method deletes the elements from specific index

# COMMAND ----------

lis = [2, 1, 3, 5, 4, 3, 8] 
  
# using del to delete elements from pos. 2 to 5 
# deletes 3,5,4 
del lis[1]
print(lis)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### sort() :- This function sorts the list in increasing order.

# COMMAND ----------

lis = [2, 1, 3, 5, 3, 8] 
  
# using sort() to sort the list 
lis.sort() 
print(lis)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### reverse() :- This function reverses the elements of list.

# COMMAND ----------

lis = [2, 1, 3, 5, 3, 8] 
lis.reverse()
print(lis)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 111- lst = [18,6,7,43,67,43,6] write a simple python program to insert an element into list without using inbuilt function?

# COMMAND ----------

# Given list
lst = [18, 6, 7, 43, 67, 43, 6]

# Element to insert
element_to_insert = 30

# Index where the element should be inserted
index_to_insert = 2

# Create a new list with the inserted element
new_lst = lst[:index_to_insert] + [element_to_insert] + lst[index_to_insert:]

print(new_lst)

# COMMAND ----------

lst = [18, 6, 7, 43, 67, 43, 6]
length = len(lst)
input_value = 9  # Changed variable name to avoid conflict with the 'input' function
index = 3

if index == length:
    lst = lst[:index] + [input_value]
else:
    lst = lst[:index] + [input_value] + lst[index:]

print(lst)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method 2: Without List Slicing

# COMMAND ----------

# Given list
lst = [18, 6, 7, 43, 67, 43, 6]

# Element to insert
element_to_insert = 30

# Index where the element should be inserted (e.g., index 2)
index_to_insert = 2

# Create a new list to hold the modified elements
new_lst = []

# Iterate through the original list
for i in range(len(lst)):
    if i == index_to_insert:
        new_lst.append(element_to_insert)
    new_lst.append(lst[i])

print(new_lst)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method 3- using inbuilt functiton insert()

# COMMAND ----------

lst = [18, 6, 7, 43, 67, 43, 6]
lst.insert(2,4)
print(lst)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 111- lst = [18,6,7,43,67,43,6], Write a simple python program to delete an element from list without using inbuilt function?

# COMMAND ----------

# Given list
lst = [18, 6, 7, 43, 67, 43, 6]

# Element to delete (e.g., 43)
element_to_delete = 43

# Create a new list without the deleted element
new_lst = lst[:lst.index(element_to_delete)] + lst[lst.index(element_to_delete) + 1:]

print(f"List after removing {element_to_delete}: {new_lst}")

# lst[:lst.index(element_to_delete)]: This part creates a sublist of lst containing all elements from the beginning of the list up to (but not including) the index of the first occurrence of element_to_delete. This represents the portion of the list before the element to be deleted.

# lst[lst.index(element_to_delete) + 1:]: This part creates a sublist of lst containing all elements starting from the index immediately after the first occurrence of element_to_delete until the end of the list. This represents the portion of the list after the element to be deleted.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method 2 - Method 2: Without List Slicing 

# COMMAND ----------

lst = [18, 6, 7, 43, 67, 43, 6]     # 1- lst
element_to_delete = 43              # 2- element_to_delete
new_lst = []                        # 3- new_lst to save the result

for i in lst:
    if i != element_to_delete:
        new_lst.append(i)
print(new_lst)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method 3 - by using inbuilt function remove()

# COMMAND ----------

lst = [18, 6, 7, 43, 67, 43, 6]
lst.remove(7)
print(lst)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 114- We have 4 teams namely India, Australia, Newzeland,Shrilanka, every team is playing with other team for example India is playing with Australia, Newzeland,Shrilanka and so on
# MAGIC Write a query in sql to find match list against every team and filter out that India is not playing with India itself?
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Cricket_teams (
# MAGIC     team_name VARCHAR(255)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO Cricket_teams (team_name) VALUES ('India'), ('Australia'), ('Newzeland'), ('Shrilanka');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Cricket_teams

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     t1.team_name AS team1,
# MAGIC     t2.team_name AS team2
# MAGIC FROM
# MAGIC     Cricket_teams t1
# MAGIC JOIN
# MAGIC     Cricket_teams t2 
# MAGIC ON t1.team_name != t2.team_name
# MAGIC ORDER BY
# MAGIC     team1, team2;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select 
# MAGIC t1.team_name as team1,
# MAGIC t2.team_name as team2
# MAGIC from Cricket_teams t1
# MAGIC join Cricket_teams t2
# MAGIC on t1.team_name != t2.team_name
# MAGIC order by team1, team2