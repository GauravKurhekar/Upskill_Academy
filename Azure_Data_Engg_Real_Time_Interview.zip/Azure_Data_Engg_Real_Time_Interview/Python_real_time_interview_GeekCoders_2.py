# Databricks notebook source
# MAGIC %md
# MAGIC ##### Question 1- CHECK IF SUM OF ANY TWO NUMBERS IS ZERO OR NOT?
# MAGIC logic is any value minus same value would give result as 0 for ex- 2-2=0, 5-5=0

# COMMAND ----------

def check_sum(nums):
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == 0:
                return True
    return False

 nums = [2, -5, 8, 3, -2]
result = check_sum(nums)

if result:
    print("There are two numbers whose sum is zero.")
else:
    print("No two numbers have a sum of zero.")


# COMMAND ----------

nums = [2, -5, 8, 3, -2]
k = []
def check_sum(nums,k):
    for i in range(len(nums)):
        for j in range(i+1, len(nums)):
            if nums[i]+nums[j]==k:
                return True
    return False
print(check_sum(nums,k))   

# COMMAND ----------

def check_sum(nums, k):
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == k:
                return True
    return False

# Example usage:
print(check_sum([12, 5, 0, 5], 10))  # Output: True
print(check_sum([20, 20, 4, 5], 40))  # Output: True
print(check_sum([1, -1], 0))          # Output: True
print(check_sum([1, 1, 0], 0))        # Output: False


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 2 - FIND A NON - NEGATIVE INTEGER THAT IS NOT IN THE ARRAY?

# COMMAND ----------

def find_missing_integer(arr):
    # Create a set to store the elements from the array     # Create a set from the array for constant-time membership checks
    num_set = set(arr)
    
    # Start checking from 0 and find the smallest missing integer
    i = 0
    while i in num_set:
        i += 1
    
    return i

# Example usage:
my_array = [0, 1, 2, 3, 5]
result = find_missing_integer(my_array)
print(f"The smallest non-negative integer not in the array is: {result}")

# COMMAND ----------

def find_missing_integer(arr):
    # Create a set from the array for constant-time membership checks
    num_set = set(arr)

    # Iterate to find the smallest non-negative integer not in the set
    missing_integer = 0
    while missing_integer in num_set:
        missing_integer += 1

    return missing_integer

# Example usage
my_array = [0, 1, 2, 3, 5]
result = find_missing_integer(my_array)

print(f"The smallest non-negative integer not in the array is: {result}")


# COMMAND ----------

arr = [0, 1, 2, 3, 5]
def miss(arr):
    i = 0
    new_arr = set(arr)
    while i in new_arr:
        i +=1
    return i
result = miss(arr)
print(f"The smallest non-negative integer not in the array is: {result}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 3- CHECK IF A STRING IS PALINDROME OR NOT?

# COMMAND ----------


def is_palindrome(s: str) -> bool:
    return s == s[::-1]

# COMMAND ----------

is_palindrome('racecar')

# COMMAND ----------

is_palindrome('Gaurav')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 4 - SWAPPING OF TWO NUMBER?

# COMMAND ----------

# Method 1: Using a temporary variable
x = 5
y = 10

# Swapping the values
temp = x
x = y
y = temp

print("After swapping:")
print("x =", x)
print("y =", y)

# Method 2: Without using a temporary variable
x = 5
y = 10

# Swapping the values
x, y = y, x

print("After swapping:")
print("x =", x)
print("y =", y)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 5 - Find factorial of given number, for ex - 5= 5*4*3*2*1= 120?  

# COMMAND ----------


def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n-1)

num = int(input("Enter a number: "))
print("The factorial of", num, "is", factorial(num))


# COMMAND ----------




# COMMAND ----------

def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)

# Example usage
number = 5
result = factorial(number)

print(f"The factorial of {number} is: {result}")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 6 - Write python program to find the length of list using recursive function?

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method 1

# COMMAND ----------

def list_length(my_list):
    if my_list == []:
        return 0
    else:
        return 1 + list_length(my_list[1:])

# Example usage
my_list = [1, 2, 3, 4, 5]
print("The length of the list is", list_length(my_list))

#If the input list is empty, the function returns 0. Otherwise, it returns 1 plus the length of the rest of the list (i.e., all elements except the first one) by calling itself recursively with the rest of the list as input.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method 2

# COMMAND ----------

def recursive_length(lst):
    # Base case: an empty list has length 0
    if not lst:
        return 0
    # Recursive case: length is 1 (for the current element) + length of the rest of the list
    else:
        return 1 + recursive_length(lst[1:])

# Example usage
my_list = [1, 2, 3, 4, 5, 6, 7]
result = recursive_length(my_list)

print(f"The length of the list is: {result}")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method 3

# COMMAND ----------


lst = [1,2,3,4,5]
print(len(lst))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 7 - Repeat Each character N times?

# COMMAND ----------

# HELLO --> HHHEEELLLLLLOOO every word repeted three times
s = 'hello'
s1 = ''
for i in s:
    s1 = s1+i*3  # or s1+=i*3
print(s1)


# COMMAND ----------

s = 'hello'
new= ''
for i in s:
    new = new+ i*2
print(new)

# COMMAND ----------

input_str = "Hello World!"
repeat = 3

def repeat_characters(input_str, n):
    result_str = ""
    for char in input_str:
        result_str += char * n
    return result_str

# Example usage

result = repeat_characters(input_str, repeat)

print(f"The string with each character repeated {repeat} times is:")
print(result)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 8 - REVERSE ORDER OF WORDS?

# COMMAND ----------

# for ex- i/p='this is gaurav' , o/p= 'Gaurav is this'
# 1st approach using user define function

sentence = 'This is Gaurav'

def reverse_words(sentence):
    words = sentence.split()                    # split the sentence
    reversed_sentence = ' '.join(words[::-1])   # reverse the sentence
    return reversed_sentence                    # return the sentence
    
result = reverse_words(sentence)

print(sentence)
print(result)

# The reverse_words_order function takes a sentence as an argument.
# It splits the sentence into a list of words.
# The words are then reversed using list slicing (words[::-1]).
# The reversed words are joined into a single string with space between them.
# The function returns the result.

# COMMAND ----------

word = 'this is gaurav'
reverse_word = ' '.join(reversed(word.split()))
print(reverse_word)

# word.split() splits the sentence into a list of words.
# reversed() reverses the order of the words.
# ' '.join(...) joins the reversed words into a single string with space between them.

# COMMAND ----------

word = 'This is Gaurav'
reversed_word = ' '.join(word.split()[::-1])
print(reversed_word)
# It then uses slicing to reverse the order of the words in the list and joins them back together into a string using the join() method.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 9 - FIND K MOST FREQUENT ELEMENT OF AN ARRAY in python?
# MAGIC Use max with a custom key function to find the most frequent element

# COMMAND ----------

def most_frequent(lst):
    return max(set(lst), key=lst.count)     # Use max with a custom key function to find the most frequent element

# Example usage:
my_list = [2, 1, 2, 2, 1, 3]
print("The most frequent element is:", most_frequent(my_list))  # Output: 2


# COMMAND ----------

lst = [2, 1, 2, 2, 1, 3]
def most(lst):
    return max(set(lst), key = lst.count)
print(most(lst))

# COMMAND ----------

from collections import Counter
lst = [2, 1, 2, 2, 1, 3]
def most_frequent(lst):
    occurrence_count = Counter(lst)
    return occurrence_count.most_common(1)[0][0]


print(most_frequent(lst))  # Output: 2


# COMMAND ----------

# MAGIC %md 
# MAGIC ##### Question 11 - CHECK IF THE LIST IS SORTED OR NOT?

# COMMAND ----------


# Method 1 Traditional method
def is_sorted(input_list):
    for i in range(1, len(input_list)):
        if input_list[i] < input_list[i-1]:
            return False
    return True

input_list = [1, 2, 3, 4, 5]
print(is_sorted(input_list)) # Output: True


# COMMAND ----------

# Method 2 using sort() method
def is_sorted(input_list):
    return input_list == sorted(input_list)

input_list = [5, 4, 3, 2, 1]
print(is_sorted(input_list)) # Output: False


# COMMAND ----------

# Method 3 - using all() function
def is_sorted(input_list):
    return all(input_list[i] <= input_list[i+1] for i in range(len(input_list)-1))

input_list = [1, 2, 3, 4, 5]
print(is_sorted(input_list)) # Output: True


# COMMAND ----------

def is_sorted_method1(lst):
    # Using the all() function and list comprehension
    return all(lst[i] <= lst[i + 1] for i in range(len(lst) - 1))

def is_sorted_method2(lst):
    # Using the sorted() function and comparing with the original list
    return lst == sorted(lst)

def is_sorted_method3(lst):
    # Using the sorted() function and comparing with the original list in reverse order
    return lst == sorted(lst, reverse=True)

# Example usage:
my_list = [1, 2, 3, 4, 5]
result1 = is_sorted_method1(my_list)
result2 = is_sorted_method2(my_list)
result3 = is_sorted_method3(my_list)

print(f"Original list: {my_list}")
print(f"Method 1: Is the list sorted? {result1}")
print(f"Method 2: Is the list sorted? {result2}")
print(f"Method 3: Is the list sorted in reverse order? {result3}")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 12 - Count the Frequency of Elements in a List?

# COMMAND ----------

from collections import Counter

def count_frequency(input_list):
    return dict(Counter(input_list))

input_list = [1, 2, 3, 4, 5, 5, 2, 3]
print(count_frequency(input_list)) # Output: {1: 1, 2: 2, 3: 2, 4: 1, 5: 2}


# COMMAND ----------

from collections import Counter
def count_num(input_number):
    return dict(Counter(input_number))

input_number = [1,1,2,2,3,3,3,4,4,4,4,]
print(count_num(input_number))

# COMMAND ----------

# Method 2 by using user define function
def counter(input_list):
    freq = {}
    for i in input_list:
        freq[i] = freq.get(i,0)+1
    return freq

print(counter([1,2,3,4,4,3,2,5]))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 13 - Convert first and last characters to upper case, input_str = 'hello gaurav'

# COMMAND ----------

input_str = 'hello gaurav'
def convert_char(input_str):
    # Split the input string into words
    words = input_str.split()

    # Loop through each word and convert the first and last character to uppercase
    for i in range(len(words)):
        words[i] = words[i][0].upper() + words[i][1:-1] + words[i][-1].upper()

    # Join the modified words back into a sentence
    output_str = ' '.join(words)
    return output_str
    
# Example usage
output_str = convert_char(input_str)
print(output_str)


# COMMAND ----------

input_str = 'hello gaurav'
def convert_char(input_str):
    return input_str[0].upper() + input_str[1:-1] + input_str[-1].upper()

print(convert_char(input_str)) # Output: 'Hello gaurAv'


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 14 - Write python code to create a new list with only numerical values?
# MAGIC to print only numerical values, use **isdigit() function along with .split()[0]** method

# COMMAND ----------

lst = ['30 student', '5 student', '7 student']
#l = list(map(lambda i: int(i.split()[0]),lst))
#print(l)

l = map(lambda i: (i.split()[0]),lst)
l1 = list(l)
print(l1)

# COMMAND ----------

lst = ['30 student', '5 student', '7 student']
numlst = []

for i in lst:
    if i.split()[0].isdigit():
        numlst.append(int(i.split()[0]))

print("Original List:", lst)
print("Numerical List:", numlst)


# COMMAND ----------

lst = ['30 student', '5 student', '7 student']
alpha_lst = []
for i in lst:
    if i.split()[1].isalpha():
        alpha_lst.append(i.split()[1])
print(alpha_lst)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 15 - Write python code to create a new list with only words in list?
# MAGIC to print only numerical values, use **isalpha() function along with .split()[1]** method

# COMMAND ----------

lst = ['30 student', '5 class', '7 number']
new_list = []
for i in lst:
    if i.split()[1].isalpha():
        new_list.append(i.split()[1])
print(new_list)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 18 -GET THE SECOND GREATEST ELEMENT FROM THE ARRAY/LIST?

# COMMAND ----------

list1 = [10, 20, 4, 45, 99]
list1.sort()
print("Second largest element is:", list1[-2])


# COMMAND ----------

list1 = [10, 20, 4, 45, 99]
list1 = list(set(list1))
list1.sort()
print("The second largest element is:", list1[-2])


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 20 - Find the unique words from the give input string?
# MAGIC use **set()** function to find the unique words from string

# COMMAND ----------

str1 = 'Hello hello gaurav gaurav kurhekar'
unique_words = set(str1.split())
print("Unique words:", unique_words)


# COMMAND ----------

str1 = 'Hello hello gaurav gaurav kurhekar'

# Split the string into words and convert to lowercase
words = str1.lower().split()

# Use set to get unique words
unique_words = set(words)

print(f"Original string: {str1}")
print(f"Unique words: {unique_words}")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 22 - Python program to insert a string in the middle of a given string?

# COMMAND ----------

Input_str = 'city:Akola-Maharashtra'
Output_str = Input_str.replace('-', '-State: ')
print(Output_str)

# replace() method to replace the hyphen with '-State: '

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 27 - Python program to transform the month number to month name? 
# MAGIC for ex - lst = ['01-01-20', '21-03-22', '23-02-23'] 
# MAGIC sample output lst = ['01-jan-2023', '21-mar-2023', '23-feb-2023'] 

# COMMAND ----------

import calendar

input_lst = ['01-01-20', '21-03-22', '23-02-23']
output_lst = []

for i in input_lst:
    day, month, year = i.split('-')
    month_name = calendar.month_abbr[int(month)].lower()
    output_lst.append(f"{day}-{month_name}-{year}")

print(output_lst)

# COMMAND ----------

day, month, year = i.split('-'): This line splits each element i (a string representing a date) into three parts using the hyphen ('-') as the separator. The resulting values are assigned to the variables day, month, and year.

month_name = calendar.month_abbr[int(month)].lower(): It converts the month (which is a string) to an integer using int(month), then uses calendar.month_abbr to get the abbreviated month name as a string. The .lower() method is called to convert the month abbreviation to lowercase.

output_lst.append(f"{day}-{month_name}-{year}"): It creates a new string in the format "day-month_name-year" and appends it to the output_lst. The formatted string (f-string) uses the values of day, month_name, and year obtained from the previous steps.

# COMMAND ----------

# 2nd approach
def transform_dates(input_lst):
    month_names = {
        '01': 'jan', '02': 'feb', '03': 'mar', '04': 'apr',
        '05': 'may', '06': 'jun', '07': 'jul', '08': 'aug',
        '09': 'sep', '10': 'oct', '11': 'nov', '12': 'dec'
    }

    output_lst = []

    for date_str in input_lst:
        day, month, year = date_str.split('-')
        transformed_date = f'{day}-{month_names[month]}-20{year}'
        output_lst.append(transformed_date)

    return output_lst

input_lst = ['01-01-20', '21-03-22', '23-02-23']
output_lst = transform_dates(input_lst)

print(output_lst)


# COMMAND ----------

# 3rd approach
def month_num_to_month_name(input_lst):
  month_names = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
  output_lst = []
  for input_date in input_lst:
    month_num = input_date.split("-")[1]
    month_name = month_names[int(month_num) - 1]
    output_date = input_date.replace(month_num, month_name)
    output_lst.append(output_date)
  return output_lst

input_lst = ['01-01-20', '21-03-22', '23-02-23']
output_lst = month_num_to_month_name(input_lst)
print(output_lst)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 28 - Flatten a list and count occurrences in Python?

# COMMAND ----------

input_list = [[1,2], [3,4],[2,3],[5,1],[7,1,2]]
# output = {1:3, 2:3,3:2, 4:1,5:1,7:1}

def f_get_count(input_list):
    counts = {}
    for sublist in input_list:
        for item in sublist:
            if item in counts:
                counts[item] += 1
            else:
                counts[item] = 1
    return counts

input_list = [[1, 2], [3, 4], [2, 3], [5, 1], [7, 1, 2]]
result = f_get_count(input_list)
print(result)
