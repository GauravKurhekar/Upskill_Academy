# Databricks notebook source
# MAGIC %md
# MAGIC ### This notebook contain below pyton topics
# MAGIC ##### datetime-10
# MAGIC ##### file i/o-10
# MAGIC ##### csv file reading/writting-5

# COMMAND ----------

# MAGIC %md
# MAGIC ### Python datetime [63 exercises with solution]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 1- Write a search Python script to display the various Date Time formats?

# COMMAND ----------


import time
import datetime
print("Current date and time: " , datetime.datetime.now())
print("Current year: ", datetime.date.today().strftime("%Y"))
print("Month of year: ", datetime.date.today().strftime("%B"))

print("Day of the month : ", datetime.date.today().strftime("%d"))
print("Day of week: ", datetime.date.today().strftime("%A"))


# COMMAND ----------

import time
import datetime
print("Week number of the year: ", datetime.date.today().strftime("%W"))
print("Weekday of the week: ", datetime.date.today().strftime("%w"))
print("Day of year: ", datetime.date.today().strftime("%j"))

# COMMAND ----------

import time
import datetime
print("Day of the month : ", datetime.date.today().strftime("%d"))
print("Day of week: ", datetime.date.today().strftime("%A"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 2 - Write a Python program to convert a string to datetime?

# COMMAND ----------

from datetime import datetime
date_object = datetime.strptime('Jul 1 2014 2:43PM', '%b %d %Y %I:%M%p')
print(date_object)

from datetime import datetime
date_object = datetime.strptime('Jul 1 2014 2:43PM', '%b %d %i:%m%p')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 3 - Write a Python program to get the current time?  

# COMMAND ----------

import datetime
print(datetime.datetime.now().time())


# COMMAND ----------

print(datetime.datetime.now().time())

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 4 - Write a Python program to subtract five days from the current date?

# COMMAND ----------

# Import the datetime module
import datetime

# Get the current date
current_date = datetime.date.today()

# Use the timedelta() function to subtract five days from the current date
new_date = current_date - datetime.timedelta(days=5)

# Print the result
print("The new date is:", new_date)


# COMMAND ----------

# SOLUTION 2
from datetime import date, timedelta
dt = date.today() - timedelta(5)

print('Current Date :',date.today())
print('5 days before Current Date :',dt)

# Use the timedelta() function to subtract five days from the current date

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 5 - Write a Python program to convert a Unix timestamp string to a readable date?

# COMMAND ----------

import datetime
print(
    datetime.datetime.fromtimestamp(
        int("1284105682")
    ).strftime('%Y-%m-%d %H:%M:%S')
)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 6 - Write a Python program to print yesterday, today, tomorrow?

# COMMAND ----------

import datetime 

today = datetime.date.today()
yesterday = today - datetime.timedelta(days = 1)
tomorrow = today + datetime.timedelta(days = 1) 

print('Yesterday : ',yesterday)
print('Today : ',today)
print('Tomorrow : ',tomorrow)


# COMMAND ----------

from datetime import date, timedelta
today = date.today()
tomorrow = date.today() + timedelta(1)
yesterday = date.today() -timedelta(1)

print(today)
print(tomorrow)
print(yesterday)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 7 - Write a Python program to print the next 5 days starting today?

# COMMAND ----------

from datetime import date, timedelta
for i in range(1,6):
    next_days = date.today() + timedelta(i)
    print(next_days)

 # The timedelta() function returns a duration object that represents a difference between two dates or times

# COMMAND ----------

# Import the datetime module
import datetime

# Get the current date
today = datetime.date.today()
# The date.today() function returns the current local date as a date object

# Use a for loop and the timedelta() function to print the next 5 days
for i in range(1, 6):
    next_day = today + datetime.timedelta(days=i)
    print(next_day)

    # The timedelta() function returns a duration object that represents a difference between two dates or times
    # The days parameter specifies the number of days to add to the current date

# COMMAND ----------

import datetime
today = datetime.date.today()
for i in range(1,6):
    next_day = today + datetime.timedelta(days = i)
    print(next_day)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 8 - Write a Python program to add 5 seconds to the current time?

# COMMAND ----------

from datetime import datetime, timedelta

w = datetime.now()
x = datetime.now() + timedelta(seconds =5)

print("Current time:", w.time())
print("Current time + 5 seconds:", x.time())


# COMMAND ----------


import datetime
x= datetime.datetime.now()
y = x + datetime.timedelta(0,5)
print(x.time())
print(y.time())


# COMMAND ----------

import datetime
today = datetime.datetime.now()
five_sec = today + datetime.timedelta(0,5)
print(five_sec)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 9- Write a Python program to get the week number?

# COMMAND ----------

from datetime import datetime

# Get the current date
current_date = datetime.now()

# Get the week number using strftime and %U
week_number = current_date.strftime("%U")

print("Current week number:", week_number)


# COMMAND ----------

import datetime
today = datetime.date.today()
week = today.isocalendar()[1]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 10 - Write a Python program to get days between two dates?

# COMMAND ----------

from datetime import date
a = date(2000,2,28)
b = date(2001,2,28)
print(b-a)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 11 - Write a Python program to get the number of days in a given month and year?

# COMMAND ----------

from calendar import monthrange
year = 2016
month = 2
print(monthrange(year, month))


# COMMAND ----------

# MAGIC %md
# MAGIC ### Class function

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 12 - Write a Python program to create an instance of a specified class and display the namespace of the said instance?

# COMMAND ----------

class Student: 
    def __init__(self, student_id, student_name, class_name):
        self.student_id = student_id
        self.student_name = student_name
        self.class_name = class_name 
student = Student('V12', 'Frank Gibson', 'V')
print(student.__dict__)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Python File Input Output[ 21 exercises with solution]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 13 - Write a Python program to read an entire text file?

# COMMAND ----------

def file_read(fname):
        txt = open(fname)
        print(txt.read())

file_read('test.txt')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 14 - Write a Python program to append text to a file and display the text?

# COMMAND ----------

def file_read(fname):
        from itertools import islice
        with open(fname, "w") as myfile:
                myfile.write("Python Exercises\n")
                myfile.write("Java Exercises")
        txt = open(fname)
        print(txt.read())
file_read('abc.txt')

#   Import the islice function from the itertools module
#   from itertools import islice
#   The islice function returns an iterator that returns selected elements from another iterable


# COMMAND ----------

file_name = "test.txt"          # Define the file name

text = "Hello, world!"          # Define the text to append

file = open(file_name, "a")     # Open the file in append mode

file.write(text + "\n")         # Write the text to the file

file.close()                    # Close the file

file = open(file_name, "r")     # Open the file in read mode

contents = file.read()          # Read and print the contents of the file
print(contents)
file.close()                    # Close the file

# The open() function returns a file object that can be used to read or write data to the file
# The mode parameter specifies how the file is opened, "a" means append mode, which adds data to the end of the file
# The close() method closes the file and frees up any system resources used by it
# The mode parameter specifies how the file is opened, "r" means read mode, which allows reading data from the file

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 15 - Write a Python program to read a file line by line and store it into a list?

# COMMAND ----------

def file_read(fname):
        with open(fname) as f:
                #Content_list is the list that contains the read lines.     
                content_list = f.readlines()
                print(content_list)

file_read(\'test.txt\')


# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 16 - Write a Python program to read a file line by line store it into a variable?

# COMMAND ----------

def file_read(fname):
        with open (fname, "r") as myfile:
                data=myfile.readlines()
                print(data)
file_read('test.txt')


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 17 - Write a Python program to read a file line by line store it into an array?

# COMMAND ----------

def file_read(fname):
        content_array = []
        with open(fname) as f:
                #Content_list is the list that contains the read lines.     
                for line in f:
                        content_array.append(line)
                print(content_array)

file_read('test.txt')


# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 18 - Write a Python program to count the number of lines in a text file?

# COMMAND ----------

def file_lengthy(fname):
        with open(fname) as f:
                for i, l in enumerate(f):
                        pass
        return i + 1
print("Number of lines in the file: ",file_lengthy("test.txt"))


# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 19 - Write a Python program to copy the contents of a file to another file?

# COMMAND ----------

from shutil import copyfile
copyfile('source.py', 'destination.py')

# COMMAND ----------

# SOLUTION 2
import shutil

source_file = "source.txt"
destination_file = "destination.txt"

shutil.copy(source_file, destination_file)

# The shutil.copy() function copies the data and mode (permissions) of the source file to the destination file

# Use the shutil.copy() function to copy the contents of the source file to the destination file


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 20 - Write a Python program to combine each line from first file with the corresponding line in second file?

# COMMAND ----------

with open('abc.txt') as fh1, open('test.txt') as fh2:
    for line1, line2 in zip(fh1, fh2):
        # line1 from abc.txt, line2 from test.txtg
        print(line1+line2)
		

# COMMAND ----------

with open('abc.txt') as one, open('xyz.txt') as two:
    for line1, line2 in zip(one, two):
        print(line1+line2)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 21 - Write a Python program to read a given CSV file having tab delimiter?

# COMMAND ----------

import csv
with open('countries.csv', newline='') as csvfile:
 data = csv.reader(csvfile, delimiter = '\t')
 for row in data:
   print(', '.join(row))
    

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 22 - Write a Python program to read a given CSV file as a list?

# COMMAND ----------

import csv
with open('employees.csv', newline='') as f:
   reader = csv.reader(f)
   data_list = list(reader)
print(data_list)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 23 - Write a Python program to read a given CSV file as a dictionary?

# COMMAND ----------

import csv
data = csv.DictReader(open("departments.csv"))
print("CSV file as a dictionary:\n")
for row in data:
   print(row)


# COMMAND ----------

import csv
data = csv.Dictreader(open('dept.csv'))
print('dict')
for row in data:
    print(row)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 24- We have list, count the list of item using Python?

# COMMAND ----------

lst = ['a','a','b','b','c','c']
dict1 = {}
for i in lst:
    if i in dict1:
        dict1[i]+=1
    else:
        dict1[i] = 1
print(dict1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 25- We have list, count the list of item using Pyspark?

# COMMAND ----------

lst = ['a','a','b','b','c','c']
# Step 1: Initialize an empty list called data
data = []

# Step 2: Iterate through each character in the list lst
for i in lst:
    # Step 3: Create a tuple with the character (char,)
    # The comma is required to create a single-element tuple
    char_tuple = (i,)

    # Step 4: Add the tuple to the data list
    data.append(char_tuple)

    # Create a DataFrame with a single column for the characters
df = spark.createDataFrame(data, ["character"])

# Group by the character column and count the occurrences
result = df.groupBy("character").count()

# Show the result
result.show()


# COMMAND ----------

lst = ['a', 'a', 'b', 'b', 'c', 'c']
data = []
for i in lst:
    data.append((i,))
df = spark.createDataFrame(data, ['key'])
df1 = df.groupBy('key').count()
df1.show()

# COMMAND ----------

# Create a list of tuples
lst = [('a',), ('a',), ('b',), ('b',), ('c',), ('c',)]

# Create a DataFrame with a single column named "key"
final = spark.createDataFrame(lst, ["key"])

# Group by the "key" column and count occurrences
result = final.groupBy("key").count()

# Show the result
result.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 26- convert datetime format into date format?

# COMMAND ----------

from pyspark.sql.functions import col, date_format
# Sample data
data = [("2024-04-28 12:30:00",),
        ("2024-04-29 10:45:00",),
        ("2024-04-30 08:15:00",)]

# Define the schema
schema = ["datetime"]

# Create a DataFrame
df = spark.createDataFrame(data, schema)

# Convert datetime column to date format
df = df.withColumn("date", date_format(col("datetime"), "yyyy-MM-dd"))

# Show the DataFrame
df.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 27- Convert pascal case into normal case for ex- ProductName into Product_Name

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, regexp_replace
# Sample data
data = [("iPhone", 1000),
        ("Samsung Galaxy", 800),
        ("Google Pixel", 700)]

# Define the schema
schema = ["ProductName", "Price"]

# Create a DataFrame
df = spark.createDataFrame(data, schema)

# Function to convert PascalCase to snake_case using regexp_replace
def convert_pascal_to_snake(column_name):
    return regexp_replace(column_name, r'(?<!^)(?=[A-Z])', '_').lower()

# Rename columns
for col_name in df.columns:
    new_col_name = convert_pascal_to_snake(col_name)
    df = df.withColumnRenamed(col_name, new_col_name)

# Show the DataFrame with renamed columns
df.show()
