# Databricks notebook source
# MAGIC %md
# MAGIC ##### Question 11 - Schema validation framework in pyspark using python/pyspark?

# COMMAND ----------

# MAGIC %fs head /FileStore/tables/Student_schema.parquet

# COMMAND ----------

# MAGIC %fs head /FileStore/tables/Student1234.csv

# COMMAND ----------

df = spark.read.format("csv").option("header", True).option("inferschema", True).load("/FileStore/tables/Student1234.csv")
df.show()

# COMMAND ----------

from pyspark.sql.types import _parse_datatype_string
from pyspark.sql import DataFrame

def f_validate_schema(input_schema: str, df: DataFrame):
    output_schema = _parse_datatype_string(input_schema)
    df_schema = df.schema
    if output_schema == df_schema:
        return "Yes, it's matching"
    else:
        raise ValueError("No, it's not matching")

f_validate_schema("ID int, Name string, Age int, Marks double", df)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Unit testing in pyspark

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 12- Write a pyspark code to check a person (use column name) whether he is eligible for vote or not with test?

# COMMAND ----------

data = [(1, "Gaurav", 34), (2, "Vaidehi", 28),(3, "Monu", 32)]
df = spark.createDataFrame(data, schema = "ID int, Name string, Age int")
df.show()

# COMMAND ----------

from pyspark.sql.functions import lower, when, col
df1 = df.withColumn("Name", lower(col("Name"))).withColumn("IsEligible", when(col("Age")>18, "Yes").otherwise("No"))
display(df1)

df1 = df.withColumn('Eligilibility_cirtria', when df["Age"]>18, 'Eligible').otherwise("Not eligible")4

select name, case
when Age>18 then eligible else not eligible

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import lower, when, col
def f_lower(df:DataFrame):
    return df.withColumn("Name", lower(col("Name")))

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import lower, when, col
def f_eligible(df:DataFrame):
    return df.withColumn(("IsEligible", when(col("Age")>18, "Yes").otherwise("No")))

# COMMAND ----------

# 1 way to call and test this function is
df_1 = f_lower(df)
df_1 = f_eligible(df_1)
display(df_1)

# COMMAND ----------

# 2nd is better approach
df_2 = df.transform(f_lower).transform(f_eligible)
display(df_2)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### SQL code to check eligibility critria

# COMMAND ----------

SELECT 
    Name,
    Age,
    CASE
        WHEN Age > 18 THEN 'Eligible for Voting'
        ELSE 'Not Eligible for Voting'
    END AS Eligibility
FROM 
    Persons;

# COMMAND ----------

# DBTITLE 1,Unit Test
data = [(1, "Gaurav"), (2, "Vaidehi"),(3, "Monu")]
df_test = spark.createDataFrame(data, schema = "ID int, Name string")
display(f_lower(df_test))
display(df_test)

# COMMAND ----------

data = [(1, "Monu"), (2, "Vaidu")]
df_expected = spark.createDataFrame(data, schema = "ID int, Name string")
display(df_expected)

# COMMAND ----------

print(df_test.collect() == df_expected.collect())

# COMMAND ----------

if(df_test.collect() == df_expected.collect()):
    print("Function is correct")
else:
    raise Exception("Function is wrong")

# COMMAND ----------

# write this test into def 
from pyspark.sql import DataFrame
def unit_testing(df_test: DataFrame, df_expected:DataFrame):
    if(df_test.collect() == df_expected.collect()):
        print("Function is correct")
    else:
        raise Exception("Function is wrong")


# COMMAND ----------

unit_testing(df_test, df_expected)

# COMMAND ----------

# write this test into def 
from pyspark.sql import DataFrame
def unit_testing(df_test: DataFrame, df_expected:DataFrame, func):
    df_testing = func(df_testing)
    if(df_test.collect() == df_expected.collect()):
        print("Function is correct")
    else:
        raise Exception("Function is wrong")


# COMMAND ----------

unit_testing(df_test, df_expected, f_lower)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 11 - Exclude column names from data frame based on given condition
# MAGIC ##### Question - create dataframe with only valid column, valid columns are those 1- which does not contain null and 2 - does not contain numeric values 

# COMMAND ----------

data = [(None, "B", "C","E", "G", "I"), 
        ("A", "10", "D", "F", "H", "J")]
columns = ["col1", "col2","col3","col4","col5","col6"]
df = spark.createDataFrame(data, columns)
display(df)
df.show()

# COMMAND ----------

 # logic - we can go all cols one by one and check if we have null and numbers and ignore the columns
 # we have function called df.columns which get the list of column names
 df.columns

# COMMAND ----------

# ~ this letter is used to reverse the order 
for ex - (col(i).isNull) = showing true and other values are false
         (~col(i).isNull) = showing false and other values are true
         

# COMMAND ----------

# work on 1st condition
from pyspark.sql.functions import col
for i in df.columns:
    df.select(~col(i).isNull()).show()


# COMMAND ----------

# work on 2nd condition
from pyspark.sql.functions import col
for i in df.columns:
    df.select(~col(i).rlike('^[0-9]*$')).show()

# COMMAND ----------

total_rows = df.count()

# COMMAND ----------

l = []
for i in df.columns:
    if(df.select(~col(i).isNull() & ~col(i).rlike('^[0-9]*$')).distinct().count()!=total_rows):
        l.append(i)
    print(l)
    df_1 = df.select(*l)
    df_1.show()

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/FileStore/tables/Dummy.txt

# COMMAND ----------

# MAGIC %md
# MAGIC ##### How to extract information from text file using regex

# COMMAND ----------

df = spark.read.text("dbfs:/FileStore/tables/Dummy.txt")
display(df)

# COMMAND ----------

from pyspark.sql.functions import *
df.select("*").withColumn("new_1", split("value", (" "))).show()

# COMMAND ----------

from pyspark.sql.functions import *

df1 = df.select("*").withColumn("first_name", regexp_extract(df.value, "([a-zA-Z]+)", 1)). \
    withColumn("last_name", regexp_extract(df.value, "([a-zA-Z]+)", 1)). \
    withColumn("Age", regexp_extract(df.value, "([0-9]+)", 1)). \
    withColumn("Marks", regexp_extract(df.value, "([0-9]+)$", 1)).show()


# COMMAND ----------

# MAGIC %md
# MAGIC #### Introduction of pytest in Pyspark databricks

# COMMAND ----------

# 1 - How we can write code in databricks
# 2 - How we can test the code
# 3 - How to merge the code in repository

# COMMAND ----------

# MAGIC %fs 
# MAGIC head /FileStore/tables/Student12.csv

# COMMAND ----------

Requirement
1 - Add loadtime column in final dataframe
2 - Add filename column in final dataframe
3 - Need to cast the column

# COMMAND ----------

df = spark.read.format("csv").option("inferschema", True).option("Header", True).load("/FileStore/tables/Student12.csv")
df.show()

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, input_file_name, col
df.withColumn("load_time", current_timestamp()).withColumn("file_name", input_file_name()).show()

# COMMAND ----------

column_list = {
    "ID": "int",
    "Name": "string",
    "Age": "int"
}
df.select([col(column).cast(datatype).alias(column) for column, datatype in column_list.items()])

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, input_file_name, col
column_list = {
    "ID": "int",
    "Name": "string",
    "Age": "int"
}
df1 = df.select([col(column).cast(datatype).alias(column) for column, datatype in column_list.items()])

df2 = df1.withColumn("load_time", current_timestamp()).withColumn("file_name", input_file_name()).show()
display(df2)

# COMMAND ----------

def f_add_loadtime(df):
    return df.withColumn("load_time", current_timestamp())

# COMMAND ----------

def f_add_file_name(df):
    return df.withColumn("file_name", input_file_name())

# COMMAND ----------

def f_cast_columns(df, column_cast_dict:dict):
    return df.select([col(column).cast(datatype).alias(column) for column, datatype in column_list.items()])