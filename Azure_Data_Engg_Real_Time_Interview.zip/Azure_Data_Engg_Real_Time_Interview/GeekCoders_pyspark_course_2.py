# Databricks notebook source
# MAGIC %md
# MAGIC ##### Question 7 -caching and persistance?

# COMMAND ----------

# caching - caching is useful when you are going to use same dataframe and rdd multiple time
# persistance - same like cache but allows you to store data in different storage level

# COMMAND ----------

# Question - you have dataframe and you need to use that dataframe again and again then what you can do?
    # Answer - will cache that data 

# COMMAND ----------

# MAGIC %fs
# MAGIC head 'dbfs:/FileStore/demo_broadcast.csv'

# COMMAND ----------

df = spark.read.format("csv").option("Header", True).option("inferschema", True).load("dbfs:/FileStore/demo_broadcast.csv")
df.show()

# COMMAND ----------

# full dataset
df1 = df.select("*")
df1.show()

# COMMAND ----------

# only selected columns
df2 = df.select("ID", "Name")
df2.show()

# COMMAND ----------

# dataset with some filters
df3 = df.select("*").filter("ID==1")
df3.show()

# COMMAND ----------

# now we are repeating data frame again and again so cache that data
df = spark.read.format("csv").option("Header", True).option("inferschema", True).load("dbfs:/FileStore/demo_broadcast.csv")
df4 = df.cache()
df4.count()

# now our data will work fast

# COMMAND ----------

# to remove the dataframe from worker node
df.unpersist()

# COMMAND ----------

# how to persist the data
df = spark.read.format("csv").option("Header", True).option("inferschema", True).load("dbfs:/FileStore/demo_broadcast.csv")
df5 = df.persist()
df5.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 8 - How to call dataframe from another Notebook?

# COMMAND ----------

data = [(1, "Gaurav"), (2, "Vaidehi")]
df = spark.createDataFrame(data = data, schema = "id int, name string")
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1st approach- use %run followed by path

# COMMAND ----------

# go to any other notebook and call it by using percent run i.e %run "path"
%run "/SQL_pyspark_python_real_time_interview/GeekCoders_pyspark_course_2"

# it will execute all the commands from that notebook

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2nd approach - # createOrReplaceGlobalTempView

# COMMAND ----------

# difference between tempView and GlobalTempView is tempView is associated only to this notebook session, 

# COMMAND ----------

df.createOrReplaceGlobalTempView("Student")

# COMMAND ----------

# MAGIC %sql -- it will get failed because globalTempView stored into "global_temp" database
# MAGIC select * from student

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.student

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 9 - Why monotonically_increasing_id number method is not optimized to generate key id column in large dataset in pyspark?/

# COMMAND ----------

The monotonically_increasing_id() function in PySpark is designed to generate unique and monotonically increasing IDs for rows within a DataFrame. While it can be useful for small to moderately sized DataFrames, it is not optimized for generating key ID columns in large datasets due to several reasons:
    
-- you can use monotonically_increasing_id() to generate incremental number however number wont be consecutive if dataframe having more than 1 partition.
-- if data is less, we can go for 1 partition, if data is bigger, its not recommended to use single partition.

1 - Lack of Global Uniqueness: The monotonically_increasing_id() function generates IDs unique within a partition but not necessarily unique across all partitions of a DataFrame. If you have a large dataset distributed across many partitions, this can lead to non-unique IDs
2 - The generated IDs are of "Long" data type, which provides a limited range. 
3- Always use "row_number" function for increasing id if there is partition column
4 - UUIDs (Universally Unique Identifiers): Use the uuid library to generate universally unique IDs that are suitable for distributed and large-scale environments.
S For certain use cases, you can generate IDs based on the hash of one or more columns in your DataFrame. This can help distribute the IDs uniformly and ensure uniqueness.
6- 

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/FileStore/tables/employee3-1.csv

# COMMAND ----------

df = spark.read.format("csv").option("Header", True).load("dbfs:/FileStore/tables/employee3-1.csv")
df.show()

# COMMAND ----------



# COMMAND ----------

df.rdd.getNumPartitions()

# COMMAND ----------

from pyspark.sql.functions import monotonically_increasing_id
df_mono = df.select("*").withColumn("consecutive_num", monotonically_increasing_id()+1)
display(df_mono)

# COMMAND ----------

# change the partition to 2
df = spark.read.format("csv").option("Header", True).load("dbfs:/FileStore/tables/employee3-1.csv")
df = df.repartition(2)
df.show()

# COMMAND ----------

df.rdd.getNumPartitions()

# COMMAND ----------

# after changing partition, consecutive number has been changed
from pyspark.sql.functions import monotonically_increasing_id
df_mono = df.select("*").withColumn("consecutive_num", monotonically_increasing_id()+1)
display(df_mono)

# COMMAND ----------

# Note - always use row_number function for increasing id if there is partition column
from pyspark.sql.functions import row_number, lit, col
from pyspark.sql.window import Window
wd = Window.partitionBy(lit(1)).orderBy(lit(1))
df_row = df.select("*").withColumn("row_num", row_number().over(wd))
display(df_row)

# COMMAND ----------

df.rdd.getNumPartitions()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 10 - How to read data from multiple source and write into data lake or delta lake?

# COMMAND ----------

# MAGIC %fs ls dbfs:/FileStore/tables/

# COMMAND ----------

dbfs:/FileStore/tables/Student.csv -- today
dbfs:/FileStore/tables/Student.json      -- tomorrow
dbfs:/FileStore/tables/Student.parquet   -- day after tomorrow
dbfs:/FileStore/tables/Student.avro
dbfs:/FileStore/tables/Student.orc

# COMMAND ----------

dbutils.fs.ls("dbfs:/FileStore/tables/")[0][1]

# COMMAND ----------

def f_check_file(input_path):
    try:
        file_type = dbutils.fs.ls(f'{input_path}')[0][1].split(".")[1]
        return file_type
    except Exception as err:
        print("error is occured", str(err))

# COMMAND ----------

print(f_check_file("dbfs:/FileStore/tables/"))

# COMMAND ----------

# we can also check file path with file type

def f_check_file(input_path):
    try:
        file_type, file_path, file_name = dbutils.fs.ls(f'{input_path}')[0][1].split(".")[1],dbutils.fs.ls(f'{input_path}')[0][0],dbutils.fs.ls(f'{input_path}')[0][1].split(".")[0]
        return file_type, file_path, file_name
    except Exception as err:
        print("error is occured", str(err))

# COMMAND ----------

print(f_check_file("dbfs:/FileStore/tables/"))

# COMMAND ----------

df = spark.read.format("json").option("multiline", True).load(f_check_file("dbfs:/FileStore/tables/")[1])
df.show()

# COMMAND ----------

# create schema
def f_schema():
    from pyspark.sql.types import StructType, StructField, StringType, IntegerType
    return StructType([StructField("ID", IntegerType()),\
                       StructField("Name", StringType()),\
                       StructField("Age", StringType())
                       ])

# COMMAND ----------

def f_read_write_delta(input_file):
    try:
        file_type, file_path, file_name = f_check_file(input_file)
        if file_type == "json":
            df = spark.read.format(file_type).option("multiline", True).schema(f_schema()).load(file_path)
        elif file_type == "csv":
            df = spark.read.format(file_type).option("header", True).schema(f_schema()).load(file_path)
        df.write.mode("overwrite").save(f"/dbfs:/FileStore/tables_output/{file_name}")
    except Exception as err:
        print("An error occurred:", str(err))


# COMMAND ----------

f_read_write_delta("dbfs:/FileStore/tables_output/")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/dbfs:/FileStore/tables_output/Student`

# COMMAND ----------

