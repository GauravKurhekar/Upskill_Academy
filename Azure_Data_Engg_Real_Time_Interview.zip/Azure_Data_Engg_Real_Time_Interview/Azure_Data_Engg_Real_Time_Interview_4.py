# Databricks notebook source
# MAGIC %md
# MAGIC ### This notes contain 1 to 60 problems

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 1- Convert string to upper?

# COMMAND ----------

string = 'gaurav kurhekar'
output = string.upper()
print(output)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 2-Convert string to lower?

# COMMAND ----------

string = 'gaurav kurhekar'
output = string.lower()
print(output)

# COMMAND ----------

number = range(10)
for i in number:
    print(i)
OR

for i in range(1,20):
  print(i)

# COMMAND ----------

number = range(5, 50,10)  # Start, stop, step
for i in number:
    print(i)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 3- Write program to add two numbers using add() function?

# COMMAND ----------

def add (a,b):
    return a+b
add(1,3)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 4- Write program to add two numbers using sum() function?

# COMMAND ----------

def sum(a,b):
    return a+b
sum(34,34)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 5- Write a program to make string as upper, lower, capitalize, center, replace and strip?

# COMMAND ----------

s = "hello"
print(s.upper())
print(s.lower())
print(s.capitalize())
print(s.center(6))
print(s.replace('l', 'ell'))
print('   world  '.strip())

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 6- Write a program to open and read the file?

# COMMAND ----------

f = open("demofile.txt", "r")
print(f.readline())
f.close()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 7- Write a python program to swap two number

# COMMAND ----------

a = int(input("enter first number"))
b = int(input("enter second number"))
temp = a
a = b
b = temp
print("value of a:", a)
print('value of b:', b)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 8- Convert the list into set and convert set back again into list?

# COMMAND ----------

lst = [1, 2, 3, 3, 4, 4, 5, 5, 5, 6, 7, 8, 8]
convert_set = set(lst)
convert_back_to_list = list(convert_set)

print("original list:", lst)
print("new list:", convert_back_to_list)


# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 9- Write python program to convert list into unique list?

# COMMAND ----------

my_list = [1, 2, 3, 3, 4, 4, 5, 5, 5, 6, 7, 8, 8]
unique_list = list(set(my_list))
print(unique_list)


# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 10- Write a program to reverse the list?

# COMMAND ----------

L = [1, 2, 3, 4, 5]
reverse_list = L[::-1]
print("original list:",L)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 11- How to create RDD?

# COMMAND ----------

data = [1,2,3,4,5]
rdd = spark.sparkContext.parallelize(data)

# COMMAND ----------

data = [(1, 'Gaurav'), (2, 'Kurhekar')]
rdd = spark.sparkContext.parallelize(data)
print(rdd.collect())

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 12- Write simple map program?

# COMMAND ----------

rdd = sc.parallelize([1,2,3])
rdd_map = rdd.map(lambda x: x*2)
rdd_map.collect()


# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 13- Write simple flatMap program?

# COMMAND ----------

rdd = sc.parallelize([1,2,3])
rdd_flatmap = rdd.flatMap(lambda x: [x, x*2, x*3])
rdd_flatmap.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 14- How to convert dictionary into list, my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}
# MAGIC to convert a dictionary into a list of tuples where each tuple contains both the key and the value, you can use the **items()** method of the dictionary.

# COMMAND ----------

my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

# Convert dictionary to a list of tuples
list_of_tuples = list(my_dict.items())

print(list_of_tuples)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 15- Convert Dictionary: Keys to a List:

# COMMAND ----------

my_dict = {'a': 1, 'b': 2, 'c': 3}
keys_list = list(my_dict.keys())
print(keys_list)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 17- Convert Dictionary: Values to a List:

# COMMAND ----------

my_dict = {'a': 1, 'b': 2, 'c': 3}
items_list = list(my_dict.values())
print(items_list)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 18- Convert Dictionary: Key-Value Pairs to a List of Tuples:

# COMMAND ----------

my_dict = {'a': 1, 'b': 2, 'c': 3}
items_list = list(my_dict.items())
print(items_list)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 19-How to combine many lists to form a PySpark DataFrame?

# COMMAND ----------

# Hint: For Creating DataFrame from multiple lists, first create an RDD (Resilient Distributed Dataset) 
# from those lists and then convert the RDD to a DataFrame.
# use zip() method to join the two list

# Define your lists
list1 = ["a", "b", "c", "d"]
list2 = [1, 2, 3, 4]

# Create an RDD from the lists and convert it to a DataFrame
rdd = spark.sparkContext.parallelize(list(zip(list1, list2)))
df = rdd.toDF(["Column1", "Column2"])

# Show the DataFrame
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 20- How to convert the first character of each element in a series to uppercase?

# COMMAND ----------

# Suppose you have the following DataFrame
data = [("john",), ("alice",), ("bob",)]
df = spark.createDataFrame(data, ["name"])
df.show()

# COMMAND ----------

from pyspark.sql.functions import initcap

# Convert the first character to uppercase
df = df.withColumn("name", initcap(df["name"]))

df.show()

df = df.withColumn('name', initcap(df['name']))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 21- How to join two columns where columns position are different and columns numbers also not match
# MAGIC we can do this by using unionByName() allowMissingColumn = True
# MAGIC
# MAGIC unionByName() lets you merge/union two different column with different schemas
# MAGIC
# MAGIC you have to mandatorily mention allowMissingColumns = True so that it will replace Null whatever the column miss

# COMMAND ----------

list_a=[['2020','Dhanush','Karnan']]
list_b=[['Vijay','2020','Master']]

# COMMAND ----------

df1=spark.createDataFrame(list_a,('year','cast','movie'))
df2=spark.createDataFrame(list_b,('cast','year','movie'))

# COMMAND ----------

df2=df2.select('year','cast','movie')
df1.union(df2).show()

# COMMAND ----------

df1.unionByName(df2,allowMissingColumns=True).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 22- How to configure spark memory?

# COMMAND ----------

from pyspark.sql import SparkSession
#spark = SparkSession.builder\
#.master("local".format(2))\
#.appName("Localspark")\
#.getOrCreate()

n_cpu = 2
spark = SparkSession.builder.appName('localSpark')\
.master('local[{}]'.format(n_cpu))\
.config("spark.driver.memory", "1g")\
.config('spark.executor.memory', '2g')\
.config('spark.executor.cores', '3')\
.config('spark.cores.max', '3')\
.getOrCreate()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 23- How to create complex column using StructType, StructField, StringType, IntegerType?

# COMMAND ----------

## creating complex column

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

data = [(1,('Gaurav', 'Kurhekar'), 30000), (2, ('Vaidehi', 'Kurhekar'), 40000)]

structName = StructType([\
                        StructField('firstName', StringType()), \
                        StructField('lastName', StringType()) 
                        ])

schema = StructType([StructField(name = 'id', dataType = IntegerType()), \
                     StructField(name = 'name', dataType = structName), \
                     StructField(name = 'salary', dataType = IntegerType())])
df = spark.createDataFrame(data, schema)
df.show()
display(df)
df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 24- Array type column in pyspark?

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType

data = [('abc', [1,2,3]), ('mno', [4,5,6]), ('xyz', [7,8,9])]
schema = StructType([ \
                        StructField('id', StringType()),\
                        StructField('numbers', ArrayType(IntegerType())) 
                   ])
df = spark.createDataFrame(data, schema)
df.show()
df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 25- Example of nested column?
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import lit
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

data = [('Gaurav', 'Male', 5000, ('black', 'brown')), ('Vaidehi', 'Female', 4000, ('black', 'silver'))]
propType = StructType([ \
                        StructField('Hair', StringType()),\
                        StructField('Eye', StringType())        

                      ])

schema = StructType([\
                    StructField('Name', StringType()),\
                    StructField('Gender', StringType()), \
                    StructField('Salary', IntegerType()), \
                    StructField('Props', propType)                
                    ])

df = spark.createDataFrame(data, schema)
print(df)
df.show()
df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 26- What are the multiple ways to access the columns?

# COMMAND ----------

from pyspark.sql.functions import lit

data = [('Gaurav', 'Male', 5000), ('Vaidehi', 'Female', 4000)]
schema = ('Name', 'Gender', 'Salary')
df = spark.createDataFrame(data, schema)
df.show()

# COMMAND ----------

## multiple ways to access the column
# 1st method
df.select(df.Name).show()

# 2nd method
df.select(df['Name']).show()

# 3rd method
from pyspark.sql.functions import col
df.select(col('Name')).show()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 27- How to access nested column i.e under Props there is Hair and Eye nested columns?
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import lit
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

data = [('Gaurav', 'Male', 5000, ('black', 'brown')), ('Vaidehi', 'Female', 4000, ('black', 'silver'))]
propType = StructType([ \
                        StructField('Hair', StringType()),\
                        StructField('Eye', StringType())        

                      ])

schema = StructType([\
                    StructField('Name', StringType()),\
                    StructField('Gender', StringType()), \
                    StructField('Salary', IntegerType()), \
                    StructField('Props', propType)                
                    ])

df = spark.createDataFrame(data, schema)
print(df)
df.show()
df.printSchema()

# COMMAND ----------

# 1- how to access nested column i.e under Props there is Hair and Eye nested columns
df.select(df.Props.Eye).show()

# 2- by using index item
df.select(df['Props.Eye']).show()

# 3- by using col function, Remember - first we want to import col function()
from pyspark.sql.functions import col


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 28 - How select function work in pyspark?

# COMMAND ----------

from pyspark.sql.functions import col

data = [(1,'Gaurav', 'Male', 5000),(2,'Vaidehi', 'Female', 4000)]
schema = ['id','name', 'gender', 'salary']
df = spark.createDataFrame(data,schema)
df.select('id', 'name').show()
df.select(df.id, df.name).show()
df.select(df['id'], df['name']).show()

# using col() function

df.select(col('id'), col('name')).show()
df.select(['id', 'name']).show()

# * is used to select all the column
df.select('*').show()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 29- What is join() function in PySpark | inner, left, right, full Joins?
# MAGIC Syntax 
# MAGIC result_df = df1.join(df2, on="common_column_name", how="join_type") 

# COMMAND ----------

# Sample data
data1 = [(1, 'Alice'), (2, 'Bob'), (3, 'Charlie')]
data2 = [(1, 25), (2, 30), (4, 28)]

# Create DataFrames
df1 = spark.createDataFrame(data1, ["id", "name"])
df2 = spark.createDataFrame(data2, ["id", "age"])

# Perform an inner join
inner_join_result = df1.join(df2, on="id", how="inner")
inner_join_result.show()

# Perform a left join
left_join_result = df1.join(df2, on="id", how="left")
left_join_result.show()

# Perform a right join
right_join_result = df1.join(df2, on="id", how="right")
right_join_result.show()

# Perform an outer join
outer_join_result = df1.join(df2, on="id", how="outer")
outer_join_result.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 30- Write a python program to check whether given maid id's are valid or not?

# COMMAND ----------

import re
s = 'gauravkurhekar04@gmail.com'
m = re.fullmatch('\w[a-zA-Z0-9_.]*@(gmail|rediffmail)[.]com+',s)
if m != None:
    print("Valid mail id")
else:
    print("Invalid email id")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 31- Write a program to find sum from 0 to 1000?

# COMMAND ----------

# sum of 0 to 1000
sum = 0
for i in range(1, 1001):
    sum = sum +i                # OR sum+=i
print(sum)

# sum of 0 to 100
sum = 0
for i in range(1, 101):
    sum = sum + i
print(sum)

# COMMAND ----------

sum_result = sum(range(1001))
print(f"The sum of numbers from 0 to 1000 is {sum_result}.")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 32- Program about playing with string?

# COMMAND ----------

s = "hello"
# Capitalize a string; prints "Hello"
print(s.capitalize())  

# Convert a string to uppercase; prints "HELLO"
print(s.upper())       

# Right-justify a string, padding with spaces; prints "  hello"
print(s.rjust(7))

# Center a string, padding with spaces; prints " hello "
print(s.center(7)) 

# Replace all instances of one substring with another; # prints "he(ell)(ell)o"
print(s.replace('l', '(ell)'))  
                                
# Strip leading and trailing whitespace; prints "world"
print('  world '.strip())  

# COMMAND ----------

# MAGIC %md
# MAGIC #### Question 33- Python program to add two numbers?

# COMMAND ----------

#Creating function with arguments
def sum_of(a,b):
  sum = a + b
  print("Sum of {} and {} is {}". format(a, b, sum))

# Calling a function with parameters
sum_of(5,6)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Question 34- Python Program for factorial of a number?

# COMMAND ----------

num = 10

def fact(n):
  """
  Python Program for factorial of a number
  Arguemnts:
  n : any number to generate Factorial
  """
  if n < 0: 
    return 0
  elif n == 0 or n == 1:
    return 1
  else:
    fact = 1
    while(n > 1):
      fact = fact * n
      n = n -1
    return fact
  
print("Fact of", num, "is :", fact(num))

# COMMAND ----------

# MAGIC %md
# MAGIC ####Question 35- Python Program for simple interest?

# COMMAND ----------



# SI = (P * R * T) / 100
def simple_interest(P, R, T):
    print("The principal amount is:", P)
    print("The rate of interest is:", R)
    print("The time in years is:", T)
    
    SI = (P * R * T)/100
    
    print("Simple Interest is :", SI)
    return SI


# COMMAND ----------

# MAGIC %md
# MAGIC ####Question 36- Python Program to find area of a circle?

# COMMAND ----------


# Area of circle = pi * r**2

def area_of_circle(r):
    pi = 3.14
    area = pi*(r)**2
    return area

radius = 55
print("Area of circle : ", area_of_circle(radius))


# COMMAND ----------

# MAGIC %md
# MAGIC ####Question 37- Python program to print all Prime numbers in an Interval?

# COMMAND ----------


# Given two positive integer start and end. The task is to write a Python program to
# print all Prime numbers in an Interval.

def find_prime_numbers(a, b):
    for num in range(a, b+1):
        if num > 1:
            for i in range(2, num):
                if (num % i) == 0:
                    break
            else:
                print("{} is a prime number.".format(num))



# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 38- Program to print ASCII Value of a character?/

# COMMAND ----------

# For this problem we'll use ord() function in Python accepts a string of length 1 as an argument and returns
# the unicode code point representation of the passed argument.

char = 'R'

print("ASCII value of input character *",char,"* is:", ord(char))

# COMMAND ----------

# MAGIC %md
# MAGIC ####Question 39- Python Program for Sum of squares of first n natural numbers?

# COMMAND ----------

def sum_of_square(n) : 
    sum = 0
    for i in range(1, n+1) : 
        sum = sum + (i * i)       
    return sum 
  
n =55
sum_of_square(n)

# COMMAND ----------

sum_of_squares = 0
for i in range(1, 56):
    sum_of_squares += i**2

print("Sum of squares for the first 55 natural numbers:", sum_of_squares)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 40- Python Program for cube sum of first n natural numbers?

# COMMAND ----------


def sum_of_cube(n):
    sum = 0
    
    for i in range(0, n+1):
        sum = sum + (i*i*i)
        
    return sum

num = 44
sum_of_cube(num)

# COMMAND ----------

sum = 0
for i in range(1, 45):
    sum+=i**3
print(sum)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 41- Python code to demonstrate star pattern? 

# COMMAND ----------

rows =5
for i in range(rows+1): 
    for j in range(i):    
        print("* ",end="") 
    print("\r") 

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 42- Number Pattern in Python?

# COMMAND ----------

rows = 5 
for i in range(rows+1):  
    for j in range(i):  
        print(i, end=" ")  
    print("\r")  

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 43- Write a program to print factorial?
# MAGIC factorial means= 3= 3*2*1=6, 5=5*4*3*2*1=120,  4=4*3*2*1=24 

# COMMAND ----------

num = 5
factorial = 1
for i in range(1, num + 1):
    factorial *= i
print(f"The factorial of {num} is {factorial}.")

# COMMAND ----------

def factorial(x):
    if x ==1:
        return 1
    else:
        return x * factorial(x-1)
print(factorial(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 44 - print todays datetime?

# COMMAND ----------

import datetime
x = datetime.datetime.now()
print(x)
print(x.year)
print(x.month)
print(x.day)
print(x.strftime('%B'))
print(x.strftime('%b'))
print(x.strftime('%m'))
print(x.strftime('%D'))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 45- Write a program to find even and odd number?

# COMMAND ----------

x = int(input('Enter any number'))
if x % 2 == 0:
    print('Even')
else:
    print('odd')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 46- Write a program to count a character in string?

# COMMAND ----------

a = input('Enter the string: ')
count = 0
for char in a:
    count = count + 1
print('The number of characters is:', count)

# COMMAND ----------

String = 'Hello My name is Gaurav and wife name is Vaidehi'
print("the count of i in string is:", String.count('i'))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 47- Write a Python program to swap two variables?

# COMMAND ----------

# SOLUTION - 3 - Write a Python program to swap two variables.
a = 30
b = 20
temp = a
a = b
b = temp
print(a)
print(b)

# COMMAND ----------

x = 9
y = 5
x, y = y, x
print('value of x variable is:', x)
print('value of y variable is:', y)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 48- Write a Python program to remove the first item from a specified list?

# COMMAND ----------

color = ["Red", "Black", "Green", "White", "Orange"]
del color[0]
print(color)

# SOLUTION - 2
new_color = color[1:]
print(new_color)

# SOLUTION - 3
color.remove("Red")
print(color)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 49 -Write a Python program to reverse words in a string?

# COMMAND ----------

string = 'My name is Gaurav Kurhekar'
words = string.split()          # split the string
words.reverse()                 # reverse the string
result = " ".join(words)        # join the string
print(result)


# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 50 - Write a Python program to print the index of a character in a string?

# COMMAND ----------


str1 = "GAURAV"
for index, char in enumerate(str1):
    print("Current character", char, "position at", index )

#for index, char in enumerate(str1):: This is a for loop that iterates through each character in the string str1. The enumerate() function is used to get both the index and the character at each iteration.

#print("Current character", char, "position at", index): This line prints the current character and its position (index) in the string for each iteration of the loop. The variables char and index hold the character and its corresponding index, respectively, from the enumerate() function.



# COMMAND ----------

str1 = "GAURAV"
for index in enumerate(str1):
    print("position at", index )

# The enumerate() function is used to get both the index and the character at each iteration.

# COMMAND ----------

str1 = "GAURAV"
for i in enumerate(str1):
    print("position at", i)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 51- Write a Python program to lowercase the first 4 characters in a string?

# COMMAND ----------

str1 = 'GAURAV KURHEKAR'
print(str1[:4].lower() + str1[4:])

# SOLUTION 2 FOR UPPER CASE()
str1 = 'gaurav kurhekar'
print(str1[:4].upper() + str1[4:])

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 52- Write a Python program to swap commas and dots in a string?

# COMMAND ----------

string = "32.054,23"
string = string.replace(",", ";").replace(".", ",").replace(";", ".")
print(string)

#This program will replace all commas with semicolons, then all dots with commas, and finally all semicolons with dots.
# need to take 3rd variable like colon(;) to swap comma and dot

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 53- Write a Python program to convert JSON data to Python object?
# MAGIC This program will convert the JSON data json_data to a Python object using the json.loads() function.

# COMMAND ----------

import json

json_data = '{ "Name":"Gaurav", "Profession":"Data Engineer", "Age":6 }'
python_obj = json.loads(json_data)

print(python_obj)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 58 - Write a Python program to convert Python object to JSON data?
# MAGIC This program will convert the Python object python_obj to JSON data using the json.dumps() function

# COMMAND ----------


import json

python_obj = { "Name":"Gaurav", "Profession":"Data Engineer", "Age":6 }
json_data = json.dumps(python_obj)

print(json_data)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 59- Write a Python program to sum all the items in a list? 

# COMMAND ----------

L1 = [1,2,3,4,5]
print(sum(L1))

# SOLUTION 2
my_list = [1, 2, 3, 4, 5]

total = sum(my_list)

print("The sum of all the items in the list is:", total)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 60- Write a Python program to multiply all the items in a list?

# COMMAND ----------

# By using for loop
my_list = [1, 2, 3, 4, 5]
total = 1
for i in my_list:
    total *= i

print("The product of all the items in the list is:", total)

# COMMAND ----------

# SOLUTION 2 - By using function
def multiply_list(items):
    total = 1
    for x in items:
        total *= x
    return total
print(multiply_list([1, 2, 3, 4, 5]))

# COMMAND ----------

# SOLUTION 3 - By using  lambda function along with the reduce() function from the functools module to multiply all the items in a list.
from functools import reduce

my_list = [1, 2, 3, 4, 5]
result = reduce(lambda x, y: x * y, my_list)
print("The product of all items in the list:", result)