-- Databricks notebook source
-- MAGIC %md
-- MAGIC ##### Question 27- Write a SQL query for a report that provides the pairs (actor_id, director_id) ,where the actor have cooperated with the director at least 3 times.
-- MAGIC
-- MAGIC * | actor_id | director_id | timestamp |
-- MAGIC * | 1 | 1 | 0 |
-- MAGIC * | 1 | 1 | 1 |
-- MAGIC * | 1 | 1 | 2 |
-- MAGIC * | 1 | 2 | 3 |
-- MAGIC * | 1 | 2 | 4 |
-- MAGIC * | 2 | 1 | 5 |
-- MAGIC * | 2 | 1 | 6 

-- COMMAND ----------

select actor_id, director_id from table_name
group by actor_id, director_id
having count(*)>3

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 28- Write an SQL query that reports all product names of the products in the Sales table along with their selling year and price.

-- COMMAND ----------

Sales table:
+---------+------------+------+----------+-------+
| sale_id | product_id | year | quantity | price |
+---------+------------+------+----------+-------+
| 1 | 100 | 2008 | 10 | 5000 |
| 2 | 100 | 2009 | 12 | 5000 |
| 7 | 200 | 2011 | 15 | 9000 |
+---------+------------+------+----------+-------+

Product table:
+------------+--------------+
| product_id | product_name |
+------------+--------------+
| 100 | Nokia |
| 200 | Apple |
| 300 | Samsung |
+------------+--------------+

-- COMMAND ----------

select p.product_name, s.year,  s.price from product as p
join sales as s
on p.product_id = s.product_id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 29- Write an SQL query that reports the total quantity sold for every product id.

-- COMMAND ----------

Sales table:
+---------+------------+------+----------+-------+
| sale_id | product_id | year | quantity | price |
+---------+------------+------+----------+-------+
| 1 | 100 | 2008 | 10 | 5000 |
| 2 | 100 | 2009 | 12 | 5000 |
| 7 | 200 | 2011 | 15 | 9000 |
+---------+------------+------+----------+-------+
Product table:
+------------+--------------+
| product_id | product_name |
+------------+--------------+
| 100 | Nokia |
| 200 | Apple |
| 300 | Samsung |
+------------+--------------+

-- COMMAND ----------

SELECT product_id, sum(quantity) AS total_quantity FROM Sales
GROUP BY product_id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 30- Write an SQL query that selects the product id, year, quantity, and price for the first year of every product sold.

-- COMMAND ----------

Sales table:
+---------+------------+------+----------+-------+
| sale_id | product_id | year | quantity | price |
+---------+------------+------+----------+-------+
| 1 | 100 | 2008 | 10 | 5000 |
| 2 | 100 | 2009 | 12 | 5000 |
| 7 | 200 | 2011 | 15 | 9000 |
+---------+------------+------+----------+-------+
Product table:
+------------+--------------+
| product_id | product_name |
+------------+--------------+
| 100 | Nokia |
| 200 | Apple |
| 300 | Samsung |
+------------+--------------+

-- COMMAND ----------

SELECT s.product_id, s.year, s.quantity, s.price
FROM sales_table44 s
JOIN (
    SELECT product_id, MIN(year) AS first_year
    FROM sales_table44
    GROUP BY product_id
) AS t ON s.product_id = t.product_id AND s.year = t.first_year;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 31- Write an SQL query that reports the average experience years of all the employees for each project, rounded to 2 digits.

-- COMMAND ----------

Project table:
+-------------+-------------+
| project_id | employee_id |
+-------------+-------------+
| 1 | 1 |
| 1 | 2 |
| 1 | 3 |
| 2 | 1 |
| 2 | 4 |
+-------------+-------------+
Employee table:
+-------------+--------+------------------+
| employee_id | name | experience_years |
+-------------+--------+------------------+
| 1 | Khaled | 3 |
| 2 | Ali | 2 |
| 3 | John | 1 |
| 4 | Doe | 2 |
+-------------+--------+------------------+

-- COMMAND ----------

SELECT
p.project_id, ROUND(AVG(e.experience_years),2) average_years
FROM
Project p JOIN Employee e ON p.employee_id = e.employee_id
GROUP BY
p.project_id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 32- from above table, Write an SQL query that reports all the projects that have the most employees.

-- COMMAND ----------

SELECT project_id FROM Project
GROUP BY project_id
HAVING COUNT(employee_id) = (SELECT COUNT(employee_id)
FROM Project
GROUP BY project_id
ORDER BY COUNT(employee_id) DESC LIMIT 1)


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 33- Write an SQL query that reports the best seller by total sales price?

-- COMMAND ----------

CREATE TABLE product_table55 (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    unit_price DECIMAL(10, 2)
);
INSERT INTO product_table55 (product_id, product_name, unit_price) VALUES
(1, 'S8', 1000),
(2, 'G4', 800),
(3, 'iPhone', 1400);
select * from product_table55;

-- COMMAND ----------

CREATE TABLE salestable55 (
    seller_id INT,
    product_id INT,
    buyer_id INT,
    sale_date DATE,
    quantity INT,
    price int
);
INSERT INTO salestable55 (seller_id, product_id, buyer_id, sale_date, quantity, price) VALUES
(1, 1, 1, '2019-01-21', 2, 2000),
(1, 2, 2, '2019-02-17', 1, 800),
(2, 2, 3, '2019-06-02', 1, 800),
(3, 3, 4, '2019-05-13', 2, 2800);
select * from salestable55;

-- COMMAND ----------

SELECT seller_id, SUM(price) AS total_sales_price
FROM salestable55
GROUP BY seller_id
ORDER BY total_sales_price DESC

-- COMMAND ----------

CREATE TABLE enrollment_table22 (
    student_id INT,
    course_id INT,
    grade INT
);

INSERT INTO enrollment_table22 (student_id, course_id, grade) VALUES
(1, 1, 90),
(1, 2, 99),
(2, 2, 95),
(2, 3, 95),
(3, 1, 80),
(3, 2, 75),
(3, 3, 82);
select * from enrollment_table22;

-- COMMAND ----------

SELECT student_id, MIN(course_id) as course_id, grade FROM enrollment_table22
WHERE (student_id, grade) IN
(SELECT student_id, MAX(grade) FROM enrollment_table22
GROUP BY student_id) GROUP BY student_id, grade
ORDER BY student_id;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 34- Write an SQL query that reports the number of posts reported yesterday for each report reason. Assume today is 2019-07-05.

-- COMMAND ----------

CREATE TABLE action_table1 (
    user_id INT,
    post_id INT,
    action_date DATE,
    action VARCHAR(10),
    extra VARCHAR(50)
);

INSERT INTO action_table1 (user_id, post_id, action_date, action, extra) VALUES
(1, 1, '2019-07-01', 'view', null),
(1, 1, '2019-07-01', 'like', null),
(1, 1, '2019-07-01', 'share', null),
(2, 4, '2019-07-04', 'view', null),
(2, 4, '2019-07-04', 'report', 'spam'),
(3, 4, '2019-07-04', 'view', null),
(3, 4, '2019-07-04', 'report', 'spam'),
(4, 3, '2019-07-02', 'view', null),
(4, 3, '2019-07-02', 'report', 'spam'),
(5, 2, '2019-07-04', 'view', null),
(5, 2, '2019-07-04', 'report', 'racism'),
(5, 5, '2019-07-04', 'view', null),
(5, 5, '2019-07-04', 'report', 'racism');
select * from action_table1;

-- COMMAND ----------

--Write an SQL query that reports the number of posts reported yesterday for each report reason. Assume today is 2019-07-05.
select extra as report_reason, count(distinct post_id) as report_count
from action_table1
where action_date = '2019-07-04' and action = 'report'
group by extra;

-- COMMAND ----------

SELECT extra AS report_reason, COUNT(DISTINCT post_id) AS num_reports
FROM action_table1
WHERE action = 'report'
  AND DATEDIFF('2019-07-05', action_date) = 1
GROUP BY extra;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 35- Write an SQL query to find the daily active user count for a period of 30 days ending 2019-07-27 inclusively. A user was active on some day if he/she made at least one activity on that day.

-- COMMAND ----------

Activity table:
+---------+------------+---------------+---------------+
| user_id | session_id | activity_date | activity_type |
+---------+------------+---------------+---------------+
| 1 | 1 | 2019-07-20 | open_session |
| 1 | 1 | 2019-07-20 | scroll_down |
| 1 | 1 | 2019-07-20 | end_session |
| 2 | 4 | 2019-07-20 | open_session |
| 2 | 4 | 2019-07-21 | send_message |
| 2 | 4 | 2019-07-21 | end_session |
| 3 | 2 | 2019-07-21 | open_session |
| 3 | 2 | 2019-07-21 | send_message |
| 3 | 2 | 2019-07-21 | end_session |
| 4 | 3 | 2019-06-25 | open_session |
| 4 | 3 | 2019-06-25 | end_session |
+---------+------------+---------------+---------------+

-- COMMAND ----------

select activity_date as day, count(distinct user_id) as active_users
from Activity
where activity_date between '2019-06-28' and '2019-07-27'
group by day;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 36- Write an SQL query to find all the authors that viewed at least one of their own articles, sorted in ascending order by their id.

-- COMMAND ----------

Views table:
+------------+-----------+-----------+------------+
| article_id | author_id | viewer_id | view_date |
+------------+-----------+-----------+------------+
| 1 | 3 | 5 | 2019-08-01 |
| 1 | 3 | 6 | 2019-08-02 |
| 2 | 7 | 7 | 2019-08-01 |
| 2 | 7 | 6 | 2019-08-02 |
| 4 | 7 | 1 | 2019-07-22 |
| 3 | 4 | 4 | 2019-07-21 |
| 3 | 4 | 4 | 2019-07-21 |
+------------+-----------+-----------+------------+

-- COMMAND ----------

select distinct author_id as id from table_name
where author_id = viewer_id 
order by author_id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 37- Write an SQL query to find all the people who viewed more than one article on the same date, sorted in ascending order by their id.

-- COMMAND ----------

CREATE TABLE view_table22 (
    article_id INT,
    author_id INT,
    viewer_id INT,
    view_date DATE
);

INSERT INTO view_table22 (article_id, author_id, viewer_id, view_date) VALUES
(1, 3, 5, '2019-08-01'),
(1, 3, 6, '2019-08-02'),
(2, 7, 7, '2019-08-01'),
(2, 7, 6, '2019-08-02'),
(4, 7, 1, '2019-07-22'),
(3, 4, 4, '2019-07-21'),
(3, 4, 4, '2019-07-21');
select * from view_table22;

-- COMMAND ----------

SELECT DISTINCT viewer_id AS id FROM view_table22
GROUP BY viewer_id, view_date
HAVING count(DISTINCT article_id)>1 ORDER BY 1


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 38- Write an SQL query to find the percentage of immediate orders in the first orders of all customers, rounded to 2 decimal places.

-- COMMAND ----------

CREATE TABLE delivery_table22 (
    delivery_id INT,
    customer_id INT,
    order_date DATE,
    customer_pref_delivery_date DATE
);

INSERT INTO delivery_table22 (delivery_id, customer_id, order_date, customer_pref_delivery_date) VALUES
(1, 1, '2019-08-01', '2019-08-02'),
(2, 2, '2019-08-02', '2019-08-02'),
(3, 1, '2019-08-11', '2019-08-12'),
(4, 3, '2019-08-24', '2019-08-24'),
(5, 3, '2019-08-21', '2019-08-22'),
(6, 2, '2019-08-11', '2019-08-13'),
(7, 4, '2019-08-09', '2019-08-09');
select * from delivery_table22;

-- COMMAND ----------

--Write an SQL query to find the percentage of immediate orders in the first orders of all customers, rounded to 2 decimal places.

SELECT ROUND(SUM(CASE WHEN order_date = customer_pref_delivery_date THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS percentage_immediate_orders
FROM delivery_table22;

-- COMMAND ----------

SELECT ROUND(AVG(CASE WHEN order_date = customer_pref_delivery_date THEN 1 ELSE 0 END) * 100, 2) AS percentage_immediate_orders
FROM delivery_table22;