# Databricks notebook source
# MAGIC %md
# MAGIC ##### this notebook contain Incremental load question with audit log activities using delta lake and slowly changing dimension by Raja's data engineer

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Pyspark merge(upsert) statement by Raja's data engineer

# COMMAND ----------

Merge is also called as upsert operation.
What is upsert/merge operation – when we have to target table based on incoming source table, we have to compare target and source data, if there is match found between them then target data will get updated based on source, 
If there is no match found in target table which means in source we receive new data new record will be inserted into target table.
When there was only data lake, then we were not able to perform any merge operation.
After introducing delta lake by databricks, merge operation comes into picture.


# COMMAND ----------

# step 1 - create dataframe with some data
from pyspark.sql.types import *
from pyspark.sql.functions import *

schema = StructType([
    StructField("empid", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("city", StringType(), True),
    StructField("country", StringType(), True),
    StructField("contactno", IntegerType(), True)
])

data = [(1, "Gaurav", "Akola", "India", 8087387)]

# Create the DataFrame with the specified schema
df = spark.createDataFrame(data=data, schema=schema)

# Show the DataFrame
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### step 2- create delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table Employee1
# MAGIC (
# MAGIC   empid int,
# MAGIC   name string,
# MAGIC   city string,
# MAGIC   country string,
# MAGIC   contactno int
# MAGIC )
# MAGIC using delta
# MAGIC location "/FileStore/delta_tables/delta_merge11"

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Employee1

# COMMAND ----------

# MAGIC %md
# MAGIC #### Method 1 - Spark SQL

# COMMAND ----------

# step 3 - create temp view
# our source and target data should be in table format to work on sql thats why we are converting df into tempview in sql
df.createOrReplaceTempView("source_view1")

# COMMAND ----------

# MAGIC %sql -- source_view is source table and employee is target table
# MAGIC select * from source_view1

# COMMAND ----------

# MAGIC %sql -- step 4 - create merge statement to merge two tables
# MAGIC -- when matched then update, when not matched then insert
# MAGIC MERGE INTO Employee1 as target
# MAGIC USING source_view1 as source
# MAGIC   ON target.empid = source.empid
# MAGIC   WHEN MATCHED 
# MAGIC THEN UPDATE SET
# MAGIC   target.name = source.name,
# MAGIC   target.city = source.city,
# MAGIC   target.country = source.country,
# MAGIC   target.contactno = source.contactno
# MAGIC WHEN NOT MATCHED THEN
# MAGIC INSERT (empid, name, city, country, contactno) values(empid, name, city, country, contactno)

# COMMAND ----------

# step 5 - insert few records to check how insert and update work
data = [(1, "Gaurav", "Pune", "India", 8087387),(2, "Vaidehi", "Pune", "India", 702026)]

# Create the DataFrame with the specified schema
df = spark.createDataFrame(data=data, schema=schema)

# Show the DataFrame
df.show()

# COMMAND ----------

# step 6 - create temp view to convert dataframe into sql table, repeat step 3
df.createOrReplaceTempView("source_view1")

# COMMAND ----------

# MAGIC %sql  -- step 7 - repeat merge statement to merge two tables of step 4   
# MAGIC -- when matched then update, when not matched then insert
# MAGIC
# MAGIC MERGE INTO Employee1 as target
# MAGIC USING source_view1 as source
# MAGIC   ON target.empid = source.empid
# MAGIC   WHEN MATCHED 
# MAGIC THEN UPDATE SET
# MAGIC   target.name = source.name,
# MAGIC   target.city = source.city,
# MAGIC   target.country = source.country,
# MAGIC   target.contactno = source.contactno
# MAGIC WHEN NOT MATCHED THEN
# MAGIC INSERT (empid, name, city, country, contactno) values(empid, name, city, country, contactno)

# COMMAND ----------

# MAGIC %sql -- check if record is inserted and updated in first table i.e Employee1 table
# MAGIC select * from Employee1

# COMMAND ----------

## 7 step process in Pyspark SQL
step 1 - create dataframe with some data -- source table
step 2 - convert dataframe into temp view to work on tables in sql
step 3 - create delta table -- target table
step 4 - create merge statement to merge two tables, data merges successfully
step 5 - insert few records again by creating dataframe to check how insert and update work
step 6 - convert this dataframe into sql table, repeat step 2
step 7 - repeat merge statement to merge two tables of step 4

# COMMAND ----------

# MAGIC %md
# MAGIC ##### How to perform merge(upsert) operation using pyspark
# MAGIC

# COMMAND ----------

# to perform merge operation using pyspark, we need to keep data in dataframe, no need to convert into tempView
# step 1 - create dataframe with some data
data = [(3, "Monu", "Akola", "India", 866878),(2, "Vaidehi", "Akola", "India", 702026)]

# Create the DataFrame with the specified schema
df = spark.createDataFrame(data=data, schema=schema)

# Show the DataFrame
df.show()

# COMMAND ----------

# step 2 - create delta table
from delta.tables import *
delta_df = DeltaTable.forPath(spark,"/FileStore/delta_tables/delta_merge11")

# COMMAND ----------

# step 3 - create merge statement
delta_df.alias("target").merge(
    source = df.alias("source"),
    condition = "target.empid" = "source.empid"
).whenMatchedUpdate(set =
    {
        "name": "source.name",
        "city":"source.city",
        "country":"source.country",
        "contactno":"source.contactno"
    }
).whenNotMatchedInsert(values = 
    {
        "empid":"source.empid",
        "name":"source.name",
        "city":"source.city",
        "country":"source.country",
        "contactno":"source.contactno"
    }
).execute()


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Employee1

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Audit log
# MAGIC

# COMMAND ----------

# MAGIC %sql -- create delta table to perform audit log
# MAGIC create table audit_log(operation string,
# MAGIC                        updated_time timestamp,
# MAGIC                        user_name string,
# MAGIC                        notebook_name string,
# MAGIC                        numTargetedRowsUpdated int,
# MAGIC                        numTargetRowsInserted int,
# MAGIC                        numTargetRowsDeleted int 
# MAGIC                       )

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from audit_log

# COMMAND ----------

# MAGIC %md
# MAGIC ##### create dataframe with last operation in Delta Table

# COMMAND ----------

from delta.tables import *
delta_df = DeltaTable.forPath(spark,"dbfs:/FileStore/delta_tables/delta_merge11" )

# COMMAND ----------

lastOperationDF = delta_df.history(2)
display(lastOperationDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Explode operation metric column

# COMMAND ----------

# explode function separate key value pair into separate rows, as operationMetrics is in Dictionary format
explode_df = lastOperationDF.select(lastOperationDF.operation, explode(lastOperationDF.operationMetrics))
explode_df_select = explode_df.select(explode_df.operation, explode_df.key, explode_df.value.cast("int"))
display(explode_df_select)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### pivot operation to convert rows into columns

# COMMAND ----------

pivot_df = explode_df_select.groupBy("operation").pivot("key").sum("value")
display(pivot_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### select only column needed for audit logs

# COMMAND ----------

pivot_df_select = pivot_df.select(col("operation"), col("numTargetRowsUpdated"), col("numTargetRowsInserted"), col("numTargetRowsDeleted"))
display(pivot_df_select)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Add notebook parameter such as userName, Notebook path etc
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import lit, current_timestamp

# Add new columns to the DataFrame
auditDF = pivot_df_select.withColumn("username", lit(dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get())) \
                        .withColumn("Notebook_name", lit(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())) \
                        .withColumn("updated_time", lit(current_timestamp))

# Display the DataFrame
display(auditDF)


# COMMAND ----------

# MAGIC %md
# MAGIC #####  Question What is Slowly changing dimension?

# COMMAND ----------

# change of attributes/values of entities over a period of time

 SCD Type1 - when address got changed and we are getting new address, it would be "OVERWRITTEN" this is called SCD Type1
     this method, we will lose the history, if someone ask what is users previous address then we dont have any data

 SCD Type2 - we will make previous version of record inactive and insert new record with new address
     we are maintaining history but at the same time, we are creating duplicate records of "PRIMARY KEYS"

 SCD Type3 - instead of overwriting or intruducing new records, we are creating new column for the updated value
     for previous address, we have a column and for new address, we will create new column

# COMMAND ----------

Slowly Changing Dimensions (SCDs) are a concept in data warehousing and database management that refer to how to handle changes to data over time. 
Type 1 SCD overwrites existing data, offering no historical tracking.
Type 2 SCD creates new records with historical data, preserving a complete history.
Type 3 SCD maintains limited historical data by updating selected attributes within the same record.

# COMMAND ----------

# https://www.youtube.com/watch?v=GhBlup-8JbE&t=801s
# screen shot is attached to pyspark_realtime_interview_geek_coders file 

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table scd2Demo(
# MAGIC   pk1 int, 
# MAGIC   pk2 string,
# MAGIC   dim1 int,
# MAGIC   dim2 int,
# MAGIC   dim3 int,
# MAGIC   dim4 int,
# MAGIC   active_status string,
# MAGIC   start_date timestamp,
# MAGIC   end_date timestamp
# MAGIC )
# MAGIC using delta
# MAGIC location '/FileStore/Tables/scd2Demo'

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO scd2Demo VALUES (111, 'Unit1', 200, 500, 800, 400, 'Y', current_timestamp(), '9999-12-31');
# MAGIC
# MAGIC INSERT INTO scd2Demo VALUES (222, 'Unit2', 900, NULL, 700, 100, 'Y', current_timestamp(), '9999-12-31');
# MAGIC
# MAGIC INSERT INTO scd2Demo VALUES (333, 'Unit2', 300, 900, 250, 650, 'Y', current_timestamp(), '9999-12-31');
# MAGIC

# COMMAND ----------

# create delta table
from delta import *
targetTable = DeltaTable.forPath(spark,'/FileStore/Tables/scd2Demo')
targetDF = targetTable.toDF()
display(targetDF)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
schema = StructType([StructField ("pk1", StringType(), True),\
                    StructField ("pk2", StringType(), True),\
                    StructField ("dim1", IntegerType(), True),\
                    StructField ("dim2", IntegerType(), True),\
                    StructField ("dim3", IntegerType(), True),\
                    StructField ("dim4", IntegerType(), True)
])

# COMMAND ----------

data = [(111, 'Unit1', 200, 500, 800, 400),
        (222, 'Unit2', 800, 1300, 800, 500),
        (444, 'Unit4', 100,None, 700, 300)]
sourceDF = spark.createDataFrame(data = data, schema = schema)
display(sourceDF)

# COMMAND ----------

from pyspark.sql.functions import col

joinDF = sourceDF.join(targetDF,
                      (sourceDF.pk1 == targetDF.pk1) &
                      (sourceDF.pk2 == targetDF.pk2) &
                      (targetDF.active_status == "Y"),
                      "leftOuter"
                     )\
              .select(sourceDF["*"],
                      targetDF.pk1.alias("target_pk1"),
                      targetDF.pk2.alias("target_pk2"),
                      targetDF.dim1.alias("target_dim1"),
                      targetDF.dim2.alias("target_dim2"),
                      targetDF.dim3.alias("target_dim3"),
                      targetDF.dim4.alias("target_dim4")
                     )

display(joinDF)


# COMMAND ----------

from pyspark.sql.functions import xxhash64, col

filterDF = joinDF.filter(
    xxhash64(joinDF.dim1, joinDF.dim2, joinDF.dim3, joinDF.dim4)
    != xxhash64(joinDF.target_dim1, joinDF.target_dim2, joinDF.target_dim3, joinDF.target_dim4)
)

display(filterDF)
# we have some null values and to handle it, we use xxhash64 function

# COMMAND ----------

mergeDF = filterDF.withColumn("mergekey", concat(filterDF.pk1, filterDF.pk2))
display(mergeDF)

# COMMAND ----------

dummyDF = filterDF.filter("target_pk1 is not null").withColumn("mergekey", lit(None))
display(dummyDF)

# COMMAND ----------

scdDF = mergeDF.union(dummyDF)
display(scdDF)

# COMMAND ----------

# now use pyspark merge statement to merge to tables

# COMMAND ----------

Step1 - left join source to target
step2 - filter out only change record
step3 - create merge key by combining key column
step4 - create null merge key only for matching records
step5 - union step3 and step4
step6 - apply merge statement