# Databricks notebook source
s = 'this is gauav'
s_split = s.split()
s_join = ' '.join(s_split[::-1])
print(s_join)

# COMMAND ----------

s = 'this is gauav'
s_split = s.split()
rev_word = s_split[::-1]
s_join = ''.join(rev_word)

print(rev_word)

# COMMAND ----------

s = 'this is gauav'
n = ''
for i in s:
    n = i +n
print(n)

# COMMAND ----------

def add(a, b):
    return a + b
print(add(3,4))

# COMMAND ----------

def sum(a,b):
    return a+b
print(3,4)

# COMMAND ----------

s = 'hello gaurav'
def upp(s):
    return s[0].upper() + s[1:-1] + s[-1].upper()
print(upp(s))

# COMMAND ----------

a = 'hELLO gAUrav kURHEkar'
split_s = a.split()
output = ''
for i in split_s:
    output = output + i[0].upper() + i[1:].lower() + ' '
print(output)

# COMMAND ----------

s = "hello gaurav kurhekar"
result = s.title()
print(result)

# COMMAND ----------

select max(salary) from company where salary not in(select max(salary) from company)

# COMMAND ----------

with cte as
(
    select *, row_number over(partition by department order by salary desc) as rank from table
)
select salary from cte where rank = 2

# COMMAND ----------

with cte as
(
    select top 2 * from table order by salary desc
)
select top 1 salary from cte order by salary asc

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, monotonically_increasing_id
w = Window.orderBy(monotonically_increasing_id())
df = df.withColumn('index', row_number().over(w)-1)


# COMMAND ----------

dbfs rm -r dbfs:/user/hive/warehouse/Table_5

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE Table_5 (
# MAGIC     ID INT
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data into Table1
# MAGIC INSERT INTO Table_5 VALUES
# MAGIC (1),
# MAGIC (1),
# MAGIC (2),
# MAGIC (Null);
# MAGIC
# MAGIC -- Create Table2
# MAGIC CREATE TABLE Table_6 (
# MAGIC     ID INT
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data into Table2
# MAGIC INSERT INTO Table_6 VALUES
# MAGIC (1),
# MAGIC (1),
# MAGIC (0),
# MAGIC (Null);

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Table_5

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Table_6

# COMMAND ----------

# MAGIC %sql    -- Count of records for inner join
# MAGIC SELECT COUNT(*) AS InnerJoinCount
# MAGIC FROM Table_5 t1
# MAGIC INNER JOIN Table_6 t2 ON t1.ID = t2.ID;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Count of records for left join
# MAGIC SELECT COUNT(*) AS LeftJoinCount
# MAGIC FROM Table_5 t1
# MAGIC LEFT JOIN Table_6 t2 ON t1.ID = t2.ID;

# COMMAND ----------

WITH RankedSalaries AS (
  SELECT
    department,
    salary,
    ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) AS salary_rank
  FROM
    your_table_name
)
SELECT
  department,
  salary
FROM
  RankedSalaries
WHERE
  salary_rank = 2;


# COMMAND ----------

from pyspark.sql.functions import rank, dense_rank, desc
from pyspark.sql.window import Window
# Sample data (replace with your actual DataFrame)
data = [("IT", 5000),
        ("IT", 6000),
        ("HR", 4500),
        ("HR", 5500),
        ("Finance", 7000),
        ("Finance", 8000)]

columns = ["department", "salary"]

# Create DataFrame
df = spark.createDataFrame(data, columns)

# Define Window specification
window_spec = Window.partitionBy("department").orderBy(desc("salary"))

# Add a rank column based on the salary within each department
df = df.withColumn("salary_rank", rank().over(window_spec))     

# Filter for the second-highest salary in each department
result_df = df.filter(result_df.salary_rank == 2)               

# Select relevant columns for the final result
result_df.select("department", "salary").show()




# COMMAND ----------

from pyspark.sql.functions import rank, dense_rank, desc
from pyspark.sql.window import Window

# Assuming the input data is in a DataFrame named 'input_data'
# with columns 'department', 'employee_name', and 'salary'

# Create a window specification to partition by department and order by salary
window_spec = Window.partitionBy('department').orderBy(desc('salary'))

# Add a new column to the DataFrame that ranks the employees within each department
ranked_data = input_data.withColumn('rank', dense_rank().over(window_spec))

# Filter the DataFrame to only include employees with a rank of 2
second_highest_salary = ranked_data.filter(ranked_data.rank == 2)

# Show the results
second_highest_salary.show()


# COMMAND ----------

from pyspark.sql.functions import rank, dense_rank, desc
from pyspark.sql.window import Window


# Sample data (replace with your actual DataFrame)
data = [("IT", 5000),
        ("IT", 6000),
        ("HR", 4500),
        ("HR", 5500),
        ("Finance", 7000),
        ("Finance", 8000)]

columns = ["department", "salary"]

# Create DataFrame
df = spark.createDataFrame(data, columns)

# Define Window specification
window_spec = Window.partitionBy("department").orderBy(desc("salary"))

# Add a rank column based on the salary within each department
df = df.withColumn("salary_rank", rank().over(window_spec))

# Filter for the second-highest salary in each department
result_df = df.filter(df.salary_rank == 2)

# Select relevant columns for the final result
result_df.select("department", "salary").show()


# COMMAND ----------

from pyspark.sql.functions import rank, dense_rank, desc
from pyspark.sql.window import Window


# Sample data (replace with your actual DataFrame)
data = [("IT", 5000),
        ("IT", 6000),
        ("HR", 4500),
        ("HR", 5500),
        ("Finance", 7000),
        ("Finance", 8000)]

columns = ["department", "salary"]

df = spark.createDataFrame(data, columns)
df.show()

w = Window.partitionBy('department').orderBy(desc('salary'))

df = df.withColumn('rank', dense_rank().over(w))

df_filter = df.filter(df.rank ==2)

df_filter.select('departmet', 'salary').show()

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import lag

# Sample data (replace with your actual DataFrame)
data = [
    (1, 'John', 60000, None, 'IT'),
    (2, 'Jane', 55000, 1, 'IT'),
    (3, 'Bob', 70000, None, 'HR'),
    (4, 'Alice', 65000, 3, 'HR'),
    (5, 'Charlie', 80000, 3, 'Finance'),
    (6, 'David', 75000, 5, 'Finance')
]

columns = ["employee_id", "employee_name", "salary", "manager_id", "department"]

# Create DataFrame
df = spark.createDataFrame(data, columns)

# Define a Window specification to partition by department
window_spec = Window().partitionBy("department").orderBy("employee_id")

# Add a column for the manager's salary using lag function
df = df.withColumn("manager_salary", lag("salary").over(window_spec))

# Filter for employees whose salary is more than their manager's salary
result_df = df.filter(df.salary > df.manager_salary)

# Select relevant columns for the final result
result_df.select("employee_id", "employee_name", "salary", "manager_salary", "department").show()


# COMMAND ----------

L = [1,2,3,4,5]
def find_odd(lst):
    for i in L:
        if i%2!=0:
            print('odd')
        else:
            print('even')
    

# COMMAND ----------

from typing import List

lst = [2,4,7,8]
target = 11

def two_sum(lst, target):
    for i in range(len(lst)):
        for j in range(i+1, len(lst)):
            if lst[i] + lst[j] == target:
                return [i, j]
            
print(two_sum(lst,target))

# COMMAND ----------

str = "HelloWorld"
char_count = {}
for i in str:
    if i in char_count:
        char_count[i] +=1
    else:
        char_count[i] = 1

print(char_count)

# COMMAND ----------

from collections import Counter
str = 'helloworld'
count = Counter(str)
print(count)

# COMMAND ----------

select 
sum(case when id> 0 then id else 0 end) as positive
sum(case when id<0 then id else 1 end) as negative
from table_name

# COMMAND ----------

'EmpID', 'EmpName', 'Salary', 'ManagerID'
table name = emptable

select E.Empid, E.EmpName, E.EmpSalary, E.ManagerID
from emp_table E
join
Emp_table M
on E.ManagerID = M.EmpID
where E.salary > M.salary

result = spark.sql("""
    SELECT e.EmpID, e.EmpName, e.Salary, e.ManagerID
    FROM employee_table e
    JOIN employee_table m ON e.ManagerID = m.EmpID
    WHERE e.Salary > m.Salary
""")

# COMMAND ----------

1000,2000,3000,4000 10000/4= 2500  Department

['EmpID', 'EmpName', 'Salary', 'DepartmentID']

select 'E.EmpID', 'E.EmpName', 'E.Salary', 'E.DepartmentID'
from Emp_table as E
join
(
select DepartmentID, avg(salary) as avgSal
from emp_table
group by DepartmentID)
as avg_table

on E.departmentID = avg_Table.departmentID
where
e.salary>avgtable.avgSal


# COMMAND ----------

EmpID, EmpName, EmpSalary,EmpCity and Designation column in SQL, write a program in sql to return designation with highest salary in each city?

select EmpID, EmpName, EmpSalary,EmpCity, Designation from EmpTable e
join
(select EmpCity, designation, max(salary) as MaxSalary
from EmpTable
group by EmpCity)
as maxixmum_salary

on EmpCity = maximum_salary.EmpCity
and E.empSal= max_salaries.empSal

# COMMAND ----------

string = "123a!"
def duplicate(s):
    result = ""
    for i in s:
        result += i*2
    return result
print(duplicate(s))


string = "123a!"

def create_duplicate(s):
    result = ""
    for i in s:
        result += i * 2
    return result

# Test the function
result_string = create_duplicate(string)
print(result_string)

# COMMAND ----------

num = 14
def is_prime(num):
    for i in range(2, num//2):
        if num%i==0:
            return 'not prime'
        else:
            return 'prime'
print(is_prime(num))

# COMMAND ----------

with cte as
(
    select 
        ID,
        Name,
        Location,
        Date, rank() over(partition by Name order by Date desc) as row_rank from emp
)
SELECT
        ID,
        Name,
        Location,
        Date, from cte where gaurav = 1

        %sql
WITH RankedRecords AS (
    SELECT
        ID,
        Name,
        Location,
        Date,
        ROW_NUMBER() OVER (PARTITION BY Name ORDER BY Date DESC) AS RowRank
    FROM
        EmployeeRecords
)

SELECT
    ID,
    Name,
    Location,
    Date
FROM
    RankedRecords
WHERE
    RowRank = 1;


# COMMAND ----------

id|   name|course

df1 = df.groupBy('ID', 'Name').agg(collect_list('cource').alias('COURCE'))

result_df = df.groupBy('ID', 'Name').agg(collect_list('course').alias('Course'))


df_result = df.withColumn('cource', explode(split(col('cource'), ' ')))

df_result = df.withColumn('courses', explode(split(col('course'), ',')))

# COMMAND ----------

my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

sort_dict = dict(sorted(my_dict.items(), key = lambda item: item[1], reverse = True))
print(sort_dict)

# COMMAND ----------

lst = [12,3,27,5,4,9,4]  # 3,4,6
target = 80

def three_multi(lst, target):
    for i in range(len(lst)):
        for j in range(i + 1, len(lst)):
            for k in range(j + 1, len(lst)):
                if lst[i] * lst[j] * lst[k] == target:
                    return lst[i], lst[j], lst[k]
    return none
print(three_multi(lst, target))

# COMMAND ----------

f = open('gaurav.txt', r)
print(f.readline())
f.close()

# COMMAND ----------

a = int(input('enter first name'))
b = int(input('enter second number'))
temp = a
a = b
b = temp
print('value of a:', a)
print('value of b:', b)


# COMMAND ----------

lst = [1, 2, 3, 3, 4, 4, 5, 5, 5, 6, 7, 8, 8]
con_set = set(lst)
con_back_lst = list(con_set)

# COMMAND ----------

my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

lst = list(my_dict.items())
print(lst)

# COMMAND ----------

from pyspark.sql.functions import col
my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

df = spark.createDataFrame(list(my_dict.items()), ['key', 'value'])
sorted_dict = df.orderBy(col('value'))
dict_net = dict(sorted_dict)
print(dict_net)

# COMMAND ----------

Write a pyspark code to extract data from .csv and create table on top on that and then save the table in parquet format?

csv_path = "dbfs:/FileStore/tables/employee1.csv"
df = spark.read.csv(csv_path, header=True, inferSchema=True)

# Display the DataFrame
df.show()

# Register the DataFrame as a temporary table
df.createOrReplaceTempView("my_table")

# Save the table in Parquet format
parquet_output_path = "dbfs:/FileStore/tables/employee1/parquet_data"
spark.sql("SELECT * FROM my_table").write.parquet(parquet_output_path)

# COMMAND ----------

# MAGIC %sql
# MAGIC select ID, Name,  Salary, avg(salary) over (partition by Department)as avg_salary from Empdept123 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the EmployeeCourses table
# MAGIC CREATE TABLE EmployeeCourses345 (
# MAGIC     id INT,
# MAGIC     name VARCHAR(255),
# MAGIC     course VARCHAR(255)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data
# MAGIC INSERT INTO EmployeeCourses345 VALUES
# MAGIC (1, 'Arul', 'SQL'),
# MAGIC (1, 'Arul', 'Spark'),
# MAGIC (2, 'Bhumica', 'SQL'),
# MAGIC (2, 'Bhumica', 'Spark');
# MAGIC select * from EmployeeCourses345

# COMMAND ----------



# COMMAND ----------

a = 'hELLO gAUrav kURHEkar'
y = a.split()
r = ''
for i in y:
    r = r + i[0].upper() + i[1:].lower() + ' '
print(r)

# COMMAND ----------

my_list = [1, 2, 3, 4, 5]
if my_list == sorted(my_list):
    print('yes')
else:
    print('no')
print(my_list)

# COMMAND ----------

string = 'Gaurav'
count = 0
for i in string:
    count = count+1
print(count)

# COMMAND ----------

subject_marks = [('English', 88), ('Science', 90), ('Maths', 97), ('Social sciences', 82)]
so= sorted(subject_marks, key = lambda x:x[1])
print(so)

# COMMAND ----------

file = file.txt

f = open('file.txt', 'r')
f.readlines()
f.close()

# COMMAND ----------

lst = [1, 2, 3, 4, 5]
sq = []
for i in lst:
    sq.append(i**3)
print(sq)

# COMMAND ----------

We have file in csv format which is saved in some bucket in databricks, write the dataframe in pyspark to- 
* 1-read the file,
* 2-load it to landing zone with .parquet format, 
* 3-save it to a externaltable,
* 4-again read the files, 
* 5-do some nullcheck and 
* 6-do some duplicate check and 
* 7-write again into any process folder?

file_path = ('dbfs:/filestore/file.csv')
df = spark.read.csv(file_path, inferSchema = True, header = True)

landing_zone= ('dbfs/filestore/zone')
df.write.parquet(landing_zone)

external_tbl_name = my_external_table
df.write.mode('overwrite').saveAsTable('external_tbl_name')

read = spark.table(external_tbl_name)

df_filter = df.filter(df.isNull).count()
df_dup = df.dropDuplicates()

proc_fol= ('dbfs:/filestore')
df.write.parquet(process_folder_path)

# COMMAND ----------

a = 'hELLO gAUrav kURHEkar'
result = ''
b = a.split()
for i in b:
    result = b[0].upper()+ b[1:-1]+b[-1].upper()
print(result)


# COMMAND ----------

a = 'hELLO gAUrav kURHEkar'
y = a.split()
r = ' '
for i in y:
    r = r + i[0].upper() + i[1:].lower() 
print(r)

# COMMAND ----------

a = 'hELLO gAUrav kURHEkar'
rersult = a.title()
print(result)

# COMMAND ----------

# Create a list of Rows for df1
data1 = [(1,),(2,),(3,),(4,),(5,)]
schema = ['id']
# Create df1 DataFrame
df1 = spark.createDataFrame(data1, schema)

# Create a list of Rows for df2
data2 = [(3,),(4,),(5,),(6,),(7,)]
schema = ['id']
# Create df2 DataFrame
df2 = spark.createDataFrame(data2, schema)

# Show the dataframes
df1.show()
df2.show()

# COMMAND ----------

df3 = df1.join(df2, df1.id == df2.id, "left_anti")

# Show the result of the anti join
df3.show()

# COMMAND ----------

df4 = df1.join(df2, df1.id == df2.id, "left_semi")

# Show the result of the anti join
df4.show()

# left semi produce same result as inner join, difference is- left semi join returns rows from the left DataFrame where a match exists
# an inner join combines rows from both DataFrames based on a join condition, while a left semi join returns rows from the left DataFrame where a match exists in the right DataFrame, but only includes columns from the left DataFrame.

# COMMAND ----------

data = [("Yughandar123",),
        ("John456",),
        ("Alice",),
        ("Bob789",)]
columns = ["names"]

df = spark.createDataFrame(data, columns)
df.show()

# COMMAND ----------

# Remove numbers from the "names" column using regexp_replace
from pyspark.sql.functions import regexp_replace

# Assuming `df` is your DataFrame containing a column "names"
df_without_numbers = df.withColumn("names_without_numbers", regexp_replace("names", r'\d+', ''))
df_without_numbers.display()

# COMMAND ----------

df.withColumn('new_table', regexp_replace('name', '\d+', ''))

# COMMAND ----------

10

# COMMAND ----------

import datetime
x = datetime.datetime.now()
print(x)
print(x.year)
print(x.month)
print(x.day)
print(x.strftime('%b'))

# COMMAND ----------

L1 = [1,2,3,4,5]
sum1 = 0
for i in L1:
    sum1+=i
print(sum1)

# COMMAND ----------

a = 'Gaurav'

new = a.count('a')
print(new)

# COMMAND ----------

import time, datetime
print(datetime.datetime.now())
print(datetime.datetime.today().strftime('%d'))

# COMMAND ----------

from datetime import date, time, timedelta, datetime

w = datetime.now()
new = w + timedelta(seconds = 2)
print(new)

# COMMAND ----------

subject_marks = [('English', 88), ('Science', 90), ('Maths', 97), ('Social sciences', 82)]
a = sorted(subject_marks, key = w = datetime.now()lambda x: x[1])
print(a)

# COMMAND ----------

L = [1, 2, 3, 4, 5]
rev = []
for i in L[::-1]:
        rev.append(i)
print(rev)

# COMMAND ----------

lst = [1, 2, 3, 4, 5]
squared_lst = []

# Loop through the list and square each element
for i in lst:
    squared_lst.append(i**2)

print(squared_lst)


# COMMAND ----------

from pyspark.sql.functions import avg
# Sample data
data = [(1, 20000, 1),
        (2, 50000, 2),
        (3, 60000, 3),
        (4, 70000, 1),
        (5, 10000, 2),
        (6, 35000, 3),
        (7, 60000, 1),
        (8, 85000, 2),
        (9, 11000, 3)]

# Define schema
schema = ["ID", "Salary", "Dept"]

# Create DataFrame
df = spark.createDataFrame(data, schema)
df.show()
df.createOrReplaceTempView('new')


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from new

# COMMAND ----------

##### Question 79- We have csv file called fileA.csv having id, customer_name, address, age, 
* customer_name column having name- first_name, middle_name and last_name, 
* Requirement- 
* 1-Read the file using dataframe using pyspark, 
* 2- Transform the data to split the name in three parts, and 
* 3-Display the output like- id, first_name, middle_name, last_name, address, age?

# COMMAND ----------

# Read the CSV file into a DataFrame
file_path = "dbfs:/FileStore/tables/fileA.csv"  # Specify the path to your CSV file
df = spark.read.csv(file_path, header=True, inferSchema=True)
display(df)

df1 = split(df['customer_name'], ' ')

df2 = df1.withColumn('fname', df1.getitems(0))\
        .withColumn('lname', df1.getitems(1))\
        .withColumn('middlename', df1.getitems(2))

df3 = df2.select('id', 'fname', 'lname', 'middlename')

from pyspark.sql.functions import split

# Split the 'customer_name' column into 'first_name', 'middle_name', and 'last_name'
name_split = split(df['customer_name'], ' ')  # Split the 'customer_name' column by spaces

# Add the split columns to the DataFrame
df = df.withColumn('first_name', name_split.getItem(0)) \
    .withColumn('middle_name', name_split.getItem(1)) \
    .withColumn('last_name', name_split.getItem(2))

# Select the required columns in the desired order
df_transformed = df.select('id', 'first_name', 'middle_name', 'last_name', 'age')

# Display the output
df_transformed.show()

# COMMAND ----------

merge into target_table as target 
using source_table as source
on target.id = source.id
when match then update set target.name = source.name, 
                            target.add = source.add
when not match then insert (empid, empname) values(1, 'gaurav')


# COMMAND ----------

str1 = "my name is Gaurav"
new = ''
for i in str1:
    new = i + new
print(new)

# COMMAND ----------

str1 = "my name is Gaurav"
sp = str1.split()
re = sp[::-1]
new = ' '.join(re)
print(new)

# COMMAND ----------

