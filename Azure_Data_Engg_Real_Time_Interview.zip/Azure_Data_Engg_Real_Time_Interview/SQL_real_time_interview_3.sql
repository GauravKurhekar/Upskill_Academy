-- Databricks notebook source
-- MAGIC %md
-- MAGIC ##### Question 31. Write an SQL query to fetch all the Employees who are also managers from the EmployeeDetails table.

-- COMMAND ----------

select e.empid, m.managerid from Empdetails2 e 
join Empdetails2 m 
on e.empid = m.ManagerId

--OR

SELECT DISTINCT E.FullName
FROM Empdetails E
INNER JOIN Empdetails M
ON E.EmpID = M.ManagerID;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 32. Write an SQL query to fetch duplicate records from EmployeeDetails (without considering the primary key – EmpId).

-- COMMAND ----------

SELECT FullName, ManagerId, DateOfJoining, City, COUNT(*)
FROM Empdetails2
GROUP BY FullName, ManagerId, DateOfJoining, City
HAVING COUNT(*) > 1;
--OR

--  select distinct fullname, count(*) from Empdetails
--  group by fullname
--  having count(*)>1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 33. Write an SQL query to remove duplicates from a table without using a temporary table.

-- COMMAND ----------

WITH CTE AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY EmpId ORDER BY EmpId) AS RowNumber
    FROM Empdetails
)
DELETE FROM CTE
WHERE RowNumber > 1;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####  Question 34. Write an SQL query to fetch only odd rows from the table.

-- COMMAND ----------

--Method 1- using CTE
WITH OddRows AS (
    SELECT *, ROW_NUMBER() OVER (ORDER BY (Empid)) AS RowNum
    FROM Empdetails2
)
SELECT *
FROM OddRows
WHERE RowNum % 2 <> 0;

-- COMMAND ----------

--Method 2 - using Case when statement
SELECT *
FROM Empdetails
WHERE CASE WHEN Empid % 2 <> 0 THEN 'Odd' ELSE 'Even' END = 'Odd';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 35. Write an SQL query to fetch only even rows from the table.

-- COMMAND ----------

with cte as (
	select *, ROW_NUMBER() over(order by empid) as even from Empdetails2
	)
	select * from cte where even%2 <>1;

-- COMMAND ----------

select * from Empdetails where case when empid%2 <> 1 then 'even' else 'odd' end as 'even'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 36. Write an SQL query to create a new table with data and structure copied from another table.

-- COMMAND ----------

--Method 1 - 
SELECT *
INTO NewTableName
FROM Empdetails;

-- COMMAND ----------

--Method 2
CREATE TABLE NewTableName AS
SELECT *
FROM Empdetails
WHERE 1 = 0;

--The condition 1 = 0 is always false, so the SELECT query will not return any rows.
--This means that no rows are selected from the existing table, resulting in an empty new table being created with the same structure as the existing table.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 38. Write an SQL query to fetch top n records.

-- COMMAND ----------

select top 1 * from Empsalary;
select top 1 * from Empsalary order by salary desc;
select top 2 * from Empsalary order by salary desc;
select top 10 * from Empsalary order by salary desc;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 39. Write an SQL query to find the nth highest salary from a table.

-- COMMAND ----------

with cte as(
	select *,ROW_NUMBER() over (order by salary desc) as hig_sal from empsalary2
	)
	select * from cte where hig_sal=1;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 40. Write SQL query to find the 3rd highest salary from a table without using the TOP/limit keyword.

-- COMMAND ----------

with cte as(
	select *,ROW_NUMBER() over (order by salary desc) as hig_sal from empsalary2
	)
	select * from cte where hig_sal=3;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 41. Consider a SalesData with columns SaleID, ProductID, RegionID, SaleAmount. Write a query to find the total sales amount for each product in each region.

-- COMMAND ----------

SELECT ProductID, RegionID, SUM(SaleAmount) AS TotalSales 
FROM SalesData 
GROUP BY ProductID, RegionID;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 43. Consider a BookCheckout table with columns – CheckoutID, MemberID, BookID, CheckoutDate, ReturnDate, Write an SQL query to find the number of books checked out by each member.

-- COMMAND ----------

SELECT MemberID, COUNT(*) AS NumberOfBooksCheckedOut 
FROM BookCheckout 
GROUP BY MemberID;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 44. Consider a StudentGrades table with columns – StudentID, CourseID, Grade. Write a query to find students who have scored an ‘A’ in more than three courses.

-- COMMAND ----------

SELECT StudentID
FROM StudentGrades
WHERE Grade = 'A'
GROUP BY StudentID
HAVING COUNT(*) > 3;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 45. Consider a table OrderDetails with columns – OrderID, CustomerID, ProductID, OrderDate, Quantity, Price. Write a query to find the average order value for each customer.

-- COMMAND ----------

SELECT CustomerID, AVG(Quantity * Price) AS AvgOrderValue 
FROM OrderDetails 
GROUP BY CustomerID;

-- query calculates the average order value (quantity multiplied by price) for each customer.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 46. Consider a table PatientVisits with Columns VisitID, PatientID, DoctorID, VisitDate, Diagnosis.Write a query to find the latest visit date for each patient.

-- COMMAND ----------

SELECT PatientID, MAX(VisitDate) AS LatestVisitDate 
FROM PatientVisits 
GROUP BY PatientID;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 47. For a table FlightBookings with columns – BookingID, FlightID, PassengerID, BookingDate, TravelDate, Class, write a query to count the number of bookings for each flight class.

-- COMMAND ----------

Question 47. For a table FlightBookings with columns – BookingID, FlightID, PassengerID, BookingDate, TravelDate, Class, 
			write a query to count the number of bookings for each flight class.

--Here, we will write an SQL query that groups the bookings by Class and counts the number of bookings in each class.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 48. Consider a table FoodOrders with columns – OrderID, TableID, MenuItemID, OrderTime, Quantity.Write a query to find the most ordered menu item.

-- COMMAND ----------

SELECT MenuItemID 
FROM FoodOrders 
GROUP BY MenuItemID 
ORDER BY COUNT(*) DESC 
LIMIT 1;

--For the desired output, we will group the orders by MenuItemID and then sort the results by the count in descending order, fetching the top result.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 49. Consider a table Transactions with columns – TransactionID, CustomerID, ProductID, TransactionDate, Amount.Write a query to find the total transaction amount for each month.

-- COMMAND ----------

SELECT MONTH(TransactionDate) AS Month, 
SUM(Amount) AS TotalAmount 
FROM Transactions 
GROUP BY MONTH(TransactionDate);

--The below query sums the Amount for each month, giving a monthly total transaction amount.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 50. Consider a table EmployeeAttendance with columns – AttendanceID, EmployeeID, Date, Status.Write a query to find employees with more than 5 absences in a month.

-- COMMAND ----------

SELECT EmployeeID, 
MONTH(Date) AS Month, 
COUNT(*) AS Absences 
FROM EmployeeAttendance 
WHERE Status = 'Absent' 
GROUP BY EmployeeID, MONTH(Date) 
HAVING COUNT(*) > 5;

--This query filters the records for absent status, groups them by EmployeeID and month, and counts absences, filtering for more than 5 absences.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Leetcode SQL interview questions

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 1-  We have two tables Person and address, 
-- MAGIC * Person having columns- personid, firstname, lastname
-- MAGIC * address having columns- addressid, personid, city, state,
-- MAGIC * Write a SQL query to Combine Two Tables 
-- MAGIC

-- COMMAND ----------

SELECT p.FirstName, p.LastName, a.City, a.State FROM Person p
LEFT JOIN  Address  a
ON p. PersonId = a . PersonId ;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###### Question 2- Write a SQL query to get the second highest salary from the Employee table.
-- MAGIC * Id	|	Salary
-- MAGIC * 1 |	100
-- MAGIC * 2	|	200
-- MAGIC * 3	|	300

-- COMMAND ----------

with cte as (
  select id, salary, row_number() over (order by salary) as sec_sal from table_name
)
select salary from cte where sec_sal = 2;

--OR

select max(salary) as second_hig_salary from table_name where salary <(select max(salary) from table_name)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 3- Nth Highest Salary 

-- COMMAND ----------

SELECT DISTINCT Salary
FROM (
    SELECT Salary, DENSE_RANK() OVER (ORDER BY Salary DESC) AS Rank
    FROM Employee
) AS RankedSalaries
WHERE Rank = N;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 4- Write a SQL query to rank scores. If there is a tie between two scores, both should have the same ranking. Note that after a tie, the next ranking number should be the next consecutive integer value. In other words, there should be no “holes” between ranks.
-- MAGIC
-- MAGIC * Id	|	Score
-- MAGIC * 1	|	3.50
-- MAGIC * 2	|	3. 65
-- MAGIC * 3	|	4.00
-- MAGIC * 4	|	3.85
-- MAGIC * 5	|	4.00
-- MAGIC * 6	|	3.65
-- MAGIC

-- COMMAND ----------



score	|	Rank
4.00	| 1
4.00	|	1
3.85	|	2
3.65	|	3
3.65	|	3
3.50	|	4


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 5- **Consitive numbers**
-- MAGIC Write a SQL query to find all numbers that appear at least three times consecutively, for ex- 1 appears three times consitively
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- Create the table
CREATE TABLE Consecutive_table (
    Id INT,
    Num INT
);

-- Insert sample records
INSERT INTO Consecutive_table (Id, Num) VALUES (1, 1);
INSERT INTO Consecutive_table (Id, Num) VALUES (2, 1);
INSERT INTO Consecutive_table (Id, Num) VALUES (3, 1);
INSERT INTO Consecutive_table (Id, Num) VALUES (4, 2);
INSERT INTO Consecutive_table (Id, Num) VALUES (5, 1);
INSERT INTO Consecutive_table (Id, Num) VALUES (6, 2);
INSERT INTO Consecutive_table (Id, Num) VALUES (7, 2);
select * from Consecutive_table;

-- COMMAND ----------

--Method 1 using CTE
WITH ConsecutiveNumbers AS (
    SELECT 
        Num,
        LAG(Num, 1) OVER (ORDER BY Id) AS PrevNum,
        LEAD(Num, 1) OVER (ORDER BY Id) AS NextNum
    FROM Consecutive_table
)
SELECT DISTINCT Num
FROM ConsecutiveNumbers
WHERE Num = PrevNum AND Num = NextNum;

--LAG(Num, 1): This function returns the value of the Num column from the previous row relative to the current row. 
--The 1 parameter specifies that we want to go back one row. If there is no previous row (for example, for the first row in the result set), LAG() will return NULL.

--LEAD(Num, 1): This function returns the value of the Num column from the next row relative to the current row. Again, 
--the 1 parameter specifies that we want to go forward one row. If there is no next row (for example, for the last row in the result set), LEAD() will return NULL.

-- COMMAND ----------

-- Method 2- using self join by three tables
SELECT DISTINCT t1.Num
FROM Consecutive_table t1
JOIN Consecutive_table t2 ON t1.Id = t2.Id - 1
JOIN Consecutive_table t3 ON t2.Id = t3.Id - 1
WHERE t1.Num = t2.Num AND t2.Num = t3.Num;

--t1.Id = t2.Id - 1 checks whether the Id value in the row represented by t1 is equal to the Id value in the row represented by t2 minus 1.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 6-Employees Earning More Than Their Managers, write a SQL query that finds out employees who earn more than their managers. For the above table, Joe is the only employee who earns more than his manager.
-- MAGIC
-- MAGIC * Id	|	Name	|	Salary	|	ManagerId
-- MAGIC * 1	|	Joe	|	70000	|	3
-- MAGIC * 2	|	Henry	|	80000	|	4
-- MAGIC * 3	|	Sam	|	60000	|	NULL
-- MAGIC * 4	|	Max	|	90000	|	NULL
-- MAGIC

-- COMMAND ----------

SELECT E.Name as ”Employee" FROM Employee E
JOIN Employee M
 
ON E.ManagerId = M.Id AND E.Salary > M.Salary;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 7- Write a SQL query to find all duplicate emails in a table named Person .
-- MAGIC * Id	|	Email
-- MAGIC * 1	| a@b.com
-- MAGIC * 2	|	c@d.com
-- MAGIC * 3	|	a@b.com

-- COMMAND ----------

select email, count(*) from table_name
group by email
having count(*)>1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 8- Customers Who Never Order, Suppose that a website contains two tables, the customers table and the Orders table. Write a SQL query to find all customers who never order anything.
-- MAGIC
-- MAGIC *  Customers 
-- MAGIC * Id | Name
-- MAGIC * 1	| Joe
-- MAGIC * 2	| Henry
-- MAGIC * 3	| Sam
-- MAGIC * 4	| tax
-- MAGIC
-- MAGIC * orders .
-- MAGIC * Id | Customer Id
-- MAGIC * 1 | 3
-- MAGIC

-- COMMAND ----------

SELECT c.id, c.name
FROM Customers c
LEFT JOIN Orders o ON c.id = o.customer_id
WHERE o.customer_id IS NULL;
 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Questiton 9- We have employee table having column- id, name, salary, departmentid and department table having column- id, name, write sql server query to find highest salary in each department and return the rows- department, employee , salary using cte
-- MAGIC * Employee table 
-- MAGIC * Id	|	Name	|	Salary	|	DepartmentId
-- MAGIC * 1	| Joe | 70000 | 1
-- MAGIC * 2	|	Jim	|	90000	|	1
-- MAGIC * 3	|	Henry	|	80000	|	2
-- MAGIC * 4	|	Sam	|	60000	|	2
-- MAGIC * 5	|	Max	|	90000	|	1
-- MAGIC
-- MAGIC * The Department table holds all departments of the company.
-- MAGIC * Id | Name
-- MAGIC * 1	| IT
-- MAGIC * 2	| Sales

-- COMMAND ----------

WITH RankedSalaries AS (
    SELECT 
        e.id AS employee_id,e.name AS employee_name, e.salary, e.departmentid,
        d.name AS department_name,
        ROW_NUMBER() OVER (PARTITION BY e.departmentid ORDER BY e.salary DESC) AS rank
    FROM 
        employee e
    JOIN 
        department d ON e.departmentid = d.id
)
SELECT 
    employee_name, salary, department_name
FROM 
    RankedSalaries
WHERE 
    rank = 1;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 10 -Department Top Three Salaries, Write a SQL query to find employees who earn the top three salaries in each of the department. 
-- MAGIC * Employee_Table
-- MAGIC * Id	|	Name	|	Salary	|	DepartmentId
-- MAGIC * 1	|	Joe	|	85000	|	1
-- MAGIC * 2	|	Henry	|	80000	|	2
-- MAGIC * 3	|	Sam	|	60000	|	2
-- MAGIC * 4	|	Max	|	90000	|	1
-- MAGIC * 5	|	Janet	|	69000	|	1
-- MAGIC * 6	|	Randy	|	85000	|	1
-- MAGIC * 7	|	Will	|	70000	|	1
-- MAGIC
-- MAGIC * Department_table
-- MAGIC * Id | Name
-- MAGIC * 1	| IT
-- MAGIC * 2	| Sa1es

-- COMMAND ----------

WITH department_ranking AS (
SELECT Name AS Employee, Salary ,DepartmentId
,DENSE_RANK() OVER (PARTITION BY DepartmentId ORDER BY Salary DESC) AS rnk
FROM Employee
)
SELECT d.Name AS Department, r.Employee, r.Salary
FROM department_ranking AS r JOIN Department AS d
ON r.DepartmentId = d.Id WHERE r.rnk <= 3
ORDER BY d.Name ASC, r.Salary DESC;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 11- Write a SQL query to delete all duplicate email entries in a table named Person , keeping only unique emails based on its smallest Id.
-- MAGIC * Id | email	 
-- MAGIC * 1	| john@example.com
-- MAGIC * 2	| bob@example.com
-- MAGIC * 3	| john@example.com

-- COMMAND ----------

WITH DuplicateEmails AS (
    SELECT id, email, ROW_NUMBER() OVER (PARTITION BY email ORDER BY id) AS RowNum
    FROM Person
)
DELETE FROM DuplicateEmails
WHERE RowNum > 1;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 12- We have table called weather having columns- id, record_Date, temperature, Write an SQL query to find all dates’	with higher temperature compared to its previous dates (yesterday)?

-- COMMAND ----------

-- Create weather table
CREATE TABLE weather (
    id INT,
    record_Date DATE,
    temperature DECIMAL(5, 2)
);

-- Insert sample records into weather table
INSERT INTO weather (id, record_Date, temperature) VALUES (1, '2024-04-01', 20.5);
INSERT INTO weather (id, record_Date, temperature) VALUES (2, '2024-04-02', 22.8);
INSERT INTO weather (id, record_Date, temperature) VALUES (3, '2024-04-03', 21.3);
INSERT INTO weather (id, record_Date, temperature) VALUES (4, '2024-04-04', 24.7);
INSERT INTO weather (id, record_Date, temperature) VALUES (5, '2024-04-05', 25.9);
INSERT INTO weather (id, record_Date, temperature) VALUES (6, '2024-04-06', 23.5);
select * from weather;

-- COMMAND ----------

with cte as (
  select record_date, temperature, lag(temperature) over (order by record_date) as prev_temperature
  from weather
)
select record_date, temperature from cte where temperature> prev_temperature;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 13- Write an SQL query that reports the first login date for each player.
-- MAGIC
-- MAGIC * Activity table:
-- MAGIC * player_id	|	device_id	|	event_date	|	games_played
-- MAGIC * 1		2   2016-03-01  | 5
-- MAGIC * 1		2		2016-05-02	|	6
-- MAGIC * 2		3		2017-06-25	|	1
-- MAGIC * 3		1		2016-03-02	|	0
-- MAGIC * 3		4		2018-07-03	|	5

-- COMMAND ----------

CREATE TABLE Activity (
    player_id INT,
    device_id INT,
    event_date DATE,
    games_played INT
);

INSERT INTO Activity (player_id, device_id, event_date, games_played) VALUES (1, 2, '2016-03-01', 5);
INSERT INTO Activity (player_id, device_id, event_date, games_played) VALUES (1, 2, '2016-05-02', 6);
INSERT INTO Activity (player_id, device_id, event_date, games_played) VALUES (2, 3, '2017-06-25', 1);
INSERT INTO Activity (player_id, device_id, event_date, games_played) VALUES (3, 1, '2016-03-02', 0);
INSERT INTO Activity (player_id, device_id, event_date, games_played) VALUES (3, 4, '2018-07-03', 5);
select * from Activity;

-- COMMAND ----------

-- Write an SQL query that reports the first login date for each player.

SELECT player_id, MIN(event_date) as first_login FROM Activity
GROUP BY player_id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 14 -Write a SQL query that reports the device that is first logged in for each player. 

-- COMMAND ----------

WITH RankedActivity AS (
    SELECT 
        player_id, device_id,event_date,
        ROW_NUMBER() OVER (PARTITION BY player_id ORDER BY event_date) AS rn
    FROM 
        Activity
)
SELECT 
    player_id, device_id AS first_logged_in_device
FROM 
    RankedActivity
WHERE 
    rn = 1;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 15- write a SQL query that finds out managers with at least 5 direct report. 

-- COMMAND ----------

CREATE TABLE empmanager (
    Id INT,
    Name VARCHAR(50),
    Department VARCHAR(50),
    ManagerId INT
);

INSERT INTO empmanager (Id, Name, Department, ManagerId) VALUES (101, 'John', 'A', NULL);
INSERT INTO empmanager (Id, Name, Department, ManagerId) VALUES (102, 'Dan', 'A', 101);
INSERT INTO empmanager (Id, Name, Department, ManagerId) VALUES (103, 'James', 'A', 101);
INSERT INTO empmanager (Id, Name, Department, ManagerId) VALUES (104, 'Amy', 'A', 101);
INSERT INTO empmanager (Id, Name, Department, ManagerId) VALUES (105, 'Anne', 'A', 101);
INSERT INTO empmanager (Id, Name, Department, ManagerId) VALUES (106, 'Ron', 'B', 101);
select * from empmanager;

-- COMMAND ----------

SELECT 
    ManagerId, count(*) as manager_count
FROM 
    empmanager
GROUP BY 
    ManagerId
HAVING 
    COUNT(*) >= 5;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 16- Select all employee’s name and bonus whose bonus is < 1000.
-- MAGIC
-- MAGIC * Table:Employee
-- MAGIC * empld | name | supervisor| salary
-- MAGIC * 1	|	John	|	3	|	1000
-- MAGIC * 2	|	Dan	|	3	|	2000
-- MAGIC * 3	|	Brad	|	null	|	4000
-- MAGIC * 4	|	Thomas	|	3	|	4000
-- MAGIC
-- MAGIC * Table: Bonus
-- MAGIC * empld | bonus
-- MAGIC * 2	| 500
-- MAGIC * 4	| 2000

-- COMMAND ----------

--Select all employee’s name and bonus whose bonus is < 1000.

select e.name, b.bonus from employee as e
join bonus as b
on e.empid = b.empid  
where b.bonus <1000 or bonus is null

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 17- Write a query to print the respective department name and number of students majoring in each department for all departments in the department table.

-- COMMAND ----------

-- Create departmentt table
CREATE TABLE departmentttt (
    dept_id INT,
    dept_name VARCHAR(50)
);

-- Insert sample records into departmentt table
INSERT INTO departmentttt (dept_id, dept_name) VALUES (1, 'Engineering');
INSERT INTO departmentttt (dept_id, dept_name) VALUES (2, 'Science');
INSERT INTO departmentttt (dept_id, dept_name) VALUES (3, 'Law');
select * from departmentttt;

-- COMMAND ----------


-- Create studentt table
CREATE TABLE studentttt (
    student_id INT,
    student_name VARCHAR(50),
    gender VARCHAR(1),
    dept_id INT,
);

-- Insert sample records into studentt table
INSERT INTO studentttt (student_id, student_name, gender, dept_id) VALUES (1, 'Jack', 'M', 1);
INSERT INTO studentttt (student_id, student_name, gender, dept_id) VALUES (2, 'Jane', 'F', 1);
INSERT INTO studentttt (student_id, student_name, gender, dept_id) VALUES (3, 'Mark', 'M', 2);

select * from studentttt;

-- COMMAND ----------

SELECT 
    d.dept_id,
    d.dept_name,
    COUNT(s.student_id) AS num_students
FROM 
    departmentt d
LEFT JOIN 
    studentt s ON d.dept_id = s.dept_id
GROUP BY 
    d.dept_id, d.dept_name;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 18- Given a table customer holding customers information and the referee. Write a query to return the list of customers NOT referred by the person with id ‘2' 
-- MAGIC  
-- MAGIC * id	| name | referee_id
-- MAGIC * 1 |	Will	NULL
-- MAGIC * 2 |	Jane	NULL
-- MAGIC * 3 |	Alex	2
-- MAGIC * 4 |	Bill	NULL
-- MAGIC * 5 |	Zack	1
-- MAGIC * 6 |	Marl	2

-- COMMAND ----------

select name from table where referee_id <>2 or referee_id is Null;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 19- Write a query to find the customer number from the orders table for the customer who has placed the largest number of orders.
-- MAGIC * Column	Type	 
-- MAGIC * order_number (PK) | int 
-- MAGIC * customer_number | int 
-- MAGIC * order_date       | date
-- MAGIC * required_date    | date
-- MAGIC * shipped_date	| date
-- MAGIC * status	| char(15)
-- MAGIC * comment	| char(200)
-- MAGIC

-- COMMAND ----------

SELECT 
    customer_number
FROM 
    customer_order
GROUP BY 
    customer_number
ORDER BY
    COUNT(order_number) DESC
LIMIT 1;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 20- A country is big if it has an area of bigger than 3 million square km or a population of more than 25 million.
-- MAGIC * population of more than 25 million.
-- MAGIC * | name | continent | area | population | gdp |
-- MAGIC * | Afghanistan | Asia | 652230 | 25500100 | 20343000 |
-- MAGIC * | Albania | Europe | 28748 | 2831741 | 12960000 |
-- MAGIC * | Algeria | Africa | 2381741 | 37100000 | 188681000 |
-- MAGIC * | Andorra | Europe | 468 | 78115 | 3712000 |
-- MAGIC * | Angola | Africa | 1246700 | 20609294 | 100990000

-- COMMAND ----------

select name, area, population from world_table
where area> 2500000 and population > 3000000;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 21- There is a table courses With columns: student and class, Please list out all classes which have more than or equal to 5 students.
-- MAGIC
-- MAGIC * | student | class |
-- MAGIC * | A | Math |
-- MAGIC * | B | English |
-- MAGIC * | C | Math |
-- MAGIC * | D | Biology |
-- MAGIC * | E | Math |
-- MAGIC * | F | Computer |
-- MAGIC * | G | Math |
-- MAGIC * | H | Math |
-- MAGIC * | I | Math 

-- COMMAND ----------

SELECT class FROM courses 
GROUP BY class
HAVING count(DISTINCT Student)>=5;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 22- We have table called big_table having below records- num
-- MAGIC 8
-- MAGIC 8
-- MAGIC 3
-- MAGIC 3
-- MAGIC 1
-- MAGIC 4
-- MAGIC 6
-- MAGIC Can you write a SQL query to find the biggest number, which only appears once.

-- COMMAND ----------

select max(num) as big_number from table_name
group by num
having count(*)=1; 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 23- Write a SQL query to output movies with an odd numbered ID and a description that is not ‘boring' Order the result by rating?
-- MAGIC

-- COMMAND ----------

CREATE TABLE cinema (
    id INT PRIMARY KEY,
    movie VARCHAR(50),
    description VARCHAR(50),
    rating INT
);

INSERT INTO cinema (id, movie, description, rating) VALUES (1, 'War', 'great 3D', 8.9);
INSERT INTO cinema (id, movie, description, rating) VALUES (2, 'Science', 'fiction', 8.5);
INSERT INTO cinema (id, movie, description, rating) VALUES (3, 'irish', 'boring', 6.2);
INSERT INTO cinema (id, movie, description, rating) VALUES (4, 'Ice song', 'Fantacy', 8.6);
INSERT INTO cinema (id, movie, description, rating) VALUES (5, 'House card', 'Interesting', 9.1);
select * from cinema;

-- COMMAND ----------

SELECT *
FROM cinema
WHERE id % 2 <> 0 AND description <> 'boring'
ORDER BY rating;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 25-Write sql query to swap the sex column from m to f and vice versa with case when statement.

-- COMMAND ----------

-- Create male_female table
CREATE TABLE male_female (
    id INT,
    name VARCHAR(50),
    sex VARCHAR(1),
    salary int
);

-- Insert sample records into male_female table
INSERT INTO male_female (id, name, sex, salary) VALUES (1, 'A', 'm', 2500);
INSERT INTO male_female (id, name, sex, salary) VALUES (2, 'B', 'f', 1500);
INSERT INTO male_female (id, name, sex, salary) VALUES (3, 'C', 'm', 5500);
INSERT INTO male_female (id, name, sex, salary) VALUES (4, 'D', 'f', 500);
select * from male_female;

-- COMMAND ----------

UPDATE male_female
SET sex = 
    CASE 
        WHEN sex = 'm' THEN 'f'
        WHEN sex = 'f' THEN 'm'
    END;
-- OR

UPDATE male_female SET sex = CASE WHEN sex='m' THEN 'f' ELSE 'm' END

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 26- Write an SQL query to find the customer ids from the Customer table that bought all the products.

-- COMMAND ----------

-- Create cust_prod table
CREATE TABLE cust_prod (
    customer_id INT,
    product_key INT
);

-- Insert sample records into cust_prod table
INSERT INTO cust_prod (customer_id, product_key) VALUES (1, 5);
INSERT INTO cust_prod (customer_id, product_key) VALUES (5, 6);
INSERT INTO cust_prod (customer_id, product_key) VALUES (2, 6);
INSERT INTO cust_prod (customer_id, product_key) VALUES (3, 5);
INSERT INTO cust_prod (customer_id, product_key) VALUES (3, 6);
INSERT INTO cust_prod (customer_id, product_key) VALUES (1, 6);

-- Create prod_cust table
CREATE TABLE prod_cust (
    product_key INT
);

-- Insert sample records into prod_cust table
INSERT INTO prod_cust (product_key) VALUES (5);
INSERT INTO prod_cust (product_key) VALUES (6);
select * from cust_prod;

-- COMMAND ----------

select * from prod_cust;

-- COMMAND ----------

SELECT customer_id
FROM cust_prod
GROUP BY customer_id
HAVING COUNT(DISTINCT product_key) = (SELECT COUNT(*) FROM prod_cust);