# Databricks notebook source
# MAGIC %md
# MAGIC ##### Question 99- Write a query to replace the null value with previous records in sql server?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Creating temp_table
# MAGIC CREATE TABLE temp_table11 (
# MAGIC     temp_data INT
# MAGIC );
# MAGIC
# MAGIC -- Inserting records into temp_table
# MAGIC INSERT INTO temp_table11 (temp_data) VALUES
# MAGIC (40),
# MAGIC (38),
# MAGIC (39),
# MAGIC (NULL),
# MAGIC (40),
# MAGIC (NULL),
# MAGIC (40);
# MAGIC select * from temp_table11;

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH CTE AS (
# MAGIC     SELECT temp_data, LAG(temp_data) OVER (ORDER BY (SELECT NULL)) AS prev_temp_data
# MAGIC     FROM temp_table11
# MAGIC )
# MAGIC UPDATE CTE
# MAGIC SET temp_data = prev_temp_data
# MAGIC WHERE temp_data IS NULL;
# MAGIC select * from temp_table11;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 100- Write a query to replace the null value with next records in sql server?

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH CTE AS (
# MAGIC     SELECT temp_data, LEAD(temp_data) OVER (ORDER BY (SELECT NULL)) AS next_temp_data
# MAGIC     FROM temp_table
# MAGIC )
# MAGIC UPDATE CTE
# MAGIC SET temp_data = next_temp_data
# MAGIC WHERE temp_data IS NULL;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 101- Is it possible to replace the first row null value with fifth row value for ex- null will get replace with 40?
# MAGIC * Yes, it's possible to replace the first occurrence of a NULL value with the value from the fifth row. 

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE temp_table
# MAGIC SET temp_data = (SELECT TOP 1 temp_data FROM temp_table WHERE temp_data IS NOT NULL ORDER BY (SELECT NULL))
# MAGIC WHERE temp_data IS NULL;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 102- How to convert dataframe into list?

# COMMAND ----------

## Method 1 - by using for loop
# Assuming df is your DataFrame
data = [("John", 25), ("Alice", 30), ("Bob", 35)]
columns = ["Name", "Age"]
df = spark.createDataFrame(data, columns)
# Collect DataFrame into a list of Row objects
data_list = df.collect()


# COMMAND ----------

# Create an empty list to store the result
python_list = []

# Iterate over each Row object in the data_list
for i in data_list:
    # Append the Row object to the python_list
    python_list.append(i)

# After the loop, python_list will contain all rows of the DataFrame as tuples
print(python_list)

# COMMAND ----------

# Assuming df is your DataFrame
data = [("John", 25), ("Alice", 30), ("Bob", 35)]
columns = ["Name", "Age"]
df = spark.createDataFrame(data, columns)

py_list =[]
for i in df:
    py_list.append(i)
print(py_list)


# COMMAND ----------

## Method 2 by using flatmap
# Assuming your DataFrame is named 'df'
name_list = df.select('Name').rdd.flatMap(lambda x: x).collect()
age_list = df.select('Age').rdd.flatMap(lambda x: x).collect()

# COMMAND ----------

print(name_list)
print(age_list)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 103- How to convert dataframe into Dict?

# COMMAND ----------

from pyspark.sql import SparkSession

# Create a SparkSession
spark = SparkSession.builder \
    .appName("DataFrame to Dictionary") \
    .getOrCreate()

# Assuming df is your DataFrame
data = [("John", 25), ("Alice", 30), ("Bob", 35)]
columns = ["Name", "Age"]
df = spark.createDataFrame(data, columns)

# Collect DataFrame into a list of Row objects
data_list = df.collect()

# Convert Row objects into a list of dictionaries
python_dict_list = [row.asDict() for row in data_list]

print(python_dict_list)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 104-What will be output of below result?

# COMMAND ----------

data = [("cat", 1), ("dog", 2), ("cat", 3), ("dog", 4)]

rdd = sc.parallelize(data)

sum_rdd = rdd.reduceByKey(lambda x, y: x + y)

print(sum_rdd.collect())

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 105 -What will be output of below result?

# COMMAND ----------

data = [("cat", 1), ("dog", 2), ("cat", 3), ("dog", 4)]
rdd = sc.parallelize(data)
grouped_rdd = rdd.groupByKey()
print(grouped_rdd.collect())

# The output consists of tuples where the first element is the key (e.g., 'cat', 'dog') and the second element is a ResultIterable object. The ResultIterable object represents an iterable containing all the values associated with the respective key. However, it doesn't directly show the values in the output. If you want to see the values associated with each key, you would need to iterate over the ResultIterable objects.

# COMMAND ----------

Quesion 106- 
i have two tables in sql servers, orders and items having following records- Orders
order_id item_id store_id 	date	      	qty_sold
1		1			1		07-07-2020		12
2		1			1		07-01-2020		71
3		1			2		07-07-2020		7
4		2			3		07-07-2020		85
5		2			3		07-09-2020		53
6		3			3		07-07-2020		17
7	 	3	 	 
	 	 	 	 
Items
itemid	item_name	price
1	Pen		        10
2	Water Bottle	100
3	Eraser		    5
4	Soap		    20
5	brush		    25
 	T-Shirt		    150, 
Write a query to find the result like- store_id, date, total_sale_amt, diff betwn total_sale amount of that day and previous_day.

# COMMAND ----------

WITH Sales AS (
    SELECT 
        o.store_id,
        o.date,
        SUM(o.qty_sold * i.price) AS total_sale_amt,
        LAG(SUM(o.qty_sold * i.price)) OVER (PARTITION BY o.store_id ORDER BY o.date) AS prev_day_sale_amt
    FROM 
        Orders o
    INNER JOIN 
        Items i ON o.item_id = i.itemid
    WHERE 
        o.qty_sold IS NOT NULL
    GROUP BY 
        o.store_id, o.date
)
SELECT 
    store_id,
    date,
    total_sale_amt,
    ISNULL(total_sale_amt - prev_day_sale_amt, 0) AS diff_prev_day_sale_amt
FROM 
    Sales
ORDER BY 
    store_id, date;


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Questiono 107- Write a pyspark code to get the top 5 customers (who spent most) who ordered BURGER (prod_name) in last month?
# MAGIC 1.Customer
# MAGIC Cust_id, cust_name 
# MAGIC
# MAGIC 2.Product
# MAGIC Prod_id, prod_name, Prod_price
# MAGIC
# MAGIC 3.Sales
# MAGIC Cust_id, prod_id, quantity, amt_paid, date
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import sum, desc
from pyspark.sql.window import Window

# Assuming you have already loaded your data into DataFrames: customer, product, and sales
# Let's assume sales_df contains the sales data

# Filter BURGER orders from the last month
last_month_sales_df = sales_df.filter((sales_df.prod_name == "BURGER") & (sales_df.date >= "2024-04-01") & (sales_df.date < "2024-05-01"))

# Calculate total spending per customer
customer_spending_df = last_month_sales_df.groupBy("Cust_id").agg(sum("amt_paid").alias("total_spending"))

# Rank customers by total spending
window_spec = Window.orderBy(desc("total_spending"))
ranked_customers_df = customer_spending_df.withColumn("rank", dense_rank().over(window_spec))

# Select the top 5 customers
top_5_customers_df = ranked_customers_df.filter(rank <= 5)

# Show the result
top_5_customers_df.show()

# COMMAND ----------

# MAGIC %sql  -- Method 2- SQL Solution 
# MAGIC SELECT TOP 5
# MAGIC     s.Cust_id,
# MAGIC     SUM(s.amt_paid) AS total_spending
# MAGIC FROM
# MAGIC     Sales s
# MAGIC JOIN
# MAGIC     Product p ON s.prod_id = p.Prod_id
# MAGIC WHERE
# MAGIC     p.prod_name = 'BURGER'
# MAGIC     AND s.date >= DATEADD(MONTH, -1, GETDATE())
# MAGIC GROUP BY
# MAGIC     s.Cust_id
# MAGIC ORDER BY
# MAGIC     total_spending DESC;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 108- We have below table 
# MAGIC * 1	10:30 
# MAGIC * 2	10:30 
# MAGIC * 3	10:30   
# MAGIC * 3	10:31   
# MAGIC * 4	10:31
# MAGIC
# MAGIC * want to remove duplicate and Time which has latest time 
# MAGIC
# MAGIC * output should be like
# MAGIC * user_id	timestamp
# MAGIC * 1	10:30 
# MAGIC * 2	10:30 
# MAGIC * 3	10:31   
# MAGIC * 4	10:31

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE rem_dup_time (
# MAGIC     user_id INT,
# MAGIC     timestamp TIME
# MAGIC );
# MAGIC
# MAGIC INSERT INTO rem_dup_time (user_id, timestamp) VALUES
# MAGIC (1, '10:30'),
# MAGIC (2, '10:30'),
# MAGIC (3, '10:30'),
# MAGIC (3, '10:31'),
# MAGIC (4, '10:31');
# MAGIC select * from rem_dup_time;

# COMMAND ----------

# MAGIC %sql -- Method 1 - by using max, min function
# MAGIC SELECT user_id, MAX(timestamp) AS timestamp
# MAGIC FROM rem_dup_time
# MAGIC GROUP BY user_id;
# MAGIC

# COMMAND ----------

# MAGIC %sql -- By using CTE
# MAGIC
# MAGIC WITH LatestTimestamp AS (
# MAGIC     SELECT user_id, MAX(timestamp) AS latest_timestamp
# MAGIC     FROM rem_dup_time
# MAGIC     GROUP BY user_id
# MAGIC )
# MAGIC SELECT t.user_id, t.timestamp
# MAGIC FROM rem_dup_time t
# MAGIC INNER JOIN LatestTimestamp lt ON t.user_id = lt.user_id AND t.timestamp = lt.latest_timestamp;

# COMMAND ----------

# Create a widget to input the table name
dbutils.widgets.text("table_name", "default_table_name", "Enter Table Name")

# Read the table name from the widget
table_name = dbutils.widgets.get("table_name")

# Create DataFrame using the table name
data_df = spark.table(table_name)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 109- Find the customerid who brought all the prodctds from below tables?
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create product_table
# MAGIC CREATE TABLE product_table33 (
# MAGIC     product_id INT,
# MAGIC     product_name VARCHAR(50)
# MAGIC );
# MAGIC
# MAGIC -- Insert records into product_table
# MAGIC INSERT INTO product_table33 (product_id, product_name) VALUES
# MAGIC (5, 'A'),
# MAGIC (6, 'B'),
# MAGIC (5, 'C');
# MAGIC select * from product_table33;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Create customer_table
# MAGIC CREATE TABLE customer_table33 (
# MAGIC     customer_id INT,
# MAGIC     product_id INT
# MAGIC );
# MAGIC
# MAGIC -- Insert records into customer_table
# MAGIC INSERT INTO customer_table33 (customer_id, product_id) VALUES
# MAGIC (1, 5),
# MAGIC (2, 6),
# MAGIC (3, 5),
# MAGIC (3, 6),
# MAGIC (1, 6);
# MAGIC select * from customer_table33;

# COMMAND ----------

# MAGIC %sql --Find the customerid who brought all the prodctds from below tables?
# MAGIC
# MAGIC SELECT c.customer_id
# MAGIC FROM customer_table33 c
# MAGIC JOIN product_table33 p ON c.product_id = p.product_id
# MAGIC GROUP BY c.customer_id
# MAGIC HAVING COUNT( p.product_id) = (SELECT COUNT(*) FROM product_table33);
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 110-
# MAGIC * L1 = [6,7,8,9]
# MAGIC * L2 = [10,11,12,[1,2,3,4]]
# MAGIC * Flat the list L2 and merge with L1.

# COMMAND ----------

# Define the lists
L1 = [6, 7, 8, 9]
L2 = [10, 11, 12, [1, 2, 3, 4]]

# Convert lists to RDDs
rdd_L1 = spark.sparkContext.parallelize(L1)
rdd_L2 = spark.sparkContext.parallelize(L2)

# Flatten list L2 and merge with L1
rdd_result = rdd_L1.union(rdd_L2.flatMap(lambda x: x if isinstance(x, list) else [x]))

# Collect the result as a list
result = rdd_result.collect()

print(result)


# COMMAND ----------

## Method 2- 
# Define the lists
L1 = [6, 7, 8, 9]
L2 = [10, 11, 12, [1, 2, 3, 4]]

# Flatten list L2 and merge with L1
for i in L2:
    if isinstance(i, list):
        L1.extend(i)
    else:
        L1.append(i)

print(L1)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 111- Write a query in sql server to find the running total based on salary field?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Employees table
# MAGIC CREATE TABLE running_total (
# MAGIC     emp_id INT,
# MAGIC     name VARCHAR(100),
# MAGIC     salary int,
# MAGIC     dept VARCHAR(50)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into the Employees table
# MAGIC INSERT INTO running_total (emp_id, name, salary, dept) VALUES
# MAGIC (1, 'Alice', 60000, 'HR'),
# MAGIC (2, 'Bob', 70000, 'Finance'),
# MAGIC (3, 'Charlie', 50000, 'IT'),
# MAGIC (4, 'David', 80000, 'Finance'),
# MAGIC (5, 'Eve', 75000, 'HR');
# MAGIC select * from running_total;

# COMMAND ----------

# MAGIC %sql
# MAGIC select emp_id, name, salary, dept, sum(salary) over(order by emp_id) as running from running_total;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 112- We have str1 = 'gaurav is good engineer', write code in python to find the vovels from string?

# COMMAND ----------

# Define the string
str1 = 'gaurav is a good engineer'

# Define the set of vowels
vowels = 'aeiouAEIOU'
output = []

for i in str1:
    if i in vowels:
        output.append(i)
print(output)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 113- Find odd or even number?

# COMMAND ----------

# Define the number
a = 999

# Check if the number is even or odd
if a % 2 == 0:
    print(f"{a} is an even number")
else:
    print(f"{a} is an odd number")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 114- Each table has play only once, no repetition?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE no_repeat_country (
# MAGIC     Country_name CHAR(1)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO no_repeat_country (Country_name) VALUES ('A'), ('B'), ('C'), ('D');
# MAGIC select * from no_repeat_country;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT c1.Country_name AS Country1, c2.Country_name AS Country2
# MAGIC FROM no_repeat_country c1
# MAGIC JOIN no_repeat_country c2 ON c1.Country_name < c2.Country_name;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 115- Column_1 Column_2 Column_3
# MAGIC  
# MAGIC A N1 P1
# MAGIC  
# MAGIC A N2 P2
# MAGIC  
# MAGIC A N3 P3
# MAGIC  
# MAGIC B N1 P1
# MAGIC  
# MAGIC C N1 P1
# MAGIC  
# MAGIC C N2 P2
# MAGIC  
# MAGIC Required Output in spark:
# MAGIC  
# MAGIC Column_1 Column_2 Column_3
# MAGIC  
# MAGIC A        N3,N2,N1 P1,P2,P3
# MAGIC  
# MAGIC B         N1       P1
# MAGIC  
# MAGIC C        N2,N1     P1,P2

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import collect_list, concat_ws

# Initialize Spark session
spark = SparkSession.builder.appName("AggregateColumns").getOrCreate()

# Create the DataFrame
data = [
    ("A", "N1", "P1"),
    ("A", "N2", "P2"),
    ("A", "N3", "P3"),
    ("B", "N1", "P1"),
    ("C", "N1", "P1"),
    ("C", "N2", "P2")
]

columns = ["Column_1", "Column_2", "Column_3"]
df = spark.createDataFrame(data, columns)
df.show()

# Group by Column_1 and aggregate the other columns
result_df = df.groupBy("Column_1").agg(
    concat_ws(",", collect_list("Column_2")).alias("Column_2"),
    concat_ws(",", collect_list("Column_3")).alias("Column_3")
)

# Show the result
result_df.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 116- Find the companies who have atleast 2 users who speak both English and German?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE UserLanguages (
# MAGIC     company_id VARCHAR(10),
# MAGIC     user_id INT,
# MAGIC     language VARCHAR(50)
# MAGIC );
# MAGIC INSERT INTO UserLanguages (company_id, user_id, language) VALUES
# MAGIC     ('A', 1, 'English'),
# MAGIC     ('A', 1, 'German'),
# MAGIC     ('A', 2, 'English'),
# MAGIC     ('A', 2, 'German'),
# MAGIC     ('A', 3, 'German'),
# MAGIC     ('B', 1, 'English'),
# MAGIC     ('B', 2, 'German'),
# MAGIC     ('C', 1, 'English'),
# MAGIC     ('C', 2, 'German');
# MAGIC select * from UserLanguages;

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH UsersWithLanguages AS (
# MAGIC     SELECT
# MAGIC         company_id,user_id,
# MAGIC         COUNT(DISTINCT language) AS lang_count
# MAGIC     FROM
# MAGIC         UserLanguages
# MAGIC     WHERE
# MAGIC         language IN ('English', 'German')
# MAGIC     GROUP BY
# MAGIC         company_id, user_id
# MAGIC     HAVING
# MAGIC         COUNT(DISTINCT language) = 2
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     company_id
# MAGIC FROM
# MAGIC     UsersWithLanguages
# MAGIC GROUP BY
# MAGIC     company_id
# MAGIC HAVING
# MAGIC     COUNT(user_id) >= 2;
# MAGIC

# COMMAND ----------

s = 'aabbccdd'
result = '-'.join(s[i:i+2] for i in range(0, len(s), 2))
print(result)

# COMMAND ----------

s = 'gaurav'
length = 2
insert = "$"

# Initialize an empty string to store the result
result = ""

# Iterate through the string with a step of 'length'
for i in range(0, len(s), length):
    # Add the current substring and the insert character
    result += s[i:i+length] + insert

# Since the loop will add an extra insert character at the end, we remove it
result = result[:-1]
print(result)

# COMMAND ----------

s = 'gaurav'
length = 2
insert = "$"

result = ""
for i in range(0, len(s), length):

    result += s[i:i+length] + insert

# Since the loop will add an extra insert character at the end, we remove it
result = result[:-1]

print(result)

# COMMAND ----------

s = 'aabbccdd'
result = ''
for i in range(0, len(s), 2):
    result += s[i:i+2] + '-'
result = result[:-1]  # Remove the trailing hyphen
print(result)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 117- 
# MAGIC L1 =['orange']
# MAGIC L2 = ['oranges']
# MAGIC How to compare this two list word by word in python for ex- o compare to o then r compare to r and so on but in L2, there is extra word s? 

# COMMAND ----------

L1 = ['orange']
L2 = ['oranges']
compare = []
for a, b in zip(L1, L2):
    compare.append(a == b)
print(compare)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 118- Write a query which shows % of covid_patient in MH?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE CovidData (
# MAGIC     city VARCHAR(50),
# MAGIC     state VARCHAR(2),
# MAGIC     num_of_covid_patient INT
# MAGIC );
# MAGIC INSERT INTO CovidData (city, state, num_of_covid_patient) VALUES
# MAGIC ('pune', 'MH', 50),
# MAGIC ('mumbai', 'MH', 100),
# MAGIC ('nagpur', 'MA', 75),
# MAGIC ('ratnagiri', 'MH', 125);
# MAGIC select * from CovidData;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Step 1: Calculate the total number of COVID-19 patients in MH
# MAGIC WITH TotalMH AS (
# MAGIC     SELECT SUM(num_of_covid_patient) AS total_mh_patients
# MAGIC     FROM CovidData
# MAGIC     WHERE state = 'MH'
# MAGIC )
# MAGIC
# MAGIC -- Step 2: Calculate the percentage of COVID-19 patients for each city in MH
# MAGIC SELECT 
# MAGIC     city, 
# MAGIC     state, 
# MAGIC     num_of_covid_patient,
# MAGIC     CASE 
# MAGIC         WHEN state = 'MH' THEN (num_of_covid_patient * 100.0 / total_mh_patients)
# MAGIC         ELSE NULL
# MAGIC     END AS pct_of_covid_patient_in_MH
# MAGIC FROM 
# MAGIC     CovidData, TotalMH;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 119- We have table called emp_sal having columns- emp_id, name, salary, write a query in sql to find employee having same name but different salary?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE emp_sal (
# MAGIC     emp_id INT,
# MAGIC     name VARCHAR(50),
# MAGIC     salary INT
# MAGIC );
# MAGIC INSERT INTO emp_sal (emp_id, name, salary) VALUES
# MAGIC (1, 'Alice', 50000),
# MAGIC (2, 'Bob', 60000),
# MAGIC (3, 'Alice', 70000),
# MAGIC (4, 'Charlie', 60000),
# MAGIC (5, 'Bob', 60000),
# MAGIC (6, 'Alice', 50000),
# MAGIC (7, 'Charlie', 70000);
# MAGIC select * from emp_sal;

# COMMAND ----------

# MAGIC %sql  --Method 1
# MAGIC SELECT DISTINCT e1.emp_id, e1.name, e1.salary
# MAGIC FROM emp_sal e1
# MAGIC JOIN emp_sal e2
# MAGIC     ON e1.name = e2.name
# MAGIC     AND e1.salary <> e2.salary
# MAGIC ORDER BY e1.name, e1.salary;
# MAGIC

# COMMAND ----------

# MAGIC %sql  --Method 2
# MAGIC WITH NameCounts AS (
# MAGIC     SELECT 
# MAGIC         emp_id,
# MAGIC         name,
# MAGIC         salary,
# MAGIC         COUNT(DISTINCT salary) OVER (PARTITION BY name) AS salary_count
# MAGIC     FROM emp_sal
# MAGIC )
# MAGIC SELECT 
# MAGIC     emp_id, 
# MAGIC     name, 
# MAGIC     salary
# MAGIC FROM 
# MAGIC     NameCounts
# MAGIC WHERE 
# MAGIC     salary_count > 1
# MAGIC ORDER BY 
# MAGIC     name, salary;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 120- I have one string in python - Str1 = ‘VIJAY’, write a python program that takes string as an input and return first non-repeated character, if all character are repeated then return None, for ex- V is first non repeated character?

# COMMAND ----------

Str1 = 'VIJAY'
result = ''
for i in str1:
	if i in result:
		result(i) +=1
	else:
		Result(i) =1
print(result)


# COMMAND ----------

Str1 = 'VIJAY'
char_count = {}

# Count occurrences of each character
for char in Str1:
    if char in char_count:
        char_count[char] += 1
    else:
        char_count[char] = 1

# Find the first non-repeated character
result = None
for char in Str1:
    if char_count[char] == 1:
        result = char
        break

print(result)  # Output: 'V'


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 121- Remove negative value and do addition of remaining all positive values using Python?

# COMMAND ----------

# Method 1
check = [-1, 1, -2, 2, 3, -3, 4, -4, 5, -5]
output = []
for i in check:
    if i >0:
        output.append(i)
new_output = sum(output)
print(new_output)

# COMMAND ----------

## Method - 2
check = [-1, 1, -2, 2, 3, -3, 4, -4, 5, -5]

# Filter out negative values
positive_values = [x for x in check if x > 0]

# Calculate the sum of remaining positive values
sum_of_positive_values = sum(positive_values)

print("Sum of positive values:", sum_of_positive_values)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 122- Remove negative value and do addition of remaining all positive values using SQL?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Step 1: Create the table
# MAGIC CREATE TABLE Numbers11 (
# MAGIC     value INT
# MAGIC );
# MAGIC
# MAGIC -- Step 2: Insert the values
# MAGIC INSERT INTO Numbers11 (value) VALUES
# MAGIC (-1), (1), (-2), (2), (3), (-3), (4), (-4), (5), (-5);
# MAGIC select * from Numbers11;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select sum(value) as sum_of_positive_numbers from Numbers11
# MAGIC where value>0;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 123- Write a query in sql to find the total sale for each customer, including customer which havent made any sale?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE cust_table11 (
# MAGIC     cust_id INT,
# MAGIC     name VARCHAR(50),
# MAGIC     address VARCHAR(100)
# MAGIC );
# MAGIC -- Insert records into cust_table11
# MAGIC INSERT INTO cust_table11 (cust_id, name, address) VALUES
# MAGIC (1, 'Alice', '123 Maple St'),
# MAGIC (2, 'Bob', '456 Oak St'),
# MAGIC (3, 'Charlie', '789 Pine St');
# MAGIC select * from cust_table11;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE sale_table11 (
# MAGIC     sale_id INT,
# MAGIC     cust_id INT,
# MAGIC     sale int
# MAGIC );
# MAGIC -- Insert records into sale_table11
# MAGIC INSERT INTO sale_table11 (cust_id, sale) VALUES
# MAGIC (1, 100.00),
# MAGIC (1, 150.00),
# MAGIC (2, 200.00);
# MAGIC select * from sale_table11;

# COMMAND ----------

# MAGIC %sql -- Write a query in sql to find the total sale for each customer, including customer which havent made any sale
# MAGIC SELECT 
# MAGIC     c.cust_id,
# MAGIC     c.name,
# MAGIC     c.address,
# MAGIC     SUM(s.sale) AS total_sale
# MAGIC FROM 
# MAGIC     cust_table11 c
# MAGIC LEFT JOIN 
# MAGIC     sale_table11 s
# MAGIC ON 
# MAGIC     c.cust_id = s.cust_id
# MAGIC GROUP BY 
# MAGIC     c.cust_id, c.name, c.address
# MAGIC ORDER BY 
# MAGIC     c.cust_id;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 124- Write a program in sql server to find product_id whose sales is max in year for 2021.

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE product_table222 (
# MAGIC     product_id INT,
# MAGIC     date DATE,
# MAGIC     sales_amount INT
# MAGIC );
# MAGIC INSERT INTO product_table222 (product_id, date, sales_amount) VALUES
# MAGIC (1, '2021-01-01', 1000),
# MAGIC (2, '2021-01-01', 1500),
# MAGIC (1, '2021-01-02', 1200),
# MAGIC (2, '2021-01-02', 1800),
# MAGIC (1, '2021-01-03', 900),
# MAGIC (2, '2021-01-03', 2000),
# MAGIC (1, '2021-02-01', 1100),
# MAGIC (2, '2021-02-01', 1600),
# MAGIC (1, '2021-02-02', 1300),
# MAGIC (2, '2021-02-02', 2200),
# MAGIC (1, '2021-02-03', 1400),
# MAGIC (2, '2021-02-03', 2400);
# MAGIC select * from product_table222;

# COMMAND ----------

# MAGIC %sql -- Method 1
# MAGIC WITH ProductSales AS (
# MAGIC     SELECT 
# MAGIC         product_id,SUM(sales_amount) AS total_sales
# MAGIC     FROM product_table222
# MAGIC     WHERE YEAR(date) = 2021
# MAGIC     GROUP BY product_id
# MAGIC )
# MAGIC SELECT product_id, total_sales
# MAGIC FROM ProductSales
# MAGIC WHERE 
# MAGIC     total_sales = (SELECT MAX(total_sales) FROM ProductSales);
# MAGIC

# COMMAND ----------

# MAGIC %sql  -- Method 2
# MAGIC SELECT 
# MAGIC     product_id,YEAR(date) AS year,
# MAGIC     SUM(sales_amount) AS total_sales
# MAGIC FROM 
# MAGIC     product_table222
# MAGIC WHERE 
# MAGIC     YEAR(date) = 2021
# MAGIC GROUP BY 
# MAGIC     product_id, YEAR(date)
# MAGIC HAVING 
# MAGIC     SUM(sales_amount) = (
# MAGIC         SELECT 
# MAGIC             MAX(total_sales)
# MAGIC         FROM 
# MAGIC             (
# MAGIC                 SELECT 
# MAGIC                     product_id,
# MAGIC                     SUM(sales_amount) AS total_sales
# MAGIC                 FROM 
# MAGIC                     product_table222
# MAGIC                 WHERE 
# MAGIC                     YEAR(date) = 2021
# MAGIC                 GROUP BY 
# MAGIC                     product_id
# MAGIC             ) AS subquery
# MAGIC     );

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 125- Write a query in sql server to find if firstname is null, it should extract from middlename and if middlename is null, it should extract from lastname?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE family_name (
# MAGIC     first_name VARCHAR(50),
# MAGIC     middle_name VARCHAR(50),
# MAGIC     last_name VARCHAR(50)
# MAGIC );
# MAGIC INSERT INTO family_name (first_name, middle_name, last_name) VALUES
# MAGIC ('John', 'Michael', 'Doe'),
# MAGIC (NULL, 'Paul', 'Smith'),
# MAGIC (NULL, NULL, 'Johnson'),
# MAGIC ('Peter', NULL, NULL);
# MAGIC select * from family_name;

# COMMAND ----------

# MAGIC %sql -- Method 1
# MAGIC SELECT 
# MAGIC     first_name, 
# MAGIC     middle_name, 
# MAGIC     last_name, 
# MAGIC     CASE
# MAGIC         WHEN first_name IS NULL THEN middle_name
# MAGIC         WHEN middle_name IS NULL THEN last_name
# MAGIC         ELSE 'no_name'
# MAGIC     END AS family_name
# MAGIC FROM 
# MAGIC     family_name;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 126- Write sql and pyspark query to find distance travelled by each car everyday, the distance here is a cumulative sum?

# COMMAND ----------

from pyspark.sql.functions import lag, col, floor
from pyspark.sql.window import Window

# Sample data
data = [
    ("car1", "Day1", 50),
    ("car2", "Day1", 120),
    ("car1", "Day2", 100),
    ("car1", "Day3", 200),
    ("car2", "Day2", 260),
    ("car2", "Day3", 300)
]

# Create a DataFrame
df = spark.createDataFrame(data, ["CAR", "DAYS", "DISTANCE"])

# Define window specification
wind_spec = Window.partitionBy('CAR').orderBy('DAYS')

# Calculate the previous distance using lag function
df = df.withColumn('prev_distance', floor(lag('DISTANCE').over(wind_spec)))

# Calculate the total distance
df = df.withColumn('total_distance', col('DISTANCE') - col('prev_distance'))

# Select required columns
df2 = df.select('CAR', 'total_distance')

# Show the result
df2.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 127- We have id, name, gender, age columns,
# MAGIC * 1- read this table into dataframe
# MAGIC * 2- then select only two columns gender and avg_age
# MAGIC * 3- write into delta table
# MAGIC id	name	gender Age
# MAGIC 101	alex	M	 20
# MAGIC 102	betty	F	 25
# MAGIC 103	mark	M	 28
# MAGIC 104	Hanna	F	 30
# MAGIC
# MAGIC gender, avg_age
# MAGIC
# MAGIC
# MAGIC file_path = ('dbfs:/silver.file.csv')
# MAGIC
# MAGIC read file, 
# MAGIC
# MAGIC df = spark.read.csv(file_path)\
# MAGIC 	.option(inferSchema =  true)
# MAGIC 	.option(header =  true)
# MAGIC
# MAGIC df.createOrReplaceTempView(cust_id)
# MAGIC
# MAGIC spark.sql(select gender, avg(Age) as avg_age from cust_id
# MAGIC group by gender)
# MAGIC
# MAGIC
# MAGIC df = spark.write.format(delta).load(file_path).saveAsTable('cust_table')
# MAGIC
# MAGIC
# MAGIC df_new = df.groupBy('gender').agg(avg('Age').alias('avg_age))
# MAGIC df_new.show()

# COMMAND ----------

# Step 1: Read the CSV file from ADLS into a DataFrame
file_path = '/mnt/your_mount_point/your_file.csv'
df = spark.read.csv(file_path, header=True, inferSchema=True)

# Step 2: Select the 'gender' and 'age' columns
selected_df = df.select('gender', 'Age')

# Step 3: Calculate the average age by gender
avg_age_df = selected_df.groupBy('gender').avg('Age').alias('avg_age')

# Step 4: Write the resulting DataFrame into a Delta table
avg_age_df.write.format("delta").mode("overwrite").save("/mnt/your_mount_point/delta_table")

# To create a Delta table in the metastore, you can use:
spark.sql("CREATE TABLE IF NOT EXISTS delta_table USING DELTA LOCATION '/mnt/your_mount_point/delta_table'")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 128- 
# MAGIC * id	name	subjects
# MAGIC
# MAGIC 101	alex	english, maths, science
# MAGIC
# MAGIC 102	betty	maths, science
# MAGIC
# MAGIC 103	mark	english

# COMMAND ----------

df1 = df.withColumn('new_subject', explode(split(('subjects'), ',',' ')

df2 = df.select('id', 'name','new_subject')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 129- convert rows into columns using SQL?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the initial table
# MAGIC CREATE TABLE StudentMarks (
# MAGIC     Name NVARCHAR(50),
# MAGIC     Subject NVARCHAR(50),
# MAGIC     Marks INT
# MAGIC );
# MAGIC
# MAGIC -- Insert the data
# MAGIC INSERT INTO StudentMarks (Name, Subject, Marks) VALUES
# MAGIC ('Rohan', 'Maths', 89),
# MAGIC ('Rohan', 'Science', 88),
# MAGIC ('Rohan', 'Eng', 96),
# MAGIC ('Puja', 'Maths', 85),
# MAGIC ('Puja', 'Science', 79),
# MAGIC ('Puja', 'Eng', 87);
# MAGIC select * from StudentMarks;
# MAGIC -- Use conditional aggregation to transform the data

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     Name,
# MAGIC     MAX(CASE WHEN Subject = 'Maths' THEN Marks ELSE NULL END) AS Maths,
# MAGIC     MAX(CASE WHEN Subject = 'Science' THEN Marks ELSE NULL END) AS Science,
# MAGIC     MAX(CASE WHEN Subject = 'Eng' THEN Marks ELSE NULL END) AS Eng
# MAGIC FROM 
# MAGIC     StudentMarks
# MAGIC GROUP BY 
# MAGIC     Name;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 130- Convert rows into columns using Pyspark?

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import max

# Initialize a Spark session
spark = SparkSession.builder.appName("StudentMarks").getOrCreate()

# Sample data
data = [
    ("Rohan", "Maths", 89),
    ("Rohan", "Science", 88),
    ("Rohan", "Eng", 96),
    ("Puja", "Maths", 85),
    ("Puja", "Science", 79),
    ("Puja", "Eng", 87)
]

# Create a DataFrame
columns = ["Name", "Subject", "Marks"]
df = spark.createDataFrame(data, columns)

# Pivot the data
pivot_df = df.groupBy("Name").pivot("Subject").agg(max("Marks"))

# Show the result
pivot_df.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 131- str1 = 'my name is gaurav', can you count each word using pyspark?

# COMMAND ----------

from pyspark.sql.functions import split, size

# Create a DataFrame with the given string
str1 = "my name is gaurav"
data = [(str1,)]
df = spark.createDataFrame(data, ["text"])

# Split the string into words and count them
df_with_words = df.withColumn("words", split("text", " "))
df_with_word_count = df_with_words.withColumn("wordCount", size("words"))

# Show the result
df_with_word_count.show()
