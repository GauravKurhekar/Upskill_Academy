-- Databricks notebook source
-- Create table COMPANY2 for practice
CREATE TABLE COMPANY3(
EMPLOYEE_ID INT,
EMPLOYEE_NAME VARCHAR(10),
DEPARTMENT_NAME VARCHAR(10),
SALARY INT);

-- COMMAND ----------

INSERT INTO COMPANY3 VALUES(1,'MAYUR','IT',50000);
INSERT INTO COMPANY3 VALUES(2,'SHINDE','MRKT',30000);
INSERT INTO COMPANY3 VALUES(3,'MANU','HR',40000);
INSERT INTO COMPANY3 VALUES(4,'ASHU','MRKT',50000);

INSERT INTO COMPANY3 VALUES(5,'VARUN','IT',50000);
INSERT INTO COMPANY3 VALUES(6,'ASHA','HR',40000);
INSERT INTO COMPANY3 VALUES(7,'SHINDE','HR',50000);
INSERT INTO COMPANY3 VALUES(8,'ARJUN','IT',70000);
INSERT INTO COMPANY3 VALUES(1,'RAM','HR',10000);
INSERT INTO COMPANY3 VALUES(2,'AMRIT','MRKT',20000);
INSERT INTO COMPANY3 VALUES(3,'RAVI','HR',30000);
INSERT INTO COMPANY3 VALUES(4,'NITIN','MRKT',40000);

-- COMMAND ----------

select * from COMPANY3

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q-1 How to find duplicate records in employee table?
-- MAGIC * 1- use employee_id, count(*)
-- MAGIC * 2- use row_number() for finding dupicate, dont use rank() and dense_rank()

-- COMMAND ----------

select EMPLOYEE_ID, count(*) from COMPANY3 
group by EMPLOYEE_ID
having count(*)>1;

-- COMMAND ----------

select *, row_number() over(partition by EMPLOYEE_ID ORDER BY EMPLOYEE_ID) AS duplicate from COMPANY3

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####Q2- How to delete duplicate records from from Employee table using CTE?

-- COMMAND ----------

with CTE as (
  select *, row_number() over(partition by employee_id order by employee_id) as duplicate_record from COMPANY3
)
delete from CTE where duplicate_record>1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q3- How to find second highest salary from employee table?

-- COMMAND ----------

with cte as (
select *, dense_rank() over(order by salary desc) as second_sal from company3
)
select salary from cte where second_sal =2

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q4- How to find second highest salary from employee table without rank and cte?

-- COMMAND ----------

select max(salary) from company3 where salary not in (select max(salary)from COMPANY3)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q5- How to find second highest salary from employee table by each department wise?

-- COMMAND ----------

with cte as (
  select salary, dense_rank() over(partition by department_name order by salary desc) as second_rank from COMPANY3
)
select salary from cte where second_rank =2

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q6- Write a query to display running total or cumulative sum from employee table?

-- COMMAND ----------

select EMPLOYEE_ID, EMPLOYEE_NAME, DEPARTMENT_NAME, SALARY, SUM(SALARY) over (order by salary) as higest_salary from COMPANY3

-- COMMAND ----------

select EMPLOYEE_ID, EMPLOYEE_NAME, DEPARTMENT_NAME, SALARY, SUM(SALARY) over (partition by Department_name order by salary) as higest_salary from COMPANY3

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q7 – Find employee from employee table who is not belong to any department from department table?

-- COMMAND ----------

-- Creating the department table
CREATE TABLE department5 (
    department_id INT,
    department_name VARCHAR(255)
);




-- COMMAND ----------

-- Creating the employee table
CREATE TABLE employee5 (
    employee_id INT,
    employee_name VARCHAR(255),
    department_id INT);


-- COMMAND ----------

-- Inserting sample data into the department table
INSERT INTO department5 VALUES
    (1, 'HR'),
    (2, 'Finance'),
    (3, 'IT');

-- Inserting sample data into the employee table
INSERT INTO employee5 VALUES
    (101, 'John Doe', 1),
    (102, 'Jane Smith', 2),
    (103, 'Bob Johnson', NULL),
    (104, 'Alice Brown', NULL);

-- COMMAND ----------

-- SQL query to find employees not belonging to any department
SELECT *
FROM employee5
WHERE department_id IS NULL;

-- COMMAND ----------

select e.employee_id,  e.employee_name,  e.department_id 
from employee5 E
inner join department5 d
on E.department_id = d.department_id
where e.employee_id is null

-- COMMAND ----------

CREATE TABLE table_aa1 (
    id_1 INT
);

-- Insert values
INSERT INTO table_aa1 VALUES (1), (1), (1), (NULL), (NULL);

-- Select to display the data
SELECT * FROM table_aa1;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q8- How many records will show?

-- COMMAND ----------

CREATE TABLE table_bb1 (
    id_2 INT
);

-- Insert values
INSERT INTO table_bb1 VALUES (1), (2),(1),(NULL);

-- Select to display the data
SELECT * FROM table_bb1;

-- COMMAND ----------

SELECT * FROM table_aa1;

-- COMMAND ----------

SELECT * FROM table_bb1;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 1-inner join

-- COMMAND ----------

select id_1, id_2 from table_aa1 a
inner join
table_bb1 b
on 
a.id_1 = b.id_2

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 2- left join

-- COMMAND ----------

select * from table_aa1 a
left join
table_bb1 b
on 
a.id_1 = b.id_2 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 3- Right join

-- COMMAND ----------

select * from table_aa1 a
right join
table_bb1 b
on 
a.id_1 = b.id_2 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 4- Full Join

-- COMMAND ----------

select * from table_aa1 a
full join
table_bb1 b
on 
a.id_1 = b.id_2 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 5- Cross join

-- COMMAND ----------

select * from table_aa1, table_bb1
-- cross join multiply the rosw, table aa_1 having 5 and table bb_1 having 4 rows, 5*4=20 rows

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### We have 4 countries playing cricket namely India, Australia, Newziland, Shrilanka, Write a query to make combination of cricket match between countries without repetition?

-- COMMAND ----------

CREATE TABLE cricket_teamss (
    team_name VARCHAR(255)
);

INSERT INTO cricket_teamss (team_name) VALUES ('India'), ('Australia'), ('Newzeland'), ('Shrilanka');

-- COMMAND ----------

select * from cricket_teamss

-- COMMAND ----------

-- Solution 1- by using <> less than greater than symbol
select * from cricket_teamss team1 join cricket_teamss team2
on team1.team_name<> team2.team_name


-- COMMAND ----------

-- By using != operator
SELECT
    t1.team_name AS team1,
    t2.team_name AS team2
FROM
    Cricket_teamss t1
JOIN
    Cricket_teamss t2 
ON t1.team_name != t2.team_name
ORDER BY
    team1, team2;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q10- Write a query to find all employee having salary greater than their average salary of each department?

-- COMMAND ----------

-- Create table COMPANY2 for practice
CREATE TABLE COMPANY4(
EMPLOYEE_ID INT,
EMPLOYEE_NAME VARCHAR(10),
DEPARTMENT_NAME VARCHAR(10),
SALARY INT);

-- COMMAND ----------

INSERT INTO COMPANY4 VALUES(1,'MAYUR','IT',10000);
INSERT INTO COMPANY4 VALUES(2,'SHINDE','MRKT',20000);
INSERT INTO COMPANY4 VALUES(3,'MANU','HR',30000);
INSERT INTO COMPANY4 VALUES(4,'ASHU','MRKT',40000);

INSERT INTO COMPANY4 VALUES(5,'VARUN','IT',50000);
INSERT INTO COMPANY4 VALUES(6,'ASHA','HR',10000);
INSERT INTO COMPANY4 VALUES(7,'SHINDE','HR',20000);
INSERT INTO COMPANY4 VALUES(8,'ARJUN','IT',30000);
INSERT INTO COMPANY4 VALUES(9,'MANU','HR',30000);
INSERT INTO COMPANY4 VALUES(10,'ASHU','MRKT',90000);

-- COMMAND ----------

SELECT EMPLOYEE_ID, EMPLOYEE_NAME, DEPARTMENT_NAME, SALARY
FROM COMPANY4 e
WHERE SALARY > (
  SELECT AVG(SALARY)
  FROM COMPANY4 e2
  WHERE e2.DEPARTMENT_NAME = e.DEPARTMENT_NAME
);

-- COMMAND ----------

SELECT e.EMPLOYEE_ID, e.employee_name, e.department_name, e.salary
FROM company4 e
WHERE e.salary > (
    SELECT AVG(salary)
    FROM company4
    WHERE department_name = e.department_name
);


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q11- Write a query to retrieve information about employees and their managers using a self-join on the employee_test table?

-- COMMAND ----------

-- Creating the employee_test table (example)
CREATE TABLE employee_test (
    eid INT,
    ename VARCHAR(255),
    mgrid INT  -- Assuming this is the manager ID
    -- Other columns...
);

-- COMMAND ----------

-- Inserting sample data into the employee_test table
INSERT INTO employee_test VALUES
    (1, 'John', 2),
    (2, 'ManagerA', NULL),
    (3, 'Jane', 2),
    (4, 'ManagerB', NULL)
    -- Other data...

-- COMMAND ----------

select * from employee_test

-- COMMAND ----------

-- Corrected query to retrieve employee and manager names
SELECT 
    e.eid,
    e.ename,
    m.ename AS managername
FROM 
    employee_test e
JOIN 
    employee_test m ON e.mgrid = m.eid;