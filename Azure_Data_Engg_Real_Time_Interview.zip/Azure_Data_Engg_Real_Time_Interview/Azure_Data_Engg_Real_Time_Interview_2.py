# Databricks notebook source
# MAGIC %md
# MAGIC ##### 
# MAGIC It contain question from 51 to 86

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 51 - We have table in SQL with column name as EmpID, EmpName, Salary, ManagerID, write a query in pyspark sql to find all the employee whose salary is more than their manager?

# COMMAND ----------

# Assuming you have a DataFrame named 'employee_df' representing your SQL table
# You can create it using spark.read or other methods

# Example DataFrame creation (replace this with your actual DataFrame creation)
data = [(1, 'John', 60000, 2),
        (2, 'Jane', 80000, 3),
        (3, 'Bob', 100000, 4),
        (4, 'Alice', 120000, 5),
        (5, 'Charlie', 150000, None)]

columns = ['EmpID', 'EmpName', 'Salary', 'ManagerID']
employee_df = spark.createDataFrame(data, columns)

# Register the DataFrame as a temporary SQL table
employee_df.createOrReplaceTempView("employee_table")

# Write a SQL query to find employees with salary greater than their manager's salary
result = spark.sql("""
    SELECT e.EmpID, e.EmpName, e.Salary, e.ManagerID
    FROM employee_table e
    JOIN employee_table m ON e.ManagerID = m.EmpID
    WHERE e.Salary > m.Salary
""")

# Show the result
result.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 52 - Write a code in SQL to find all employees whose salary is more than average salary of department?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE employee_table222 (
# MAGIC     EmpID INT,
# MAGIC     EmpName VARCHAR(100),
# MAGIC     Salary int,
# MAGIC     DepartmentID INT
# MAGIC );
# MAGIC
# MAGIC INSERT INTO employee_table222 (EmpID, EmpName, Salary, DepartmentID) VALUES
# MAGIC (1, 'John', 50000.00, 101),
# MAGIC (2, 'Alice', 60000.00, 101),
# MAGIC (3, 'Bob', 45000.00, 102),
# MAGIC (4, 'Charlie', 55000.00, 102),
# MAGIC (5, 'David', 70000.00, 101),
# MAGIC (6, 'Emily', 48000.00, 102);
# MAGIC select * from employee_table222;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT EmpID, EmpName, Salary, DepartmentID
# MAGIC FROM employee_table222 e
# MAGIC WHERE Salary > (
# MAGIC     SELECT AVG(Salary)
# MAGIC     FROM employee_table222
# MAGIC     WHERE DepartmentID = e.DepartmentID
# MAGIC );
# MAGIC -- OR
# MAGIC select e.EmpID, e.EmpName, e.Salary, e.DepartmentID from table_name e where e.salary>
# MAGIC (select avg(salary) as avg_salary from table where department = e.department)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 52 - Write a code in pyspark SQL to find all employees whose salary is more than average salary of department?

# COMMAND ----------

# Example DataFrame creation (replace this with your actual DataFrame creation)
data = [
    (1, 'John', 60000, 1),
    (2, 'Jane', 80000, 1),
    (3, 'Bob', 100000, 2),
    (4, 'Alice', 120000, 2),
    (5, 'Charlie', 150000, 1)
]

columns = ['EmpID', 'EmpName', 'Salary', 'DepartmentID']
employee_df = spark.createDataFrame(data, columns)

# Register the DataFrame as a temporary SQL table
employee_df.createOrReplaceTempView("employee_table")

# Write a SQL query to find employees with salary greater than the average salary of their department
result = spark.sql("""
    SELECT e.EmpID, e.EmpName, e.Salary, e.DepartmentID
    FROM employee_table e
    JOIN (
        SELECT DepartmentID, AVG(Salary) AS AvgSalary
        FROM employee_table
        GROUP BY DepartmentID
    ) AS avg_table
    ON e.DepartmentID = avg_table.DepartmentID
    WHERE e.Salary > avg_table.AvgSalary
""")

# Show the result
result.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 52 - Write a code in pyspark to find all employees whose salary is more than average salary of department?

# COMMAND ----------

from pyspark.sql.functions import avg, col

# Example DataFrame creation (replace this with your actual DataFrame creation)
data = [
    (1, 'John', 60000, 1),
    (2, 'Jane', 80000, 1),
    (3, 'Bob', 100000, 2),
    (4, 'Alice', 120000, 2),
    (5, 'Charlie', 150000, 1)
]

columns = ['EmpID', 'EmpName', 'Salary', 'DepartmentID']
employee_df = spark.createDataFrame(data, columns)

avg_salaries = employee_df.groupBy("DepartmentID").agg(avg(col("Salary")).alias("avg_salary"))

# Step 2: Join the original DataFrame with the average salaries
result_df = employee_df.join(avg_salaries, on="DepartmentID", how="inner")

# Step 3: Filter employees with salaries greater than the average salary of their department
filtered_df = result_df.filter(col("Salary") > col("avg_salary"))

# Show the resulting DataFrame
filtered_df.show()

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Countries (
# MAGIC     CountryID INT,
# MAGIC     CountryName VARCHAR(50),
# MAGIC     Population INT
# MAGIC );
# MAGIC
# MAGIC INSERT INTO Countries (CountryID, CountryName, Population)
# MAGIC VALUES
# MAGIC     (1, 'USA', 331002651),   -- United States
# MAGIC     (2, 'India', 1380004385), -- India
# MAGIC     (3, 'China', 1444216107),
# MAGIC     (4, 'Brazil', 212559417),
# MAGIC     (5, 'Russia', 145934462),
# MAGIC     (6, 'Japan', 126476461),
# MAGIC     (7, 'Germany', 83783942),
# MAGIC     (8, 'United Kingdom', 67886011),
# MAGIC     (9, 'France', 65273511),
# MAGIC     (10, 'Italy', 60461826);

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 54 - We have CountryID, countryName and Population column, write a query to find the total number of population in US and India in sql?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to find the total population of the United States and India
# MAGIC SELECT 
# MAGIC     SUM(Population) AS TotalPopulation
# MAGIC FROM 
# MAGIC     Countries
# MAGIC WHERE 
# MAGIC     CountryName IN ('USA', 'India');
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 55 - We have EmpID, EmpName, EmpSalary,EmpCity and Designation column in SQL, write a program in sql to return designation with highest salary in each city?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Employees123 (
# MAGIC     EmpID INT,
# MAGIC     EmpName VARCHAR(50),
# MAGIC     EmpSalary DECIMAL(10, 2),
# MAGIC     EmpCity VARCHAR(50),
# MAGIC     Designation VARCHAR(50)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO Employees123 (EmpID, EmpName, EmpSalary, EmpCity, Designation)
# MAGIC VALUES
# MAGIC     (1, 'John Doe', 60000.00, 'New York', 'Manager'),
# MAGIC     (2, 'Jane Smith', 55000.00, 'New York', 'Developer'),
# MAGIC     (3, 'Bob Johnson', 70000.00, 'Chicago', 'Manager'),
# MAGIC     (4, 'Alice Williams', 65000.00, 'Chicago', 'Analyst'),
# MAGIC     (5, 'Charlie Brown', 75000.00, 'Los Angeles', 'Director'),
# MAGIC     (6, 'Diana Miller', 72000.00, 'Los Angeles', 'Manager'),
# MAGIC     (7, 'Eva Davis', 58000.00, 'New York', 'Analyst'),
# MAGIC     (8, 'Frank Wilson', 68000.00, 'Chicago', 'Developer'),
# MAGIC     (9, 'Grace Lee', 71000.00, 'Los Angeles', 'Developer');
# MAGIC     select * from Employees123;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT e.EmpCity, e.Designation, e.EmpSalary
# MAGIC FROM Employees12 e
# MAGIC JOIN (
# MAGIC     SELECT EmpCity, MAX(EmpSalary) AS MaxSalary
# MAGIC     FROM Employees12
# MAGIC     GROUP BY EmpCity
# MAGIC ) max_salaries
# MAGIC ON e.EmpCity = max_salaries.EmpCity
# MAGIC AND e.EmpSalary = max_salaries.MaxSalary;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### By using Rank() function along with CTE

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH RankedSalaries AS (
# MAGIC     SELECT 
# MAGIC         EmpCity, Designation,EmpSalary,
# MAGIC         ROW_NUMBER() OVER (PARTITION BY EmpCity ORDER BY EmpSalary DESC) AS SalaryRank
# MAGIC     FROM 
# MAGIC         Employees123
# MAGIC )
# MAGIC SELECT 
# MAGIC     EmpCity, Designation, EmpSalary
# MAGIC FROM 
# MAGIC     RankedSalaries
# MAGIC WHERE 
# MAGIC     SalaryRank = 1;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### By using Rank() function

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT EmpCity, Designation, EmpSalary
# MAGIC FROM (
# MAGIC     SELECT EmpCity, Designation, EmpSalary,
# MAGIC            RANK() OVER (PARTITION BY EmpCity ORDER BY EmpSalary DESC) AS SalaryRank
# MAGIC     FROM Employees12
# MAGIC ) as ranked_salaries
# MAGIC WHERE SalaryRank = 1;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 61- Suppose we have one table with 5 MB data and second table with 100 GB data then how broadcast works in pyspark?

# COMMAND ----------

from pyspark.sql.functions import broadcast

# Assuming you have two DataFrames df1 and df2
# df1 is small (5 MB) and df2 is large (100 GB)

# Sample data for demonstration purposes
data1 = [(1, "Alice"), (2, "Bob"), (3, "Charlie")]
data2 = [(1, "Engineering"), (2, "Sales"), (3, "Marketing")]

# Define schemas
schema1 = ["id", "name"]
schema2 = ["id", "department"]

# Create DataFrames
df1 = spark.createDataFrame(data1, schema=schema1)
df2 = spark.createDataFrame(data2, schema=schema2)

# Use the broadcast hint for the smaller DataFrame
broadcast_df1 = broadcast(df1)

# Perform a join operation with the broadcast hint
result = df2.join(broadcast_df1, "id")

# Show the result
result.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 65- Write a word count program in pyspark?

# COMMAND ----------

sc = spark.sparkContext                                             # 1.Create a Spark Context:
file= sc.textFile("dbfs:/FileStore/tables/wordcount.txt")           # 2.Read/Load a Text File into RDD (Resilient Distributed Dataset):
flat_file = file.flatMap(lambda word : word.split(' '))             # 3.FlatMap Operation to Split Words:
flat_file_tuple = flat_file.map(lambda word: (word,1))              # 4.Map Operation to Create Tuple (word, 1):
final_word_count = flat_file_tuple.reduceByKey(lambda x,y : x+y)    # 5.ReduceByKey Operation to Perform Word Count:
count = final_word_count.collect()                                  # 6.Collect the Results to the Driver Program:
count.saveAsTextFile("dbfs:/FileStore/tables/wordcount_new2.txt")   # 7.Save the result

# COMMAND ----------

1.	Create a Spark Context:
sc = spark.sparkContext 
•	This line creates a Spark Context (sc), which is the entry point to interact with Spark functionality. spark is assumed to be a previously created SparkSession.

2.	Read Text File into RDD (Resilient Distributed Dataset):
file = sc.textFile("dbfs:/FileStore/tables/wordcount.txt") 
•	This line reads the text file located at "dbfs:/FileStore/tables/wordcount.txt" and creates an RDD named file. An RDD is a fundamental data structure in Spark that represents a distributed collection of data.

3.	FlatMap Operation to Split Words:
flat_file = file.flatMap(lambda word: word.split(' ')) 
•	This line uses the flatMap transformation on the file RDD. It splits each line into words using a space as the delimiter and flattens the resulting list of lists into a single list of words.

4.	Map Operation to Create Tuple (word, 1):
flat_file_tuple = flat_file.map(lambda word: (word, 1)) 
•	This line uses the map transformation on the flat_file RDD. It transforms each word into a tuple (word, 1). This is a common pattern for preparing data for word count operations.

5.	ReduceByKey Operation to Perform Word Count:
final_word_count = flat_file_tuple.reduceByKey(lambda x, y: x + y) 
•	This line uses the reduceByKey transformation on the flat_file_tuple RDD. It groups the tuples by the word (key) and sums up the corresponding counts, effectively performing a word count.

6.	Collect the Results to the Driver Program:
count = final_word_count.collect() 
•	This line triggers the execution of the transformations and actions defined so far, collecting the results back to the driver program. The result is a list of tuples, where each tuple contains a unique word and its count.

7.	Display the Word Counts:
count 
•	This line, when executed, will display the word counts collected in the previous step.


# COMMAND ----------

# Load the text file into an RDD
input_file = sc.textFile("dbfs:/FileStore/tables/wordcount.txt")

# Perform computation to count the number of words in the file
words = input_file.flatMap(lambda line: line.split(" "))

# Count the occurrence of each word
wordCounts = words.map(lambda word: (word, 1))

# Correct the typo: It should be `wordCounts.reduceByKey` instead of `map.reduceByKey`
counts = wordCounts.reduceByKey(lambda a, b: a + b)

# Save the result
counts.saveAsTextFile("dbfs:/FileStore/tables/wordcount_new2.txt")

# COMMAND ----------

Load the text file into an RDD:

input_file = sc.textFile("dbfs:/FileStore/tables/wordcount.txt"): This line loads the text file into an RDD (Resilient Distributed Dataset) named input_file. Adjust the file path as needed.
Perform computation to count the number of words:

words = input_file.flatMap(lambda line: line.split(" ")): This line splits each line into words and flattens the result. The flatMap transformation is used for this purpose.
Count the occurrence of each word:

wordCounts = words.map(lambda word: (word, 1)): This line assigns a count of 1 to each word, creating a key-value pair where the word is the key, and 1 is the value.
Correct the typo and perform the reduction:

counts = wordCounts.reduceByKey(lambda a, b: a + b): This line correctly uses reduceByKey to sum the counts for each word. The result is a new RDD named counts.
Save the result:

counts.saveAsTextFile("dbfs:/FileStore/tables/wordcount_new1.txt"): This line saves the final word count result to a new text file. Adjust the file path as needed.

# COMMAND ----------

import sys
from pyspark import SparkContext, SparkConf

if __name__ == "__main__":
    # Create Spark context with necessary configuration
    sc = SparkContext("local", "PySpark Word Count Example")
    
    # Read data from a text file and split each line into words
    words = sc.textFile("D:/workspace/spark/input.txt").flatMap(lambda line: line.split(" "))
    
    # Count the occurrence of each word
    wordCounts = words.map(lambda word: (word, 1)).reduceByKey(lambda a, b: a + b)
    
    # Save the counts to an output folder
    wordCounts.saveAsTextFile("D:/workspace/spark/output/")


# COMMAND ----------

from pyspark.sql.functions import explode, split, col, count                # Three step process

# Load the text file into a DataFrame
file_path = "dbfs:/FileStore/tables/wordcount.txt"
df = spark.read.text(file_path)                                             # Step1- Read the file                         

# Split each line into words using space as delimiter
words_df = df.select(explode(split(col("value"), " ")).alias("word"))       # Step2 - explode and split the file

# Group by word and count occurrences
word_counts_df = words_df.groupBy("word").agg(count("*").alias("count"))    # Step3- groupBy and count the file

# Show the word counts
word_counts_df.show()                                                       # Step4 - show the file


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 70- We have three column, product, amount and country, write a program in pyspark to pivot the column based on country column, also explain what is pivot in pyspark?

# COMMAND ----------

from pyspark.sql.functions import col

# Sample data
data = [("Product_A", 100, "USA"),
        ("Product_A", 150, "Canada"),
        ("Product_B", 200, "USA"),
        ("Product_B", 120, "Canada")]

# Define the schema
schema = ["product", "amount", "country"]

# Create a DataFrame
df = spark.createDataFrame(data, schema=schema)
df.show()

# Pivot the DataFrame based on the "country" column
pivot_df = df.groupBy("product").pivot("country").sum("amount")

# Show the result
pivot_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 71- We have three column namely ID, Name and ManagerID, write a query in SQL to print respective manager name of employee for respective employee?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Employee table
# MAGIC CREATE TABLE Emp1 (
# MAGIC     ID INT,
# MAGIC     Name STRING,
# MAGIC     ManagerID INT
# MAGIC )
# MAGIC USING PARQUET; -- You can choose a different format based on your preference
# MAGIC
# MAGIC -- Insert sample data
# MAGIC INSERT INTO Emp1 VALUES
# MAGIC (1, 'John', NULL),
# MAGIC (2, 'Alice', 1),
# MAGIC (3, 'Bob', 1),
# MAGIC (4, 'Charlie', 2),
# MAGIC (5, 'David', 2),
# MAGIC (6, 'Eva', 3),
# MAGIC (7, 'Frank', 3);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from emp1

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to retrieve employee and manager names
# MAGIC SELECT
# MAGIC     E.ID AS EmployeeID,
# MAGIC     E.Name AS EmployeeName,
# MAGIC     M.Name AS ManagerName
# MAGIC FROM
# MAGIC     Emp1 AS E
# MAGIC LEFT JOIN
# MAGIC     Emp1 AS M ON E.ManagerID = M.ID;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 72- Write a query to find who is manager and who is not?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to identify managers and non-managers using LEFT JOIN
# MAGIC SELECT
# MAGIC     E.ID,
# MAGIC     E.Name,
# MAGIC     CASE WHEN M.ID IS NOT NULL THEN 'Manager' ELSE 'Not a Manager' END AS Role
# MAGIC FROM
# MAGIC     Emp1 AS E
# MAGIC LEFT JOIN
# MAGIC     Emp1 AS M ON E.ID = M.ManagerID;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to identify managers and non-managers
# MAGIC SELECT
# MAGIC     ID,
# MAGIC     Name,
# MAGIC     CASE WHEN ID IN (SELECT DISTINCT ManagerID FROM Emp1 WHERE ManagerID IS NOT NULL) THEN 'Manager' ELSE 'Not a Manager' END AS Role
# MAGIC FROM
# MAGIC     Emp1;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 72- We have 4 columns namely ID, Name, Department, Salary, write a query in sql to add new column in above table with average salary for employees by department?

# COMMAND ----------

# MAGIC     %sql
# MAGIC     -- Create the Employee table
# MAGIC     CREATE TABLE Employee3 (
# MAGIC         ID INT,
# MAGIC         Name VARCHAR(255),
# MAGIC         Department VARCHAR(255),
# MAGIC         Salary INT
# MAGIC     );
# MAGIC
# MAGIC     -- Insert sample data
# MAGIC     INSERT INTO Employee3 VALUES
# MAGIC     (1, 'John', 'HR', 50000),
# MAGIC     (2, 'Alice', 'IT', 60000),
# MAGIC     (3, 'Bob', 'HR', 55000),
# MAGIC     (4, 'Charlie', 'IT', 65000),
# MAGIC     (5, 'David', 'Finance', 70000),
# MAGIC     (6, 'Eva', 'Finance', 75000),
# MAGIC     (7, 'Frank', 'IT', 62000);
# MAGIC     select * from Employee3;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Add a new column with the average salary by department
# MAGIC SELECT
# MAGIC     ID,
# MAGIC     Name,
# MAGIC     Department,
# MAGIC     Salary,
# MAGIC     AVG(Salary) OVER (PARTITION BY Department) AS AvgSalaryByDepartment
# MAGIC FROM
# MAGIC     Employee3;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Can you add a new column with records having highest salary in each department?

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH RankedEmployees AS (
# MAGIC     SELECT
# MAGIC         ID,Name,Department,Salary,
# MAGIC         RANK() OVER (PARTITION BY Department ORDER BY Salary DESC) AS SalaryRank
# MAGIC     FROM Employee3
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC     ID,Name,Department,Salary
# MAGIC FROM 
# MAGIC     RankedEmployees WHERE SalaryRank = 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC select *, max(Salary) over(partition by Department)as highest_salary_by_department
# MAGIC from Employee3

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 73- We have a string "123a!" write a program in python which return like "112233aa!!"

# COMMAND ----------

string = "123a!"
new = ""
for i in string:
    new += i * 2
print(new)


# COMMAND ----------

string = "123a!"

def create_duplicate(s):
    result = ""
    for i in s:
        result += i * 2
    return result

# Test the function
result_string = create_duplicate(string)
print(result_string)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 74- Write simple python program to check if the given number is prime or not?

# COMMAND ----------

def is_prime(num):
    if num <= 1:
        return False
    for i in range(2, num):
        if num % i == 0:
            return False
    return True

num = 407  # You can change this value to check other numbers
if is_prime(num):
    print(f"{num} is a prime number")
else:
    print(f"{num} is not a prime number")


# COMMAND ----------

number = 13
def prime_check(number):
    for i in range(2, number//2):
        if number%i ==0:
            return 'not prime'
        else:
            return 'prime'
print(prime_check(number))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 76 - We have 4 columns namely ID, Name, Location and Date, write query in sql to print only newest record for each name?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the EmployeeRecords table
# MAGIC CREATE TABLE EmployeeRecords (
# MAGIC     ID INT,
# MAGIC     Name VARCHAR(255),
# MAGIC     Location VARCHAR(255),
# MAGIC     Date DATE
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data
# MAGIC INSERT INTO EmployeeRecords VALUES
# MAGIC (1, 'John', 'New York', '2023-01-01'),
# MAGIC (2, 'Alice', 'Los Angeles', '2023-02-15'),
# MAGIC (3, 'Bob', 'Chicago', '2023-03-10'),
# MAGIC (4, 'Alice', 'San Francisco', '2023-04-05'),
# MAGIC (5, 'John', 'Seattle', '2023-03-20'),
# MAGIC (6, 'Bob', 'Houston', '2023-05-01');
# MAGIC select * from EmployeeRecords

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Method 1 - By using min() function
# MAGIC select Name, min(Date) as new_record from EmployeeRecords
# MAGIC group by Name;

# COMMAND ----------

# MAGIC %sql -- Method 2- By using row_number()
# MAGIC WITH RankedRecords AS (
# MAGIC     SELECT
# MAGIC         ID,Name,Location,Date, ROW_NUMBER() OVER (PARTITION BY Name ORDER BY Date DESC) AS RowRank
# MAGIC     FROM
# MAGIC         EmployeeRecords
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     ID,Name,Location,Date
# MAGIC FROM
# MAGIC     RankedRecords WHERE RowRank = 1;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### collect_list Function:

# COMMAND ----------

collect_list Function:

1- The collect_list function is an aggregation function in PySpark that is used with the groupBy operation to aggregate data.
2- It collects the values of a specified column into a list for each group defined by the groupBy operation.
3- This function is useful when you want to aggregate data in a way that retains multiple values for each group, rather than reducing them to a single value.

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import collect_list

data = [("Alice", "Math"), ("Bob", "English"), ("Alice", "Physics"), ("Bob", "Math")]
columns = ["Name", "Subject"]

df = spark.createDataFrame(data, columns)
df.show()
result = df.groupBy("Name").agg(collect_list("Subject").alias("Subjects"))

result.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### concat_ws Function:

# COMMAND ----------

1- The concat_ws function is used to concatenate the values of multiple columns with a specified delimiter.
2- This function is helpful when you want to combine the values of multiple columns into a single column with a specific separator.
3- The concat_ws function takes two arguments: the separator and the columns to concatenate.


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import concat_ws

spark = SparkSession.builder.appName("example").getOrCreate()

data = [("Alice", 25), ("Bob", 30), ("Charlie", 22)]
columns = ["Name", "Age"]

df = spark.createDataFrame(data, columns)
df.show()
result = df.withColumn("Concatenated", concat_ws("-", "Name", "Age"))

result.show()

# In the example, concat_ws("-", "Name", "Age") concatenates the "Name" and "Age" columns using a hyphen as the separator. 
# The resulting DataFrame has a new column named "Concatenated" containing the concatenated values.


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 77-Write a query in sql to return the output like 'course' column contain Spark, SQL in one column, question is in word file?
# MAGIC * 1- In Pyspark- we have df.groupBy('ID', 'Name').agg(collect_list('course').alias('Course')) function to perform collect
# MAGIC * 2- In SQL- we have STRING_AGG(course, ',') function to perform collect
# MAGIC
# MAGIC * 1- In Pyspark- df_result = df.withColumn('courses', explode(split(col('course'), ',')))
# MAGIC * 2- In SQL - select id, name from table_name CROSS APPLY STRING_SPLIT(course, ',');

# COMMAND ----------

data= [(1, 'Arul','SQL'),
(1,'Arul','Spark' ),
(2,'Bhumica','SQL'   ),
(2,'Bhumica','Spark')]

schema= ['id','name','course']

df= spark.createDataFrame(data=data,schema=schema)

df.createOrReplaceTempView('table')

spark.sql("""
select * from table
""").show()

# COMMAND ----------

from pyspark.sql.functions import col, collect_list
# Aggregate and concatenate the courses
result_df = df.groupBy('ID', 'Name').agg(collect_list('course').alias('Course'))

# Show the result
result_df.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Solution in SQL

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the EmployeeCourses table
# MAGIC CREATE TABLE EmployeeCourses (
# MAGIC     id INT,
# MAGIC     name VARCHAR(255),
# MAGIC     course VARCHAR(255)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data
# MAGIC INSERT INTO EmployeeCourses VALUES
# MAGIC (1, 'Arul', 'SQL'),
# MAGIC (1, 'Arul', 'Spark'),
# MAGIC (2, 'Bhumica', 'SQL'),
# MAGIC (2, 'Bhumica', 'Spark');
# MAGIC select * from EmployeeCourses

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to concatenate courses for each id and name
# MAGIC SELECT
# MAGIC     id,
# MAGIC     name,
# MAGIC     STRING_AGG(course, ',') AS Course
# MAGIC FROM
# MAGIC     EmployeeCourses
# MAGIC GROUP BY
# MAGIC     id, name;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 78- Vice versa of above question, question is in word file?
# MAGIC * In Pyspark- df_result = df.withColumn('courses', explode(split(col('course'), ',')))
# MAGIC * In SQL - select id, name from table_name CROSS APPLY STRING_SPLIT(course, ',');

# COMMAND ----------

from pyspark.sql import functions as F
# Sample data
data = [(1, 'Arul', 'SQL,Spark'),
        (2, 'Bhumica', 'SQL,Spark')]

# Define the schema
schema = ['id', 'name', 'course']

# Create a DataFrame
df = spark.createDataFrame(data, schema=schema)

df.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### course column contain two value- [SQL,Spark] separate this column into values, we use split and explode in same line which is easy

# COMMAND ----------

from pyspark.sql.functions import split, explode, col

# Split the 'course' column based on comma and explode into separate rows
df_result = df.withColumn('courses', explode(split(col('course'), ',')))

# Drop the original 'course' column if needed
df_result = df_result.drop('course')

# Show the result
df_result.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### course column contain two value- [SQL,Spark] separate this column into values, we use split and explode in separate line

# COMMAND ----------

# Split the 'course' column based on comma
df_split = df.withColumn('courses_split', split(col('course'), ','))

# Explode the resulting array into separate rows
df_result = df_split.select('id', 'name', explode(df_split['courses_split']).alias('course'))

# Drop the intermediate 'courses_split' column if needed
df_result = df_result.drop('courses_split')

# Show the result
df_result.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### By using Function as F

# COMMAND ----------

from pyspark.sql import functions as F

# Split the 'course' column by comma and explode the array into separate rows
result_df = (
    df.withColumn("course", F.split("course", ","))
    .withColumn("course", F.explode("course"))
)

# Show the result
result_df.show(truncate=False)

# split("course", ",") is used to split the 'course' column by commas, creating an array of values.
# explode("course") is used to explode the array into separate rows, duplicating the original rows for each value in the array.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the EmployeeCourses table
# MAGIC CREATE TABLE EmployeeCourses1 (
# MAGIC     id INT,
# MAGIC     name VARCHAR(255),
# MAGIC     course VARCHAR(255)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data
# MAGIC INSERT INTO EmployeeCourses1 VALUES
# MAGIC (1, 'Arul', 'SQL,Spark'),
# MAGIC (2, 'Bhumica', 'SQL,Spark');
# MAGIC
# MAGIC select * from EmployeeCourses1;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to split comma-separated values into separate rows
# MAGIC SELECT
# MAGIC     id, name FROM EmployeeCourses1
# MAGIC CROSS APPLY STRING_SPLIT(course, ',');
# MAGIC
# MAGIC --The STRING_SPLIT(course, ',') function is used to split the 'course' column into rows based on the comma separator.

# COMMAND ----------

spark.sql("""
          select id, name, explode(split(course,",")) as courses from EmployeeCourses1 
          """).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 79 - Find average salary of each manager where each manager can have multiple employee working under him?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the manager_tbl table
# MAGIC CREATE TABLE manager_tbl (
# MAGIC     id INT,
# MAGIC     name VARCHAR(100),
# MAGIC     salary INT,
# MAGIC     manager_id INT
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into manager_tbl
# MAGIC INSERT INTO manager_tbl (id, name, salary, manager_id) VALUES
# MAGIC (1, 'Manager A', 5000.00, NULL),
# MAGIC (2, 'Manager B', 6000.00, NULL),
# MAGIC (3, 'Employee A1', 3000.00, 1),
# MAGIC (4, 'Employee A2', 4000.00, 1),
# MAGIC (5, 'Employee B1', 3500.00, 2),
# MAGIC (6, 'Employee B2', 4500.00, 2),
# MAGIC (7, 'Employee B3', 5500.00, 2);
# MAGIC select * from manager_tbl;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     m.id AS manager_id,
# MAGIC     m.name AS manager_name,
# MAGIC     AVG(e.salary) AS average_salary
# MAGIC FROM 
# MAGIC     manager_tbl m
# MAGIC LEFT JOIN 
# MAGIC     manager_tbl e ON m.id = e.manager_id
# MAGIC GROUP BY 
# MAGIC     m.id, m.name;
# MAGIC

# COMMAND ----------

data=[(10 ,'Anil',50000, 18),
(11 ,'Vikas',75000,  16),
(12 ,'Nisha',40000,  18),
(13 ,'Nidhi',60000,  17),
(14 ,'Priya',80000,  18),
(15 ,'Mohit',45000,  18),
(16 ,'Rajesh',90000, 10),
(17 ,'Raman',55000, 16),
(18 ,'Sam',65000,   17)]

schema=['id','name','sal','mngr_id']

manager_df= spark.createDataFrame(data=data,schema=schema)
manager_df.createOrReplaceTempView("manager_tbl")
spark.sql("""
select * from manager_tbl
""").show()

# COMMAND ----------

spark.sql("""
          select manager_id, manager_name, avg(salary_of_employee) as average_sal
          from 
          (
              select m1.mngr_id as manager_id, m2.name as manager_name, m1.sal as salary_of_employee from manager_tbl m1
              inner join manager_tbl m2
              on m1.mngr_id = m2.id
          )
          group by 1,2
          
          """).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 80 is in word file

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create Table1
# MAGIC CREATE TABLE Table_1 (
# MAGIC     ID INT
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data into Table1
# MAGIC INSERT INTO Table_1 VALUES
# MAGIC (1),
# MAGIC (1),
# MAGIC (2),
# MAGIC (0);
# MAGIC
# MAGIC -- Create Table2
# MAGIC CREATE TABLE Table_2 (
# MAGIC     ID INT
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data into Table2
# MAGIC INSERT INTO Table_2 VALUES
# MAGIC (1),
# MAGIC (1),
# MAGIC (2),
# MAGIC (2);
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Count of records for inner join
# MAGIC SELECT COUNT(*) AS InnerJoinCount
# MAGIC FROM Table_1 t1
# MAGIC INNER JOIN Table_2 t2 ON t1.ID = t2.ID;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Count of records for left join
# MAGIC SELECT COUNT(*) AS LeftJoinCount
# MAGIC FROM Table_1 t1
# MAGIC LEFT JOIN Table_2 t2 ON t1.ID = t2.ID;

# COMMAND ----------

Inner Join Count (InnerJoinCount): This represents the count of records where the 'ID' values are common in both Table1 and Table2. In this case, the common 'ID' values are 1 and 2, and there are two occurrences of 1 and one occurrence of 2 in Table1, and two occurrences of 1 and two occurrences of 2 in Table2. So, the inner join count is 1 (for ID=1) + 1 (for ID=2) = 2.

Left Join Count (LeftJoinCount): This represents the count of records from the left table (Table1) and includes matching records from the right table (Table2). In this case, the left join count includes all records from Table1 (4 records) and the matching records from Table2 (1 record for ID=1 and 2 records for ID=2), so the total left join count is 4 + 1 + 2 = 7.

# COMMAND ----------

Spark words count:-
sc = spark.sparkContext
file= sc.textFile("/FileStore/tables/word_count.txt")
flat_file = file.flatMap(lambda word : word.split(' '))
flat_file_tuple = flat_file.map(lambda word: (word,1))
final_word_count = flat_file_tuple.reduceByKey(lambda x,y : x+y)
count = final_word_count.collect()
count

# COMMAND ----------

# MAGIC %md
# MAGIC ##### list1 = [1, 3, 4, 6, 8, 2] 
# MAGIC ##### list2 = list1 
# MAGIC ##### list3 = list1.copy(), what is difference between list2 = list1 and list3 = list1.copy() ?
# MAGIC

# COMMAND ----------

list1 = [1, 3, 4, 6, 8, 2] 
list2 = list1 
list1[0] = 100 
print(list2) # Output: [100, 3, 4, 6, 8, 2] 

# COMMAND ----------

list1 = [1, 3, 4, 6, 8, 2] 
list3 = list1.copy() 
list1[0] = 100 
print(list3) # Output: [1, 3, 4, 6, 8, 2] 

# COMMAND ----------

With list2 = list1, changes to one list affect the other because they reference the same underlying list object.
With list3 = list1.copy(), the two lists are independent, and changes to one do not affect the other.
list2 = list1 – save in same memory area.
list3 = list1.copy() list3 becomes a new list with the same elements as list1, but it is a separate object in memory. Modifying one list does not affect the other.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 84- What is shallow copy and deep copy in pyspark?

# COMMAND ----------

# Example of a shallow copy in PySpark
original_list = [1, [2, 3], 4]
shallow_copy = original_list.copy()

# Modify the nested list in the shallow copy
shallow_copy[1][0] = 100

# Changes are reflected in the original list
print(original_list)  # Output: [1, [100, 3], 4]


# COMMAND ----------

# Example of a deep copy in PySpark
import copy

original_list = [1, [2, 3], 4]
deep_copy = copy.deepcopy(original_list)

# Modify the nested list in the deep copy
deep_copy[1][0] = 100

# Changes do not affect the original list
print(original_list)  # Output: [1, [2, 3], 4]


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 85- How to sort the dictionary based on key?
# MAGIC We have method called **items()** to sort the dictionary based on key

# COMMAND ----------

my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

sort_dict = dict(sorted(my_dict.items(), key = lambda item: item[0]))

conv_dict = dict(sort_dict)
print(conv_dict)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 85- How to sort the dictionary based on Value?
# MAGIC We have method called **items()** to sort the dictionary based on values

# COMMAND ----------

my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

# Sort the dictionary by values in ascending order
sorted_items = sorted(my_dict.items(), key=lambda item: item[1])

# Create a new dictionary from the sorted items
sorted_dict = dict(sorted_items)

print(sorted_dict)

# This approach directly sorts the items and then constructs a new dictionary from the sorted items using dict()

# COMMAND ----------

my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

# Sort the dictionary based on values
sorted_dict = dict(sorted(my_dict.items(), key=lambda item: item[1]))

# Display the sorted dictionary
print(sorted_dict)

# my_dict.items() returns a view of the dictionary's key-value pairs.
# The key=lambda item: item[1] specifies that the sorting should be based on the values (item[1]).
# The sorted function sorts the key-value pairs based on the specified key function.
# dict() is used to convert the sorted key-value pairs back into a dictionary.

# COMMAND ----------

# MAGIC %md
# MAGIC #####  If you want to sort in descending order, you can add the reverse=True parameter to the sorted function:

# COMMAND ----------

# If you want to sort in descending order, you can add the reverse=True parameter to the sorted function:
my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

sorted_dict_desc = dict(sorted(my_dict.items(), key=lambda item: item[1], reverse=True))


# Display the sorted dictionary
print(sorted_dict_desc)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question - How to convert dictionary into list?
# MAGIC To convert a dictionary into a list of tuples, where each tuple contains a key-value pair, you can use the **items()** method of the dictionary

# COMMAND ----------

my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

# Convert dictionary to list of tuples
my_list = list(my_dict.items())

print(my_list)

# COMMAND ----------

# MAGIC %md 
# MAGIC ##### by converting dictionary into list

# COMMAND ----------

from pyspark.sql.functions import col
my_dict = {'a': 17, 'b': 5, 'c': 15, 'd': 1}

# Create a DataFrame from the dictionary
df = spark.createDataFrame(list(my_dict.items()), ["key", "value"])

# Sort the DataFrame by value in ascending order
sorted_df = df.orderBy(col("value"))

# Convert the sorted DataFrame back to a dictionary
sorted_dict = dict(sorted_df.collect())

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 86- How to sort the dictionary based on Key?

# COMMAND ----------

my_dict = {'d': 17, 'c': 15, 'b': 5, 'a': 1}

# Sort the dictionary based on keys
sorted_dict = dict(sorted(my_dict.items()))

# Display the sorted dictionary
print(sorted_dict)

# To sort a dictionary based on its keys in Python, you can use the sorted function with the items() method and a custom key function
# my_dict.items() returns a view of the dictionary's key-value pairs.
# The sorted function sorts the key-value pairs based on the default order of the keys (lexicographic order for strings, ascending order for numbers).
# dict() is used to convert the sorted key-value pairs back into a dictionary.

# COMMAND ----------

my_dict = {'d': 17, 'c': 15, 'b': 5, 'a': 1}

sorted_dict_desc = dict(sorted(my_dict.items(), reverse=True))

print(sorted_dict_desc)

# If you want to sort in descending order, you can add the reverse=True parameter to the sorted function:

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Sort the dictionary by ** OrderedDict**
# MAGIC OrderedDict is present in Collections in pyspark

# COMMAND ----------

from collections import OrderedDict

my_dict = {'d': 17, 'c': 15, 'b': 5, 'a': 1}

# Create an OrderedDict from the sorted items
sorted_dict = OrderedDict(sorted(my_dict.items()))

# Display the sorted dictionary
print(sorted_dict)

# Another simple approach to sort a dictionary by keys is to use the collections.OrderedDict
# In this approach, the OrderedDict constructor takes the sorted key-value pairs directly, resulting in a dictionary sorted by keys. 
# The OrderedDict maintains the order of the keys as they were sorted.