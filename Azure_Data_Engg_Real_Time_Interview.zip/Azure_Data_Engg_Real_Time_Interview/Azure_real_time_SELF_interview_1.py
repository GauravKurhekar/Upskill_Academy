# Databricks notebook source
# MAGIC %md
# MAGIC ##### To delete any table present in hive metastore
# MAGIC dbutils.fs.rm('dbfs:/user/hive/warehouse/employee',recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### To create table in sql or pyspark
# MAGIC DROP TABLE IF EXISTS table_name;
# MAGIC CREATE TABLE IF NOT EXISTS table_name;

# COMMAND ----------

dbutils.fs.rm('/delta/empdetails',recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 1- 2nd highest salary dept wise using SQL?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Employee (
# MAGIC     emp_id INT,
# MAGIC     emp_name VARCHAR(100),
# MAGIC     emp_salary DECIMAL(10, 2),
# MAGIC     department VARCHAR(100)
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO Employee (emp_id, emp_name, emp_salary, department)
# MAGIC VALUES
# MAGIC     (1, 'John', 50000, 'IT'),
# MAGIC     (2, 'Jane', 60000, 'IT'),
# MAGIC     (3, 'Mike', 55000, 'HR'),
# MAGIC     (4, 'Emily', 52000, 'HR'),
# MAGIC     (5, 'Alex', 48000, 'Finance'),
# MAGIC     (6, 'Sarah', 53000, 'Finance');

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH RankedSalaries AS (
# MAGIC     SELECT 
# MAGIC         emp_id, 
# MAGIC         emp_name, 
# MAGIC         emp_salary, 
# MAGIC         department,
# MAGIC         DENSE_RANK() OVER (PARTITION BY department ORDER BY emp_salary DESC) AS salary_rank
# MAGIC     FROM 
# MAGIC         Employee
# MAGIC )
# MAGIC SELECT 
# MAGIC     department,
# MAGIC     emp_name,
# MAGIC     emp_salary
# MAGIC FROM 
# MAGIC     RankedSalaries
# MAGIC WHERE 
# MAGIC     salary_rank = 2;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 2- 2nd highest salary dept wise using Pyspark?

# COMMAND ----------

from pyspark.sql.window import Window
# Sample data
data = [
    (1, 'John', 50000, 'IT'),
    (2, 'Jane', 60000, 'IT'),
    (3, 'Mike', 55000, 'HR'),
    (4, 'Emily', 52000, 'HR'),
    (5, 'Alex', 48000, 'Finance'),
    (6, 'Sarah', 53000, 'Finance')
]

# Define schema
schema = ["emp_id", "emp_name", "emp_salary", "department"]

# Create DataFrame
df = spark.createDataFrame(data, schema=schema)

# COMMAND ----------

from pyspark.sql.functions import dense_rank
from pyspark.sql.window import Window

# Define window partitioned by department and ordered by salary
w = Window.partitionBy('department').orderBy('emp_salary')

# Add rank based on salary
df1 = df.withColumn('sec_hig_sal', dense_rank().over(w))

# Filter for rows where rank is 2
df2 = df1.filter(df1['sec_hig_sal'] == 2)   # df2 = df1.filter(df1.sec_hig_sal==2)

# Show the result
df2.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 3- Write a query to find Emp salary more than their manager salary dept wise using SQL?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create Employee table
# MAGIC CREATE TABLE Employee77 (
# MAGIC     emp_id INT,
# MAGIC     emp_name VARCHAR(100),
# MAGIC     emp_salary DECIMAL(10, 2),
# MAGIC     manager_id INT, -- This column indicates the manager for each employee
# MAGIC     department VARCHAR(100)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into Employee table
# MAGIC INSERT INTO Employee77 (emp_id, emp_name, emp_salary, manager_id, department)
# MAGIC VALUES
# MAGIC     (1, 'John', 50000, 3, 'IT'),
# MAGIC     (2, 'Jane', 60000, 3, 'IT'),
# MAGIC     (3, 'Mike', 55000, 5, 'HR'),
# MAGIC     (4, 'Emily', 52000, 5, 'HR'),
# MAGIC     (5, 'Alex', 48000, NULL, 'Finance'),
# MAGIC     (6, 'Sarah', 53000, 3, 'IT');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to find employees whose salary is more than their manager's salary dept wise
# MAGIC
# MAGIC SELECT e.emp_id, e.emp_name, e.emp_salary, e.manager_id, e.department
# MAGIC from Employee77 E
# MAGIC JOIN
# MAGIC Employee77 M
# MAGIC ON
# MAGIC E.manager_id = M.emp_id 
# MAGIC WHERE
# MAGIC E.emp_salary>M.emp_salary
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 4- Write a query to find Emp salary more than their manager salary dept wise using two different tables in SQL?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create Employee table
# MAGIC CREATE TABLE Employee88 (
# MAGIC     emp_id INT,
# MAGIC     emp_name VARCHAR(100),
# MAGIC     emp_salary DECIMAL(10, 2),
# MAGIC     manager_id INT
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into Employee table
# MAGIC INSERT INTO Employee88 (emp_id, emp_name, emp_salary, manager_id)
# MAGIC VALUES
# MAGIC     (1, 'John', 50000, 3),
# MAGIC     (2, 'Jane', 60000, 3),
# MAGIC     (3, 'Mike', 55000, 5),
# MAGIC     (4, 'Emily', 52000, 5),
# MAGIC     (5, 'Alex', 48000, NULL),
# MAGIC     (6, 'Sarah', 53000, 3);
# MAGIC
# MAGIC -- Create Department table
# MAGIC CREATE TABLE Department88 (
# MAGIC     dept_id INT,
# MAGIC     dept_name VARCHAR(100)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into Department table
# MAGIC INSERT INTO Department88 (dept_id, dept_name)
# MAGIC VALUES
# MAGIC     (1, 'IT'),
# MAGIC     (2, 'HR'),
# MAGIC     (3, 'Finance');

# COMMAND ----------

# MAGIC %sql
# MAGIC --Employee88 (emp_id, emp_name, emp_salary, manager_id)
# MAGIC --Department88 (dept_id, dept_name)
# MAGIC
# MAGIC select emp_id, emp_name, emp_salary, manager_id, dept_name as department
# MAGIC from Employee88 E
# MAGIC join Department d
# MAGIC on
# MAGIC e.manager_id = d.dept_id
# MAGIC where e.emp_salary>
# MAGIC (selelct emp_salary from Employee88 where emp_id = e.manager_id)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to find employees whose salary is more than their manager's salary dept wise
# MAGIC SELECT e.emp_id, e.emp_name, e.emp_salary, e.manager_id, d.dept_name AS department
# MAGIC FROM Employee88 e
# MAGIC JOIN Department88 d ON e.manager_id = d.dept_id
# MAGIC WHERE e.emp_salary > (
# MAGIC     SELECT emp_salary
# MAGIC     FROM Employee88
# MAGIC     WHERE emp_id = e.manager_id
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #####Question 5- Write a query to find Emp salary more than their manager salary dept wise using Pyspark?

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import col, lag
# Sample data
data = [
    (1, 'John', 50000, 3, 'IT'),
    (2, 'Jane', 60000, 3, 'IT'),
    (3, 'Mike', 55000, 5, 'HR'),
    (4, 'Emily', 52000, 5, 'HR'),
    (5, 'Alex', 48000, None, 'Finance'),
    (6, 'Sarah', 53000, 3, 'IT')
]

# Define schema
schema = ["emp_id", "emp_name", "emp_salary", "manager_id", "department"]

# Create DataFrame
df = spark.createDataFrame(data, schema=schema)

# Define window partitioned by department and ordered by salary
windowSpec = Window.partitionBy("department").orderBy("emp_salary")

# Add column with manager's salary using lag function
df = df.withColumn("manager_salary", lag("emp_salary").over(windowSpec))

# Filter for rows where employee salary is greater than manager's salary
result = df.filter(col("emp_salary") > col("manager_salary"))

# Select relevant columns
result = result.select("emp_id", "emp_name", "emp_salary", "manager_id", "department")

# Show the result
result.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 6-Read the data from parquet file then write the data again into parquet file with overwrite mode, compression and inferschema with header and save into some table in pyspark?

# COMMAND ----------

from pyspark.sql import SparkSession

# Initialize SparkSession
spark = SparkSession.builder \
    .appName("Read and Write Parquet File") \
    .getOrCreate()

# Read data from Parquet file
parquet_file_path = "path/to/your/parquet/file"

# Read data from Parquet file
df = spark.read.parquet("path_to_input_parquet_file")

# Write data back to Parquet file with overwrite mode, compression, inferSchema, and header
df_filtered.write \
    .mode("overwrite") \
    .option("compression", "snappy") \
    .option("header", "true") \
    .option("inferSchema", "true") \    
    .parquet("path_to_output_parquet_file")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 7- Write dataframe for ID column, id- 1,2,3,4

# COMMAND ----------

# Define the data
data = [(1,), (2,), (3,), (4,)]

# Define the column name
columns = ["id"]

# Create a DataFrame
df = spark.createDataFrame(data, columns)

# Show the DataFrame
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 8- We have below table, Find the top 3 customer names who placed the most orders in the last year?
# MAGIC
# MAGIC * Customers(customer_id, customer_name),
# MAGIC * Orders (order_id, customer_id, order_date),
# MAGIC * Order_Items(order_id, product_id),
# MAGIC * Products (product_id, product_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Table structure for Customers
# MAGIC CREATE TABLE Customers (
# MAGIC     customer_id INT,
# MAGIC     customer_name VARCHAR(100)
# MAGIC );
# MAGIC
# MAGIC -- Table structure for Orders
# MAGIC CREATE TABLE Orders (
# MAGIC     order_id INT,
# MAGIC     customer_id INT,
# MAGIC     order_date DATE
# MAGIC );
# MAGIC
# MAGIC -- Table structure for Order_Items
# MAGIC CREATE TABLE Order_Items (
# MAGIC     order_id INT,
# MAGIC     product_id INT
# MAGIC );
# MAGIC
# MAGIC -- Table structure for Products
# MAGIC CREATE TABLE Products (
# MAGIC     product_id INT,
# MAGIC     product_name VARCHAR(100)
# MAGIC );
# MAGIC
# MAGIC -- Sample records for Customers table
# MAGIC INSERT INTO Customers (customer_id, customer_name) VALUES
# MAGIC (1, 'John'),
# MAGIC (2, 'Jane'),
# MAGIC (3, 'Mike'),
# MAGIC (4, 'Emily');
# MAGIC
# MAGIC -- Sample records for Orders table
# MAGIC INSERT INTO Orders (order_id, customer_id, order_date) VALUES
# MAGIC (1, 1, '2023-03-15'),
# MAGIC (2, 1, '2023-05-20'),
# MAGIC (3, 2, '2023-08-10'),
# MAGIC (4, 3, '2024-01-05'),
# MAGIC (5, 4, '2023-11-28');
# MAGIC
# MAGIC -- Sample records for Order_Items table
# MAGIC INSERT INTO Order_Items (order_id, product_id) VALUES
# MAGIC (1, 101),
# MAGIC (1, 102),
# MAGIC (2, 103),
# MAGIC (3, 104),
# MAGIC (4, 105),
# MAGIC (5, 106);
# MAGIC
# MAGIC -- Sample records for Products table
# MAGIC INSERT INTO Products (product_id, product_name) VALUES
# MAGIC (101, 'Product A'),
# MAGIC (102, 'Product B'),
# MAGIC (103, 'Product C'),
# MAGIC (104, 'Product D'),
# MAGIC (105, 'Product E'),
# MAGIC (106, 'Product F');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT TOP 3 c.customer_name, COUNT(o.order_id) AS order_count
# MAGIC FROM Customers c
# MAGIC JOIN Orders o ON c.customer_id = o.customer_id
# MAGIC WHERE o.order_date >= DATEADD(year, -1, GETDATE()) -- Filtering orders from the last year
# MAGIC GROUP BY c.customer_name
# MAGIC ORDER BY order_count DESC;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 9- Optimization technique?
# MAGIC * 1-	Use standard coding and best practice to write the code.
# MAGIC * 2-	Use broadcast variable.
# MAGIC * 3-	Use broadcast joins.
# MAGIC * 4-	Use cache and persist intermediate data.
# MAGIC * 5-	Use partition and bucketing if needed.
# MAGIC * 6-	Repartition and coalesce ().
# MAGIC * 7-	use right file format for ex- .csv, .parquet, .json.
# MAGIC * 8-	define your own schema instead of infer Schema
# MAGIC * 9-	Avoid UDF and user build in function
# MAGIC * 10-	Filter out the data and unwanted columns as much possible as you can and bring only necessary data for processing
# MAGIC * 11-	instead of select *, give proper column name to retrieve data.
# MAGIC * 12-	Reduce Garbage Collection Overhead.
# MAGIC * 13-	Use Partition Pruning.
# MAGIC * 14-	Make Use of Data Skew.
# MAGIC * 15-	use right number of executor and executor cores.
# MAGIC * 16-	Right memory configuration for driver and spark.
# MAGIC * 17- Use Adeptive query enable(AQE) which comes in spark 3.0 onwards by default
# MAGIC * 18- Predicate pushdown, where filter and where condition is used
# MAGIC * 19- Avoid using collect () function.
# MAGIC * 20 -Enable Snappy Compression.  
# MAGIC * 21- Avoid unnecessary shuffle.  

# COMMAND ----------

# MAGIC %md
# MAGIC #####1- Broadcast variable Example
# MAGIC * A broadcast variable is a read-only shared variable that is cached and available on all nodes in a cluster.
# MAGIC * It helps reduce communication costs by distributing data efficiently to workers.
# MAGIC * Example: Suppose we have a lookup table for state abbreviations and their full names. Instead of sending this data with every task, we can use broadcast variable to cache it on each machine.
# MAGIC * Here’s how you can create and use a broadcast variable:

# COMMAND ----------

# Define a lookup table (state abbreviations to full names)
states = {"NY": "New York", "CA": "California", "FL": "Florida"}

# Broadcast the lookup table
broadcast_states = spark.sparkContext.broadcast(states)

# Create an RDD with sample data
data = [("James", "Smith", "USA", "CA"),
        ("Michael", "Rose", "USA", "NY"),
        ("Robert", "Williams", "USA", "CA"),
        ("Maria", "Jones", "USA", "FL")]
rdd = spark.sparkContext.parallelize(data)

# Use the broadcast variable to convert state abbreviations to full names
result = rdd.map(lambda x: (x[0], x[1], x[2], broadcast_states.value.get(x[3], x[3]))).collect()

# Display the result
for row in result:
    print(row)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2- Broadcast Join
# MAGIC * Broadcast join is an optimization technique for joining a large DataFrame with a smaller one.
# MAGIC * The smaller DataFrame is broadcast to all executors, and the larger DataFrame is split and distributed across executors.
# MAGIC * Example: Suppose we have two DataFrames orders and customers, and we want to join them on the customer_id column. If the customers DataFrame is small, * we can use a broadcast join.
# MAGIC * Here’s how you can perform a broadcast join:

# COMMAND ----------

# Assuming you have 'orders' and 'customers' DataFrames
# Join 'orders' with 'customers' using broadcast join
joined_df = orders.join(customers, on='customer_id', how='inner')

# Show the result
joined_df.show()

--OR
data1 = [("John", 25), ("Jane", 30), ("Mike", 35)]
data2 = [("John", "New York"), ("Jane", "Los Angeles"), ("Mike", "Chicago")]

# Create DataFrames
df1 = spark.createDataFrame(data1, ["name", "age"])
df2 = spark.createDataFrame(data2, ["name", "city"])

# Broadcast join
result = df1.join(df2, "name", on='customer_id', how='inner')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3- Cache and Persist:
# MAGIC * Caching and persisting are used to save intermediate computation results in memory or on disk.
# MAGIC * Use cache() or persist() methods to store DataFrames in memory or disk.
# MAGIC * Example:

# COMMAND ----------

# Cache a DataFrame in memory
df.cache()

# Persist a DataFrame on disk (MEMORY_AND_DISK storage level)
df.persist()

# Unpersist (remove from cache)
df.unpersist()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4- Partitioning involves dividing a large dataset into smaller chunks (partitions) based on one or more partition keys.
# MAGIC * Use repartition() or coalesce() transformations to control the number of partitions.

# COMMAND ----------

# Repartition the DataFrame by a specific column
df_repartitioned = df.repartition(4, 'column_name')

# Coalesce the DataFrame to reduce the number of partitions
df_coalesced = df.coalesce(2)


# COMMAND ----------

# MAGIC %md
# MAGIC #####5- Bucketing: Bucketing divides data into a fixed number of buckets based on a chosen column.
# MAGIC * It helps organize related data together and optimize queries.

# COMMAND ----------

# Bucket the DataFrame by a specific column
df_bucketed = df.write.bucketBy(4, 'column_name').saveAsTable('bucketed_table')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 10- dbutils.widgets commands?

# COMMAND ----------

dbutils.widgets.help()
dbutils.widgets.combobox
dbutils.widgets.dropdown
dbutils.widgets.text

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 11- dbutils.filesystem commands

# COMMAND ----------

dbutils.fs.help()
dbutils.fs.mount
dbutils.fs.refreshMounts
dbutils.fs.unmount
dbutils.fs.cp
dbutils.fs.mv
dbutils.fs.rm
dbutils.fs.mkdirs
dbutils.fs.ls
dbutils.fs.put
dbutils.fs.head

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 12-write a program to find the second higest number from list?
# MAGIC

# COMMAND ----------

# List of numbers
list1 = [10, 20, 20, 4, 45, 45, 45, 99, 99]
 
# Removing duplicates from the list
list2 = list(set(list1))
 
# Sorting the  list
list2.sort()
 
# Printing the second last element
print("Second largest element is:", list2[-2])

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 13- Write a program to summension/total sum of all numbers from list?
# MAGIC

# COMMAND ----------

lst = [1, 9, 4, 7, 6, 2, 5, 8, 3]

# Calculate the sum of all numbers in the list
total_sum = sum(lst)

# Print the result
print(f"The sum of all numbers in the list is: {total_sum}")

# COMMAND ----------

lst = [1, 9, 4, 7, 6, 2, 5, 8, 3]

# Initialize a variable to store the sum
total_sum = 0

# Iterate through the list and add each element to the sum
for number in lst:
    total_sum += number

# Print the result
print("List:", lst)
print("Sum of all numbers:", total_sum)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 14- Write a function to find mean of number from list?
# MAGIC

# COMMAND ----------

def calculate_mean(lst):
    # Check if the list is not empty to avoid division by zero
    if not lst:
        return None  # Return None if the list is empty

    mean = sum(lst) / len(lst)
    return mean
    

# Example usage
lst = [1, 9, 4, 7, 6, 2, 5, 8, 3]
result_mean = calculate_mean(lst)

if result_mean is not None:
    print(f"Mean of the list {lst}: {result_mean}")
else:
    print("The list is empty.")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Quesion 15- To work on all join operations- inner, full, left outer, right outer
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table Table_A111

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Table_A111 (
# MAGIC     ID INT
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data into Table1
# MAGIC INSERT INTO Table_A111 VALUES
# MAGIC (1),
# MAGIC (2),
# MAGIC (1),
# MAGIC (0),
# MAGIC (Null);
# MAGIC -- Create Table2
# MAGIC
# MAGIC CREATE TABLE Table_B111 (
# MAGIC     ID INT
# MAGIC );
# MAGIC
# MAGIC -- Insert sample data into Table2
# MAGIC INSERT INTO Table_B111 VALUES
# MAGIC (1),
# MAGIC (2),
# MAGIC (1),
# MAGIC (0),
# MAGIC (Null);

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1-- Count of records for inner join

# COMMAND ----------

# MAGIC %sql    -- Count of records for inner join
# MAGIC SELECT COUNT(*) AS InnerJoinCount
# MAGIC FROM Table_A111 t1
# MAGIC INNER JOIN Table_B111 t2 ON t1.ID = t2.ID;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2-- Count of records for Left join or Left Outer join (Both left join and left outer join are same)

# COMMAND ----------

# MAGIC %sql    -- Count of records for Left join
# MAGIC SELECT COUNT(*) AS LeftCount
# MAGIC FROM Table_A111 t1
# MAGIC Left JOIN Table_B111 t2 ON t1.ID = t2.ID;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3-- Count of records for Left-anti join

# COMMAND ----------

# MAGIC %sql    -- Count of records for Left-anti join
# MAGIC SELECT COUNT(*) AS LeftCount
# MAGIC FROM Table_A111 t1
# MAGIC LEFT ANTI JOIN Table_B111 t2 
# MAGIC ON t1.ID = t2.ID;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4-- Count of records for Left-semi join
# MAGIC * A left semi join in Spark SQL is a type of join operation that returns only the columns from the left dataframe that have matching values in the right dataframe.
# MAGIC * The result of a left semi join is a dataframe that contains only the columns from the left dataframe that have matching values in the right dataframe. 

# COMMAND ----------

# MAGIC %sql    -- Count of records for Left-semi join
# MAGIC SELECT COUNT(*) AS LeftCount
# MAGIC FROM Table_A111 t1
# MAGIC LEFT SEMI JOIN Table_B111 t2 
# MAGIC ON t1.ID = t2.ID;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 5- -- Count of records for Right join

# COMMAND ----------

# MAGIC %sql    -- Count of records for Right join
# MAGIC SELECT COUNT(*) AS RightCount
# MAGIC FROM Table_A111 t1
# MAGIC RIGHT JOIN Table_B111 t2 ON t1.ID = t2.ID;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 6- -- Count of records for Right-Anti join
# MAGIC RIGHT ANTI JOIN is not standard SQL and might not be supported by all database systems. If your database system does not support RIGHT ANTI JOIN, you can achieve the same result using a combination of RIGHT JOIN and a WHERE clause with IS NULL. Here's the corrected code:

# COMMAND ----------

# MAGIC %sql   -- Count of records for Right-Anti join
# MAGIC SELECT COUNT(*) AS RightCount
# MAGIC FROM Table_A111 t1
# MAGIC RIGHT JOIN Table_B111 t2 ON t1.ID = t2.ID
# MAGIC WHERE t1.ID IS NULL;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 7- -- Count of records for Right-Semi join

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS RightCount
# MAGIC FROM Table_A111 t1
# MAGIC RIGHT JOIN Table_B111 t2 ON t1.ID = t2.ID
# MAGIC WHERE t1.ID IS NOT NULL; -- Using WHERE clause to mimic RIGHT SEMI JOIN behavior

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 8-- Count of records for Full join or Full Outer join

# COMMAND ----------

# MAGIC %sql    -- Count of records for Full join
# MAGIC SELECT COUNT(*) AS FullCount
# MAGIC FROM Table_A111 t1
# MAGIC FULL JOIN Table_B111 t2 ON t1.ID = t2.ID;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 16-find difference between current year sales vs previous year sales using SQL?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create sales_table
# MAGIC CREATE TABLE sales_table (
# MAGIC     year INT,
# MAGIC     total_sale DECIMAL(10, 2)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into sales_table
# MAGIC INSERT INTO sales_table (year, total_sale) VALUES
# MAGIC (2015, 23000),
# MAGIC (2016, 25000),
# MAGIC (2017, 34000),
# MAGIC (2018, 32000),
# MAGIC (2019, 33000);

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sales_table

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     year,
# MAGIC     total_sale,
# MAGIC     total_sale - LAG(total_sale) OVER (ORDER BY year) AS Sales_Difference
# MAGIC FROM sales_table
# MAGIC ORDER BY year;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 17-find difference between current year sales vs previous year sales using Pyspark?

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import lag, col, coalesce

# Sample data (replace with your actual data)
data = [(2015, 23000),
        (2016, 25000),
        (2017, 34000),
        (2018, 32000),
        (2019, 33000)]

# Create DataFrame
df = spark.createDataFrame(data, ["year", "total_sale"])

# Calculate difference between current year sales and previous year sales
w = Window.orderBy("year")

df = df.withColumn("previous_year_sale", lag("total_sale").over(w))
df1 = df.withColumn("YOY_Difference", col("total_sale") - coalesce(col("previous_year_sale")))

# Show the result
df1.show()

# We calculate the year-over-year difference and handle any potential NULL values using the coalesce function.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 18-We have two tables, product_table and sales_table, Write a query in SQL to select the top product sold in each year?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create product_table
# MAGIC drop table if exists product_table;
# MAGIC CREATE TABLE product_table (
# MAGIC     PRODUCT_ID INT,
# MAGIC     PRODUCT_NAME VARCHAR(100)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into product_table
# MAGIC INSERT INTO product_table (PRODUCT_ID, PRODUCT_NAME) VALUES
# MAGIC (100, 'Nokia'),
# MAGIC (200, 'IPhone'),
# MAGIC (300, 'Samsung'),
# MAGIC (400, 'LG');
# MAGIC
# MAGIC -- Create sales_table
# MAGIC drop table if exists sales_table;
# MAGIC CREATE TABLE sales_table (
# MAGIC     SALE_ID INT,
# MAGIC     PRODUCT_ID INT,
# MAGIC     YEAR INT,
# MAGIC     QUANTITY INT,
# MAGIC     PRICE DECIMAL(10, 2)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into sales_table
# MAGIC INSERT INTO sales_table (SALE_ID, PRODUCT_ID, YEAR, QUANTITY, PRICE) VALUES
# MAGIC (1, 100, 2010, 25, 5000),
# MAGIC (2, 100, 2011, 16, 5000),
# MAGIC (3, 100, 2012, 8, 5000),
# MAGIC (4, 200, 2010, 10, 9000),
# MAGIC (5, 200, 2011, 15, 9000),
# MAGIC (6, 200, 2012, 20, 9000),
# MAGIC (7, 300, 2010, 20, 7000);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from product_table;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sales_table;

# COMMAND ----------

# MAGIC %sql  -- We have two tables, product_table and sales_table, Write a query in SQL to select the top product sold in each year?
# MAGIC WITH RankedProducts AS (
# MAGIC     SELECT 
# MAGIC         p.PRODUCT_NAME,
# MAGIC         s.YEAR,
# MAGIC         s.QUANTITY,
# MAGIC         ROW_NUMBER() OVER (PARTITION BY s.YEAR ORDER BY s.QUANTITY DESC) AS rank
# MAGIC     FROM 
# MAGIC         sales_table s
# MAGIC     JOIN 
# MAGIC         product_table p ON s.PRODUCT_ID = p.PRODUCT_ID
# MAGIC )
# MAGIC SELECT 
# MAGIC     YEAR,
# MAGIC     PRODUCT_NAME,
# MAGIC     QUANTITY
# MAGIC FROM 
# MAGIC     RankedProducts
# MAGIC WHERE 
# MAGIC     rank = 1;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 19-We have two tables, product_table and sales_table, Write a query to select the top product sold in each year using Pyspark?

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number

# Sample data
product_data = [
    (100, 'Nokia'),
    (200, 'IPhone'),
    (300, 'Samsung'),
    (400, 'LG')
]

sales_data = [
    (1, 100, 2010, 25, 5000),
    (2, 100, 2011, 16, 5000),
    (3, 100, 2012, 8, 5000),
    (4, 200, 2010, 10, 9000),
    (5, 200, 2011, 15, 9000),
    (6, 200, 2012, 20, 9000),
    (7, 300, 2010, 20, 7000)
]

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number

# Create DataFrame
product_df = spark.createDataFrame(product_data, ["PRODUCT_ID", "PRODUCT_NAME"])
sales_df = spark.createDataFrame(sales_data, ["SALE_ID", "PRODUCT_ID", "YEAR", "QUANTITY", "PRICE"])

# Define window specification ordered by year and quantity
windowSpec = Window.partitionBy("YEAR").orderBy(col("QUANTITY").desc())

# Join sales_df with product_df on PRODUCT_ID
ranked_products_df = sales_df.join(product_df, "PRODUCT_ID")

# Add a new column "rank" using the row_number() window function
ranked_products_df = ranked_products_df.withColumn("rank", row_number().over(windowSpec))

# Filter the DataFrame to select only the rows where rank is 1
ranked_products_df = ranked_products_df.filter(col("rank") == 1)

# Select only the columns "YEAR", "PRODUCT_NAME", and "QUANTITY"
ranked_products_df = ranked_products_df.select("YEAR", "PRODUCT_NAME", "QUANTITY")

# Show the result
ranked_products_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 20- We have customer_table having three columns, cust_id, tran_date, trans_amount, Find the latest three transactions for each customer in given month in SQL?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE customer_table123 (
# MAGIC     cust_id INT,
# MAGIC     transaction_date DATE,
# MAGIC     transaction_amount DECIMAL(10, 2)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO customer_table123 (cust_id, transaction_date, transaction_amount) VALUES
# MAGIC (1, '2024-03-01', 100.00),
# MAGIC (1, '2024-03-05', 150.00),
# MAGIC (1, '2024-03-10', 200.00),
# MAGIC (1, '2024-03-15', 120.00),
# MAGIC (1, '2024-03-20', 180.00),
# MAGIC (2, '2024-03-02', 75.00),
# MAGIC (2, '2024-03-06', 90.00),
# MAGIC (2, '2024-03-09', 110.00),
# MAGIC (2, '2024-03-14', 130.00),
# MAGIC (2, '2024-03-18', 160.00),
# MAGIC (3, '2024-03-03', 50.00),
# MAGIC (3, '2024-03-07', 70.00),
# MAGIC (3, '2024-03-11', 85.00),
# MAGIC (3, '2024-03-16', 95.00),
# MAGIC (3, '2024-03-21', 105.00);
# MAGIC
# MAGIC select * from  customer_table123

# COMMAND ----------

# MAGIC %sql  -- Find the latest three transactions for each customer in given month in SQL?
# MAGIC WITH RankedTransactions AS (
# MAGIC     SELECT 
# MAGIC         cust_id, 
# MAGIC         transaction_date, 
# MAGIC         transaction_amount,
# MAGIC         ROW_NUMBER() OVER (PARTITION BY cust_id ORDER BY transaction_date DESC) AS row_num
# MAGIC     FROM 
# MAGIC         customer_table123
# MAGIC     WHERE 
# MAGIC         MONTH(transaction_date) = 3  -- Replace <month> with the desired month (e.g., 3 for March, 4 for april)
# MAGIC )                                    -- YEAR(transaction_date) =2024 (2024 year)
# MAGIC SELECT                               -- YEAR(transaction_date) = 07 (7th day)
# MAGIC     cust_id, 
# MAGIC     transaction_date, 
# MAGIC     transaction_amount
# MAGIC FROM 
# MAGIC     RankedTransactions
# MAGIC WHERE 
# MAGIC     row_num <= 3;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 21- Suppose we have TableA having some records and TableB having some records, how to check in sql if both table having exact records?
# MAGIC * To check if two tables have exactly the same records, you can use the EXCEPT operator in SQL. The **EXCEPT** operator returns the rows that are present in the first query but not in the second query.

# COMMAND ----------

# MAGIC %sql  
# MAGIC -- Check if TableA has the same records as TableB
# MAGIC SELECT * FROM TableA
# MAGIC EXCEPT
# MAGIC SELECT * FROM TableB;
# MAGIC
# MAGIC -- Check if TableB has the same records as TableA
# MAGIC SELECT * FROM TableB
# MAGIC EXCEPT
# MAGIC SELECT * FROM TableA;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 22- How to remove and identify duplicates in a table using different techniques in SQL?
# MAGIC ##### We can remove duplicates using multiple techniques
# MAGIC ##### 1. distinct() -SELECT DISTINCT column1, column2 from table_name;
# MAGIC ##### 2. dropDuplicates(), drop_Duplicates()
# MAGIC ##### 3. window function() with Row_number()
# MAGIC ##### 4. groupBy() with count()
# MAGIC
# MAGIC * 1- Using GROUP BY
# MAGIC * 2- Using window functions
# MAGIC * 3- Using Common Table Expressions (CTEs)
# MAGIC * 4-  Using self-join
# MAGIC
# MAGIC * **<>**: The <> operator is used to check for inequality between two values. It returns true if the two values are not equal. It is often used in WHERE clauses or JOIN conditions to filter or join rows based on inequality.
# MAGIC
# MAGIC * SELECT *
# MAGIC FROM table
# MAGIC WHERE column1 <> column2;
# MAGIC
# MAGIC * **COUNT(*)**: The COUNT(*) function is an aggregate function used in conjunction with the GROUP BY clause. It counts the number of rows in each group defined by the GROUP BY clause. When used without any arguments, COUNT(*) counts all rows, including those with NULL values, within each group.
# MAGIC
# MAGIC * SELECT department, COUNT(*)
# MAGIC FROM employees
# MAGIC GROUP BY department;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the sample table
# MAGIC CREATE TABLE EmployeeDuplicate (
# MAGIC     EmployeeID INT,
# MAGIC     FirstName VARCHAR(50),
# MAGIC     LastName VARCHAR(50),
# MAGIC     Department VARCHAR(50)
# MAGIC );
# MAGIC
# MAGIC -- Insert some sample records with duplicates
# MAGIC INSERT INTO EmployeeDuplicate(EmployeeID, FirstName, LastName, Department)
# MAGIC VALUES 
# MAGIC     (1, 'John', 'Doe', 'HR'),
# MAGIC     (2, 'Jane', 'Smith', 'Finance'),
# MAGIC     (3, 'John', 'Doe', 'HR'),
# MAGIC     (4, 'Emily', 'Brown', 'Marketing'),
# MAGIC     (5, 'John', 'Doe', 'IT');
# MAGIC
# MAGIC select * from EmployeeDuplicate;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### -- 1- Using Group By

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 1- Using Group By
# MAGIC SELECT FirstName, LastName, COUNT(*) AS DuplicateCount
# MAGIC FROM EmployeeDuplicate
# MAGIC GROUP BY FirstName, LastName
# MAGIC HAVING COUNT(*) > 1;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### -- 2- Using Window Function

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 2- Using Window Function
# MAGIC SELECT EmployeeID, FirstName, LastName, Department, 
# MAGIC        ROW_NUMBER() OVER (PARTITION BY FirstName, LastName ORDER BY EmployeeID) AS RowNum
# MAGIC FROM EmployeeDuplicate; 

# COMMAND ----------

# MAGIC %md
# MAGIC ##### -- 3- Using CTE

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 3- Using CTE
# MAGIC WITH CTE AS (
# MAGIC     SELECT EmployeeID, FirstName, LastName, Department,
# MAGIC            ROW_NUMBER() OVER (PARTITION BY FirstName, LastName ORDER BY EmployeeID) AS RowNum
# MAGIC     FROM EmployeeDuplicate
# MAGIC )
# MAGIC SELECT *
# MAGIC FROM CTE
# MAGIC WHERE RowNum > 1;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### -- 4 Using Self Join

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 4 Using Self Join
# MAGIC SELECT e1.EmployeeID, e1.FirstName, e1.LastName, e1.Department
# MAGIC FROM EmployeeDuplicate e1
# MAGIC JOIN EmployeeDuplicate e2 ON e1.FirstName = e2.FirstName 
# MAGIC                  AND e1.LastName = e2.LastName 
# MAGIC                  AND e1.EmployeeID <> e2.EmployeeID;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 23- What are the different different techniques to identify and remove duplicated in sql?
# MAGIC * 1. Using SELECT DISTINCT:
# MAGIC * 2. Using GROUP BY:
# MAGIC * 3. Identifying Duplicates with DELETE and Joins:
# MAGIC * 4. Using Common Table Expressions (CTE): 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from employeeduplicate

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1- Using Common Table Expression(CTE)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC with CTE as (
# MAGIC   select *, row_number() over (partition by firstname, lastname order by EmployeeID) as dup from employeeduplicate
# MAGIC )
# MAGIC delete from CTE where dup>1

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2. Using GROUP BY:

# COMMAND ----------

# MAGIC %sql
# MAGIC select firstname, lastname, count(*)as duplicate_count from employeeduplicate
# MAGIC group by firstname, lastname
# MAGIC having count(*)>1

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3. Using SELECT DISTINCT:

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct * from employeeduplicate

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4. Identifying Duplicates with DELETE and Joins:

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE E
# MAGIC FROM employeeduplicate E
# MAGIC INNER JOIN employeeduplicate D
# MAGIC     ON E.EmployeeID <> D.EmployeeID -- Use > instead of <>
# MAGIC     AND E.FirstName = D.FirstName
# MAGIC     AND E.LastName = D.LastName
# MAGIC     AND E.Department = D.Department;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 24- lst = [1,9,4,7,6,2,5,8,3], find the addition of all numbers?
# MAGIC * 1- By using inbuild Sum() function
# MAGIC * 2- By using For loop 

# COMMAND ----------

-- 1- By Using SUM Function
lst = [1,9,4,7,6,2,5,8,3]
sum_of_numbers = sum(lst)
print(sum_of_numbers)

# COMMAND ----------

-- 2 - By using for loop
lst = [1,9,4,7,6,2,5,8,3]
sum_num = 0
for i in lst:
    sum_num = sum_num + i  # or sum_num +=i
print(sum_num)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 25- lst = [1,9,4,7,6,2,5,8,3], find the second largest numbers?

# COMMAND ----------

1- By using Slicing
lst = [1,9,4,7,6,2,5,8,3]
print(lst[-2])

# COMMAND ----------

2- By using user define function (UDF)
# Given list
my_list = [1, 9, 4, 7, 6, 2, 5, 8, 3]

def find_second_highest_sorted(lst):
    sorted_lst = sorted(lst)
    return sorted_lst[-2]

# Call the function with the list
result = find_second_highest_sorted(my_list)

print("Second highest number:", result)


# COMMAND ----------

--By using sort function and reverse=True
lst = [1, 9, 4, 7, 6, 2, 5, 8, 3]

# Sort the list in descending order
lst.sort(reverse=True)

# The second highest number is at index 1
second_highest = lst[1]

print("Second highest number:", second_highest)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 26- Write a program to find mean of number?

# COMMAND ----------

# Example usage:
my_list = [1, 9, 4, 7, 6, 2, 5, 8, 3]

def calculate_mean(my_list):

    # Calculate the mean
    mean = sum(my_list) / len(my_list)
    return mean

result = calculate_mean(my_list)
print("Mean of the numbers:", result)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 27- Write a program to summension of number?

# COMMAND ----------

# Example usage:
my_list = [1, 9, 4, 7, 6, 2, 5, 8, 3]

def calculate_sum(my_list):
    # Calculate the sum of the numbers
    summation = sum(my_list)

    return summation

result = calculate_sum(my_list)
print("Sum of the numbers:", result)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 28- I have a table called Emp_table having Eid, Ename, Sal, DeptID, can you find DeptID wise total sal and show only those dept in output whose sal> 1000000?

# COMMAND ----------

CREATE TABLE Emp_table (
    Eid INT,
    Ename VARCHAR(50),
    Sal DECIMAL(10, 2),
    DeptID INT
);
INSERT INTO Emp_table (Eid, Ename, Sal, DeptID) VALUES
(1, 'John Doe', 1200000.00, 101),
(2, 'Jane Smith', 950000.00, 102),
(3, 'Alice Johnson', 1100000.00, 101),
(4, 'Bob Anderson', 1050000.00, 103),
(5, 'Charlie Brown', 980000.00, 102),
(6, 'Emma Watson', 1250000.00, 101);


# COMMAND ----------

SELECT 
    DeptID, 
    SUM(Sal) AS Total_Salary
FROM 
    Emp_table
GROUP BY 
    DeptID
HAVING 
    SUM(Sal) > 1000000;


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 29- Convert the list into dictionary? lst = [1,1,1,2,2,3,3,3,3,4,4] and desire output is dict= {1:3, 2:2, 3:4, 4:2}

# COMMAND ----------

# 1- By using Counter
from collections import Counter

lst = [1, 1, 1, 2, 2, 3, 3, 3, 3, 4, 4]
result_dict = dict(Counter(lst))

print(result_dict)

# COMMAND ----------

# 2- By using For loop
lst = [1, 1, 1, 2, 2, 3, 3, 3, 3, 4, 4]
my_dict= {}
for i in lst:
    if i in my_dict:
        my_dict[i]+=1
    else:
        my_dict[i] = 1
print(my_dict)

# COMMAND ----------

lst = [1, 1, 1, 2, 2, 3, 3, 3, 3, 4, 4]
output = {}
for i in lst:
    if i in output:
        output[i]+=1
    else:
        output[i]= 1
print(output)

#if i in op_dict:: This line checks if the current element i is already a key in the dictionary op_dict. If it is, it means that we have encountered this element before, so we need to increment its count.

#op_dict[i] += 1: If the current element i is already in the dictionary, this line increments its count by 1.

#else:: If the current element i is not already a key in the dictionary op_dict, it means that we are encountering this element for the first time.

#op_dict[i] = 1: In this case, we add the current element i as a key to the dictionary op_dict and initialize its count to 1.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 30- Convert the Dictionary into List of tuple?

# COMMAND ----------

my_dict = {1: 'apple', 2: 'banana', 3: 'orange'}

list_of_tuples = list(my_dict.items())

print(list_of_tuples)


# COMMAND ----------

lst = [5, 5, 5, 5, 5, 5, 5]

op_dict = {}
for i in lst:
    if i in op_dict:
        op_dict[i]+= 1
    else:
        op_dict[i]=1
print(op_dict)

# COMMAND ----------

# Assuming df is your DataFrame
df.createOrReplaceGlobalTempView("shared_view")
