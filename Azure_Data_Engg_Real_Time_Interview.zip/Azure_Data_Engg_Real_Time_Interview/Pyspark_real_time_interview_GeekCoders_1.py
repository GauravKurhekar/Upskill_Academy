# Databricks notebook source
# MAGIC %md
# MAGIC ##### Question 1 - 1. Merge two Dataframes using PySpark?

# COMMAND ----------

# union can only perform with table with same number of columns, here first df contain 5 column and 2nd df contain only 4 column

SampleData1 = [(1, 'Gaurav', 'IT', 'MH', 80), \
              (2, 'Vaidehi', 'HR', 'MH', 60) ]
Columns1 = ['ID', 'Student_Name', 'Department_Name', 'State', 'Marks']

df1 = spark.createDataFrame(data = SampleData1, schema = Columns1)
df1.show()

# COMMAND ----------


SampleData2 = [(3, 'Monu', 'Comp', 'MH'), \
                (4, 'Vaidu', 'HR', 'MH')]
Columns2 = ['ID', 'Student_Name', 'Department_Name', 'State']

df2 = spark.createDataFrame(data=SampleData2, schema=Columns2)
df2.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### solution 1 - add extra column in 2nd df to make similar column in both df

# COMMAND ----------

from pyspark.sql.functions import lit
df3 = df2.withColumn('Marks', lit('null'))
df1.union(df3).show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Solution 2 - unionByName- this method can use when we have not same column in dataframe

# COMMAND ----------

merged_df = df1.unionByName(df2)
merged_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 2 - 2. Explode columns using PySpark?

# COMMAND ----------

# Question is in word file

from pyspark.sql.functions import explode, col

SampleData = [(1, ['Gaurav', 'Kurhekar']), \
            (2, ['Vaidehi', 'Kurhekar']),\
            (3, ['Monu', 'Kurhekar'])]
Columns = ['ID', 'Name']
df = spark.createDataFrame(data = SampleData, schema = Columns)
df.show()


# COMMAND ----------

from pyspark.sql.functions import explode, col
df_output = df.select(col('ID'), explode(col('Name')))
df_output.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 3 -  select only correct records from below dataframe, Solve using Regex using PySpark?

# COMMAND ----------

Sample = [(1, 'Gaurav', 'a8087b387c187'), \
              (2, 'Vaidehi','7020269389') ]
Columns = ['ID', 'Name','Mobile']

df1 = spark.createDataFrame(data = Sample, schema = Columns)
df1.show()

# COMMAND ----------

df1.select('*').filter(col('Mobile').rlike('^[0-9]*$')).show()
# * = all the numbers only, not digits
# $ = meaning Mobile number end with numbers only
# ^ cap = meaning mobile number start with numbers only

# by using spark.sql- which is easy
spark.sql("select * from student where Mobile rlike('^[0-9]*$')").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 4 - Skip line while loading data into dataFrame using pyspark?
# MAGIC 1st Method

# COMMAND ----------

# 1st Method- 
from pyspark.sql.functions import col
SampleData1 = [(1, 'Gaurav', 'IT'), \
              (2, 'Vaidehi', 'HR'),\
              (3, 'Vaidu', 'Comp')]
Columns1 = ['ID', 'Student_Name', 'Department_Name']

df1 = spark.createDataFrame(data = SampleData1, schema = Columns1)
df1.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method1 -  By using not equal to operator  !=

# COMMAND ----------

df2 = df1.filter(col("ID") != 2)
df2.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method 2- By using isin operator  isin([])

# COMMAND ----------

# 2nd Method- 
from pyspark.sql.functions import col
SampleData1 = [(1, 'Gaurav', 'IT'), \
              (2, 'Vaidehi', 'HR'),\
              (3, 'Vaidu', 'Comp')]
Columns1 = ['ID', 'Student_Name', 'Department_Name']

df1 = spark.createDataFrame(data = SampleData1, schema = Columns1)

df1 = df1.filter(col("ID").isin([1, 3]))
df1.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method3 - By using the zipWithIndex function to add an index to each line

# COMMAND ----------

# 3rd Method
from pyspark.sql import Row

SampleData1 = [(1, 'Gaurav', 'IT'), \
              (2, 'Vaidehi', 'HR'),\
              (3, 'Vaidu', 'Comp')]
Columns1 = ['ID', 'Student_Name', 'Department_Name']
df1 = spark.createDataFrame(data = SampleData1, schema = Columns1)

# convert dataframe to rdd
indexed_rdd = df1.rdd

# Use the zipWithIndex function to add an index to each line
indexed_rdd = indexed_rdd.zipWithIndex()

# Filter out the line you want to skip (e.g., line with index 1)
filtered_rdd = indexed_rdd.filter(lambda x: x[1] != 1)

# Remove the index from the filtered lines
data_rdd = filtered_rdd.map(lambda x: x[0])

# Split the lines and create Row objects
data_rdd = data_rdd.map(lambda line: line.split(','))
data_rdd = data_rdd.map(lambda p: Row(ID=int(p[0]), Student_Name=p[1], Department_Name=p[2]))

# Create a DataFrame from the filtered and processed data
# df = spark.createDataFrame(data_rdd)

# Show the DataFrame
#df.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 5 - Count rows in each column where NULLs present?

# COMMAND ----------

from pyspark.sql.functions import col
SampleData = [(1, 'Gaurav', 32), \
              (2, 'Vaidehi', 28),\
              (3, 'Vaidu', 27), \
              (4, 'Monu', 24),\
              (5, 'MV', 31)]
Columns = ['ID', 'Name', 'Age']

df1 = spark.createDataFrame(data = SampleData, schema = Columns)
df1.show()

# COMMAND ----------

from pyspark.sql.functions import col, count, when
SampleData = [(1, 'Gaurav', 32), \
              (2, 'Vaidehi', 28),\
              (3, 'Vaidu', 27), \
              (4, 'Null', 24),\
              (5, 'Null', 'Null')]
Columns = ['ID', 'Name', 'Age']

df1 = spark.createDataFrame(data = SampleData, schema = Columns)
df1= df1.select([count(when(col(i).isNull(),i)).alias(i) for i in df1.columns])
df1.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### breaking for loop into multiple rows

# COMMAND ----------

from pyspark.sql.functions import col, count, when

# Initialize an empty list to store count expressions
column_counts = []

# Iterate over columns and create count expressions
for i in df1.columns:
    # Create a condition to check for NULL values in the column
    condition = when(col(i).isNull(), i)
    
    # Use the count function to count rows satisfying the condition, and alias the result with the column name
    count_expression = count(condition).alias(i)
    
    # Append the count expression to the list
    column_counts.append(count_expression)

# Create a new DataFrame with the count expressions
df_counts = df1.select(column_counts)

# Show the result
df_counts.show()

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum

# Create a Spark session
spark = SparkSession.builder.appName("example").getOrCreate()

# Create the DataFrame
SampleData = [(1, 'Gaurav', 32),
              (2, 'Vaidehi', 28),
              (3, 'Vaidu', 27),
              (4, 'Null', 24),
              (5, 'Null', 'Null')]
Columns = ['ID', 'Name', 'Age']
df1 = spark.createDataFrame(data=SampleData, schema=Columns)

# Count null values in each column
null_counts = df1.select([sum(col(c).isNull().cast("int")).alias(c) for c in df1.columns])

# Show the null value counts
null_counts.show()


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count, when

# Create a Spark session
spark = SparkSession.builder.appName("example").getOrCreate()

# Create the DataFrame
SampleData = [(1, 'Gaurav', 32),
              (2, 'Vaidehi', 28),
              (3, 'Vaidu', 27),
              (4, 'Null', 24),
              (5, 'Null', 'Null')]
Columns = ['ID', 'Name', 'Age']
df1 = spark.createDataFrame(data=SampleData, schema=Columns)

# Count null values in each column
df1 = df1.select([count(when(col(i).isNull(), i)).alias(i) for i in df1.columns])

# Show the null value counts
df1.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 6 - How to handle multi delimiters
# MAGIC Question is in word file

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 7 - Solve using REGEXP_REPLACE

# COMMAND ----------

# we have input - 1-A-12-2-B-23-3-C-34-4-D-15, id, name, age, we need to use - as seperator after 3 value i.e 1-A-12 then 2-B-23...

from pyspark.sql.functions import regexp_replace, explode

df = spark.read.text('dbfs:/FileStore/Practice_txt.txt')
df1 = df.withColumn('new_value', regexp_replace("value", "(.*?\\-){3}","$0,")).drop("value")
df2 = df1.withColumn("new_value1", explode(split(df1.new_value, '-,'))).drop("new_value")
df2.show()
# .*= take everything
# regexp_replace function to perform a regular expression-based replacement on the "value" column. The regular expression pattern (.*?\\-){3} matches any sequence of characters followed by a hyphen repeated three times. The replacement string "$0," means that the matched pattern is replaced with itself followed by a comma. So, this effectively adds a comma after every third hyphen in the "value" column.

# df1.withColumn("new_value1", explode(split(df1.new_value, '-,')): This line adds another new column called "new_value1" to the DataFrame df1. It uses the split function to split the "new_value" column using the delimiter "-," and then uses the explode function to transform the resulting array of values into separate rows. This operation essentially splits the "new_value" column into multiple rows, each containing a single value.

# COMMAND ----------

# The regexp_replace function in PySpark is used to replace substrings in a given column based on a regular expression pattern. In the expression regexp_replace("value", "(.*?\\-){3}", "$0,"), it's performing the following operation:

"value": This is the name of the column in which you want to perform the replacement. In this case, you are applying the replacement on a column named "value."

"(.*?\\-){3}": This is the regular expression pattern to match. Let's break down this pattern:

.*?: This part matches any sequence of characters (denoted by .*), and the ? makes it non-greedy, which means it will match as few characters as possible. This is important to match the least number of characters until the next part of the pattern.
\\-: This matches a hyphen ("-"). The double backslash (\\) is used to escape the hyphen because the hyphen has a special meaning in regular expressions.
So, (.*?\\-) matches a sequence of characters followed by a hyphen.

(...){3}: This part surrounds the previous pattern with {3}, which means it should match the sequence of characters followed by a hyphen exactly three times.
"$0,": This is the replacement string. It uses the special reference $0 to refer to the entire matched string, which is the sequence of characters followed by three hyphens. It then appends a comma (",") to the end of the matched string. In other words, it adds a comma after every third hyphen in the "value" column.

So, the entire regexp_replace("value", "(.*?\\-){3}", "$0,") operation replaces every third hyphen in the "value" column with a hyphen followed by a comma. This effectively adds a comma after every third hyphen in the column's values.


# COMMAND ----------

split(df1.new_value, '-,'):

split is a PySpark function used to split a string column into an array of strings based on a delimiter.
df1.new_value is the column you want to split, which is "new_value" from the DataFrame df1.
'-,' is the delimiter you want to use to split the string. In this case, you're splitting the "new_value" column using the delimiter "-," which means the string will be split whenever "-," appears.
So, the split function takes the values in the "new_value" column and splits them into arrays of strings wherever it encounters "-,". The result is an array column.

explode(split(df1.new_value, '-,')):

explode is another PySpark function that is used to explode (unnest) array columns. It takes an array column and returns a new row for each element in the array, effectively creating multiple rows from a single row where each element of the array gets its own row.
In this case, you're applying the explode function to the result of the split function.
So, explode(split(df1.new_value, '-,')) takes the arrays of strings produced by splitting the "new_value" column and "explodes" them into separate rows, with each string element in its own row. This is often used when you have a single column with delimited values and you want to split them into multiple rows to process them individually.


# COMMAND ----------

from pyspark.sql.functions import regexp_replace, explode, split

# Read the text file
df = spark.read.text('dbfs:/FileStore/Practice_txt.txt')

# Split the "value" column into separate columns and drop the original "value" column
df1 = df.withColumn('new_value', regexp_replace("value", "(.*?\\-){3}", "$0,")).drop("value")
df2 = df1.withColumn("new_value1", explode(split(df1.new_value, '-,'))).drop("new_value")

# Create separate columns for "ID," "Name," and "Age"
df3 = df2.withColumn("ID", split(df2.new_value1, '-')[0]).withColumn("Name", split(df2.new_value1, '-')[1]).withColumn("Age", split(df2.new_value1, '-')[2]).drop("new_value1")

# Show the DataFrame
df3.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 8 - Solve Using Pivot and Explode Multiple columns
# MAGIC ##### we want to convert 'Name' column into rows and and 'Country' rows into column?

# COMMAND ----------

l = [(1,'Gaga','India',"2022-01-11"),(1,'Katy','UK', "2022-01-11"),(1,'Bey','Europe', "2022-01-11"),(2,'Gaga',None, "2022-10-11"),(2,'Katy','India', "2022-10-11"),(2,'Bey','US',"2022-02-15"),(3,'Gaga','Europe', "2022-10-11"),
(3,'Katy','US',"2022-10-11"),(3,'Bey',None,"2022-02-15"), (1, 'Gaga','US',"2022-01-11"),(3, 'Katy', 'Switz',"2022-02-15") ]
df = spark.createDataFrame(l,['ID','NAME','COUNTRY', 'Date_part'])
display(df)

# COMMAND ----------

from pyspark.sql.functions import *
df1 = df.groupBy('ID', 'Date_part').pivot('Name').agg(first('COUNTRY'))
df1.show()

# COMMAND ----------

from pyspark.sql.functions import *
df1=df.groupBy('ID','DATE_part').pivot('Name').agg(collect_list('COUNTRY'))
display(df1)

# COMMAND ----------

list_column_explode=df1.columns[2:]
for i in range(len(list_column_explode)):
    list_column_explode[i]="new1."+list_column_explode[i]

# COMMAND ----------

df2=df1.withColumn("new",arrays_zip(*df1.columns[2:])).withColumn("new1",explode("new")).drop("new")
df3=df2.select(*df1.columns[0:2],*list_column_explode)
display(df3)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 9 - Check the Count of Null values in each column?

# COMMAND ----------

data=[(1,'Sagar',23),(2,None,34),(None,None,40),(5,'Alex',None),(4,'Kim',None)]
df=spark.createDataFrame(data,schema="ID int,Name string,Age int")
df.show()

# COMMAND ----------

for i in df.columns:
    print(i)

# COMMAND ----------

from pyspark.sql.functions import col, count
df.select([count(col(i)) for i in df.columns])
    

# COMMAND ----------

from pyspark.sql.functions import col, count, when

df1 = df.select([count(when(col(i).isNull(), i)) for i in df.columns])
df1.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 10 - Solve using regexp_extract method
# MAGIC The **regexp_extract()** function in PySpark is used to extract substrings from a string column based on a regular expression pattern and an index. It returns the substrings that match the pattern based on the index you specify. This function is useful when you want to extract specific parts of a string that match a particular pattern.
# MAGIC
# MAGIC We use **regexp_extract("text", pattern, 1)** to extract the first matching group (index 1) from the "text" column based on the regular expression pattern (\w+), which matches one or more word characters.

# COMMAND ----------

data=[('ABSHFJFJ12QWERT12',1),('QWERT5674OTUT1',2),('DGDGNJDJ1234UYI',3)]
df=spark.createDataFrame(data,schema="input_string string,id int")
df.show()

# COMMAND ----------

from pyspark.sql.functions import regexp_extract
df.select("*").withColumn("new_col", regexp_extract(df.input_string,"(^[a-zA-Z]*([0-9]*))",1)).withColumn("new_col1", regexp_extract(df.input_string,"(^[a-zA-Z]*([0-9]*)([a-zA-Z]*([0-9]*$)",2)).drop("input_string", "id").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 11 - if todays file column name is id, name, and tomorrows file having same schema i.e id, name then it infer the schema from todays file directly 

# COMMAND ----------

# path='/FileStore/tables/csv_with_no_header.csv'
df=spark.read.option('header',True).option('inferschema',True).csv(f'{path}').limit(1)
if(df.schema==schema):
    df.write.mode('overwrite').save('/FileStore/tables/csv_with_header_output/')
else:
    df=spark.read.option('header',False).schema(schema).csv(f'{path}')
    df.write.mode('overwrite').save('/FileStore/tables/csv_with_header_output/')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### What is regexp function in pyspark 
# MAGIC -syntax
# MAGIC ##### from pyspark.sql.functions import regexp_extract
# MAGIC
# MAGIC ###### Using regexp_extract to extract a pattern from a column
# MAGIC new_df = df.withColumn("new_column_name", regexp_extract("column_to_extract_from", "regex_pattern", capture_group_index))
# MAGIC

# COMMAND ----------

In PySpark, the regexp function is used to perform regular expression matching on strings within a DataFrame. It allows you to extract or manipulate strings using regular expressions. Here's a simple example:

Suppose you have a DataFrame named df with a column named "text," and you want to extract all words that start with the letter "A" from that column.

# COMMAND ----------

from pyspark.sql.functions import regexp_extract
import re

# Sample DataFrame
data = [("Apple is a fruit",), ("Banana is not",), ("Cherry is delicious",)]
columns = ["text"]
df = spark.createDataFrame(data, columns)

# Use regexp_extract to extract words starting with "A"
pattern = r'\bA\w+\b'  # Regular expression to match words starting with "A"
result_df = df.select("text", regexp_extract("text", pattern, 0).alias("extracted_word"))

result_df.show()

# In this example, we're using the regexp_extract function to extract words that start with "A" using the regular expression pattern \bA\w+\b. The regular expression pattern \bA\w+\b matches words that start with "A" (\b represents word boundaries, A is the letter "A," and \w+ matches one or more word characters). 

# COMMAND ----------

# MAGIC %md
# MAGIC ##### What is regexp_replace in pyspark
# MAGIC from pyspark.sql.functions import regexp_replace
# MAGIC
# MAGIC Using regexp_replace to replace a pattern with a replacement string.
# MAGIC
# MAGIC new_df = df.withColumn("new_column_name", regexp_replace("column_to_modify", "regex_pattern", "replacement_string"))
# MAGIC

# COMMAND ----------

The regexp_replace function in PySpark is used to replace substrings in a string column using regular expressions. Here's a simple example:

Suppose you have a DataFrame named df with a column named "text," and you want to replace all occurrences of the word "apple" with "orange" in that column.

# COMMAND ----------

from pyspark.sql.functions import regexp_replace

# Sample DataFrame
data = [("I have an apple",), ("She likes apples",), ("He bought an apple",)]
columns = ["text"]
df = spark.createDataFrame(data, columns)
df.show()
# Use regexp_replace to replace "apple" with "orange"
result_df = df.withColumn("modified_text", regexp_replace("text", "apple", "orange"))

result_df.show()

# In this example, we're using the regexp_replace function to replace all occurrences of "apple" with "orange" in the "text" column. 
# The first argument to regexp_replace is the column to be modified, the second argument is the regular expression pattern to match ("apple" in this case), and the third argument is the replacement string ("orange" in this case).

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 12- We have some name in Name column for ex- 1.Gaurav-Kurhekar 2.Vaidehi Kurhekar, in 1st name, we need to remove '-' and take surname in another column?

# COMMAND ----------

data=[(1,"Sagar-Prajapati"),(2,"Alex-John"),(3,"John Cena"),(4,"Kim Joe")]
schema="ID int,Name string"
df=spark.createDataFrame(data,schema)
df.show()

# COMMAND ----------

from pyspark.sql.functions import regexp_replace
df.select("*").withColumn("New_column", regexp_replace('Name', r'(-)', ' ')).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Question 13 - Solve using PySpark and Spark-SQL
# MAGIC Write pyspark query to report a movie with an odd number ID and description that is not "boaring". return the result table in descending order by rating?

# COMMAND ----------

data=[(1, 'War','great 3D',8.9)
,(2, 'Science','fiction',8.5) 
,(3, 'irish','boring',6.2)
,(4, 'Ice song','Fantacy',8.6)  
,(5, 'House card','Interesting',9.1)]    
schema="ID int,movie string,description string,rating double"
df=spark.createDataFrame(data,schema)

# COMMAND ----------

df.show()

# COMMAND ----------

df.createOrReplaceTempView('cinema')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cinema where id %2!=0 and description != 'boring' order by rating desc

# COMMAND ----------

# MAGIC %sql -- solve by using sql
# MAGIC select * from cinema where id%2!=0 and lower(trim(description)) != 'boring' order by rating desc

# COMMAND ----------

# solve by using pyspark
df1 = sql("""select * from cinema where id%2!=0 and lower(trim(description)) != 'boring' order by rating desc """)
display(df1)

# COMMAND ----------

# solve by using pyspark
from pyspark.sql.functions import col, desc, lower, trim
df.select("*").filter((col("ID")%2!=0) & (trim(lower(col("description")))!='boring')).orderBy(col("rating").desc()).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 14 - Solve using PySpark- Collect_list and Aggregation?

# COMMAND ----------

data = [
    ("john", "tomato", 2),
    ("𝚋𝚒𝚕𝚕", "𝚊𝚙𝚙𝚕𝚎", 2),
    ("john", "𝚋𝚊𝚗𝚊𝚗𝚊", 2),
    ("john", "tomato", 3),
    ("𝚋𝚒𝚕𝚕", "𝚝𝚊𝚌𝚘", 2),
    ("𝚋𝚒𝚕𝚕", "𝚊𝚙𝚙𝚕𝚎", 2),
]
schema = "name string,item string,weight int"
df = spark.createDataFrame(data, schema)

# COMMAND ----------

display(df)

# COMMAND ----------

df_final= df.groupBy("name", "item").agg(sum("weight").alias("sum_weight"))
display(df_final)

# COMMAND ----------

df_final = df.groupBy("name", "item").agg(sum("weight").alias("sum_weight"))


# COMMAND ----------

from pyspark.sql.types import IntegerType

df = df.withColumn("weight", df["weight"].cast(IntegerType()))
df_final = df.groupBy("name", "item").agg(sum("weight").alias("sum_weight"))


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 15 - Write a pyspark dataframe query to find all duplicate emails?

# COMMAND ----------

data = [(1, "abc@gmail.com"), (2, "bcd@gmail.com"), (3, "abc@gmail.com")]
schema = "ID int,email string"
df = spark.createDataFrame(data, schema)
df.show()

# COMMAND ----------

df.createOrReplaceTempView('tempo')


# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), email from tempo group by email

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), email from tempo group by email having count(*)>1

# COMMAND ----------

# MAGIC %sql
# MAGIC select email from
# MAGIC (
# MAGIC   select count(*), email from tempo group by email having count(*)>1
# MAGIC )

# COMMAND ----------

# using spark
df2 =spark.sql("""
 select email from
(
  select count(*), email from tempo group by email having count(*)>1
)         
          """)
df2.show()

# COMMAND ----------

# by using pyspark
df3 = df.groupBy("email").count()
display(df3)


# COMMAND ----------

df4 = df.groupBy("email").count().filter(col("count")>1)
df4.show()

# COMMAND ----------

df5 = df.groupBy("email").count().filter(col("count")>1).select("email")
df5.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 16- We have two table called customer and order table, write pyspark df to find all customer who never order anything?

# COMMAND ----------

data=[(1,'Sagar'),(2,'Alex'),(3,'John'),(4,'Kim')]
schema="Customer_ID int, Customer_Name string"
df_customer=spark.createDataFrame(data,schema)

data=[(1,4),(3,2)]
schema="Order_ID int, Customer_ID int"
df_order=spark.createDataFrame(data,schema)

# COMMAND ----------

display(df_customer)

# COMMAND ----------

display(df_order)

# COMMAND ----------

df = df_customer.join(df_order,df_customer.Customer_ID == df_order.Customer_ID, 'left').filter(df_order.Customer_ID.isNull())
display(df)

# COMMAND ----------

df1 = df_customer.join(df_order,df_customer.Customer_ID == df_order.Customer_ID, 'left').filter(df_order.Customer_ID.isNull()).select(df_customer.Customer_Name)
display(df1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 18 - Write pyspark query for report that provides customer id from customer table that bought all product in product table?

# COMMAND ----------

data=[(1,5),(2,6),(3,5),(3,6),(1,6)]
schema="customer_id int,product_key int"
customer_df=spark.createDataFrame(data,schema)


data=[(5,),(6,)]
schema="product_key int"
product_df=spark.createDataFrame(data,schema)

# COMMAND ----------

display(customer_df)

# COMMAND ----------

display(product_df)

# COMMAND ----------

from pyspark.sql.functions import countDistinct, col
df = product_df.agg(countDistinct(col("product_key"))).alias("count_product")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 19 - Get employee, department id with maximum and minimum salary in each department?

# COMMAND ----------

data=[('Genece' , 2 , 75000),
('𝗝𝗮𝗶𝗺𝗶𝗻' , 2 , 80000 ),
('𝗣𝗮𝗻𝗸𝗮𝗷' , 2 , 80000 ),
('Tarvares' , 2 , 70000),
('Marlania' , 4 , 70000),
('Briana' , 4 , 85000),
('𝗞𝗶𝗺𝗯𝗲𝗿𝗹𝗶' , 4 , 55000),
('𝗚𝗮𝗯𝗿𝗶𝗲𝗹𝗹𝗮' , 4 , 55000),  
('Lakken', 5, 60000),
('Latoynia' , 5 , 65000) ]
schema="emp_name string,dept_id int,salary int"
df=spark.createDataFrame(data,schema)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import max, min
df1 = df.groupBy("dept_id").agg(max("salary").alias("max_sal"),min("salary").alias("min_sal")).withColumnRenamed("dept_id", "dept_id1")
display(df1)

# COMMAND ----------

df2 = df.join(df1, df.dept_id == df1.dept_id1, 'inner')
display(df2)

# COMMAND ----------

from pyspark.sql.functions import *
df3 = df2.filter((col("max_sal")== col("salary")) | (col("min_sal") == col("salary")))
df3.groupBy("dept_id", "salary").agg(collect_set("emp_name")).alias("employee_name")
display(df3)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 20 - Cache and Persist DataFrame PySpark Interview Question?

# COMMAND ----------

data = [("Raj","Doe",None),
 (None,"Samuel","VIZAG"),
 ("David","Smith", None),
 ("Samson",None, "HYD"),
 ("Immi", "Steve", "BNG"),
 (None, None, None)]

columns = ["Firstname", "Lastname", "City"]

df = spark.createDataFrame(data,columns)
df.cache()

# COMMAND ----------

from pyspark.sql.functions import *
for i in df.columns:
    total_count = df.select(col(i)).count()
    null_values = df.filter(col(i).isNull()).count()
    percentage = (null_values/total_count)*100
    print(i, percentage)