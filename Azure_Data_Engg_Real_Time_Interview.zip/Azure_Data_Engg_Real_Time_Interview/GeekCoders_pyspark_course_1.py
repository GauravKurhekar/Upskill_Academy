# Databricks notebook source
# GeekCoders login id – gauravkurhekar04@gmail.com
# Pass - *Kurhekar@04


# COMMAND ----------

# MAGIC %fs head dbfs:/FileStore/demo_4.csv

# COMMAND ----------

# MAGIC %md
# MAGIC ##### # Question 1 - Why manual schema is faster than infer schema? How to optimize csv file read process?

# COMMAND ----------

df = spark.read.format("csv").option("Inferschema", True).option("Header", True).load('dbfs:/FileStore/demo_4.csv')
df.show()

# Note- if by default we make Inferschema as 'False' then all the datatypes will consider as 'string'.

# COMMAND ----------

# create our own schema, it takes only 1.58 sec while if we inferschema then it takes 6 seconds
from pyspark.sql.types import StructType, StructField, IntegerType, StringType
schema = StructType([StructField('ID', IntegerType()),\
                    StructField('Name', StringType()),\
                    StructField('Age', IntegerType())])
df1 = spark.read.format("csv").schema(schema).option("Header", True).load('dbfs:/FileStore/demo_4.csv')
df1.show()

# COMMAND ----------

# Infer Schema True - spark will read file twice while loading and while reading file entirely 
# define schema manually - spark will read file only once while loading with .load method

# COMMAND ----------

# MAGIC %md
# MAGIC ##### # Question 2- how to handle corrupt and bad records in pyspark?

# COMMAND ----------

# Three types of read mode available in pyspark
1- Permissive Mode (permissive):

In permissive mode, PySpark will attempt to read the data from the source even if it doesn't fully comply with the specified schema.
When using permissive mode, PySpark will accept malformed records (i.e., records that don't match the schema) and load them as null values or string representations of the entire record.
This mode is helpful when you have noisy data with occasional schema violations, and you want to read as much data as possible.

2-Drop Malformed Records (dropmalformed):
When you set the dropmalformed option to true, PySpark will skip or drop any records that don't match the specified schema.
This option is useful when you want to load only records that fully conform to the schema and ignore any malformed or problematic records.

3- Fail Fast (failfast):
In "failfast" mode, PySpark will immediately throw an exception and fail the job if it encounters any records that do not match the specified schema.
This mode is useful when you want to ensure that your data strictly adheres to the schema, and any deviation should be treated as an error.

"PERMISSIVE" will load all data, including malformed records as null or string representations.
"DROPMALFORMED" will load only well-formed records and drop the rest.
"FAILFAST" will throw an exception and stop processing if any malformed record is encountered.

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType
schema = StructType([StructField('ID', IntegerType()),\
                    StructField('Name', IntegerType()),\
                    StructField('Age', IntegerType()),\
                    StructField('_corrupt_record', StringType())
                    ])
df1 = spark.read.format("csv").schema(schema).option("Header", True).option('mode', 'Permissive').load('dbfs:/FileStore/demo_4.csv')
df1.show()

# COMMAND ----------

df1.createOrReplaceTempView("test")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from test

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 3 - How to load the .csv or .txt file using dynamic delimiter or different delimiter?

# COMMAND ----------

# daily you are receiving txt/csv file with headers and you have to read and save into delta lake
# challenge is delimeter/separator can be changed any day(its not static) then how to write your code?
# 1- in delimiter_1.txt- we have | as separator, 2- delimiter_2.txt- , is separator, 3 - in delimiter_3.txt- ; is separator 

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/FileStore/delimiter_1.txt

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/FileStore/delimiter_2.txt

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/FileStore/delimiter_3.txt

# COMMAND ----------

df = spark.read.format("csv").option("Header", True).option("sep", "|").load("dbfs:/FileStore/delimiter_1.txt")
df.show()

# COMMAND ----------

import re
def f_get_delimiter(input_file):
    try:
        df = sc.textFile(f'{input_file}').take(1)
        df_header = ''.join(df)
        get_delimiter = re.search("(,|;|\\|)",df_header)
        return get_delimiter.group()
    except exception as err:
        print("Error occured", str(err))

# COMMAND ----------

sep = f_get_delimiter("dbfs:/FileStore/delimiter_1.txt")
df = spark.read.format("csv").option("Header", True).option("sep", sep).load("dbfs:/FileStore/delimiter_1.txt")
df.write.format("delta").save("dbfs:/FileStore/delimiter_output.txt")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`dbfs:/FileStore/delimiter_output.txt`

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 4 - How to optimize pyspark UDF?

# COMMAND ----------

# 1- create python function
# 2- convert python function into pyspark UDF
# 3 - use pyspark UDF

# python/pyspark UDF are slower as it will executes on only one driver nodes, it doesnt work on distributed fashion and sometimes gets OOM issue
# alternatively we can use pandas UDF with Arrow enabled. Arrow is memory computition.

# COMMAND ----------

# MAGIC %fs head dbfs:/FileStore/demo_4.csv

# COMMAND ----------

def convert_to_upper(str_input):
    return str_input.upper()

# COMMAND ----------

from pyspark.sql.functions import col, udf
convert_to_upper_udf = udf(lambda x:convert_to_upper(x))

# COMMAND ----------

# this is user define function UDF to make string as upper
df = spark.read.format("csv").option("Header", True).load('dbfs:/FileStore/demo_4.csv')
df.select("ID", convert_to_upper_udf(col("Name")).alias("NewUpperName"), "Age")

# COMMAND ----------

# by using inbuild function will take much small amount of time- 2.60 sec, udf tooks 9.30 seconds
from pyspark.sql.functions import upper
df1 = spark.read.format("csv").option("Header", True).load('dbfs:/FileStore/demo_4.csv')
df1.select("ID", upper("Name"), "Age").show()

# COMMAND ----------

# to optimized UDF , we have to enable the Arrow which help the execution happened in memory
spark.conf.set('spark.databricks.executions.pythonUDF.arrow.enabled', True)

# COMMAND ----------

# after enabling Arrow, this time it tooks only 1.25 second for execution
df = spark.read.format("csv").option("Header", True).load('dbfs:/FileStore/demo_4.csv')
df.select("ID", convert_to_upper_udf(col("Name")).alias("NewUpperName"), "Age")

# COMMAND ----------

# We can also enable Arrow in pandas library
@pandas_udf(StringType())
def to_upper(s:pd.Series)->pd.Series:
    return s.str.upper()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 5 - Read .csv from file location and change the state name with respective full name, mapping list is given?

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/FileStore/demo_broadcast.csv

# COMMAND ----------

from pyspark.sql.functions import col, when

# Read the CSV file
df = spark.read.csv("dbfs:/FileStore/demo_broadcast.csv", header=True)

# Define a dictionary to map abbreviated state names to full names
state_mapping = {
    "UP": "Uttar Pradesh",
    "MH": "Maharashtra",
    "GJ": "Gujarat",
    "DL": "Delhi"
}

# Use the 'when' function to update the 'State' column based on the mapping
df = df.withColumn("State", when(col("State") == "UP", "Uttar Pradesh")
                             .when(col("State") == "MH", "Maharashtra")
                             .when(col("State") == "GJ", "Gujarat")
                             .when(col("State") == "DL", "Delhi")
                             .otherwise(col("State")))

# Show the updated DataFrame
df.show()

state_mapping = {
    "MH":"Maharashtra",
    "UP":"Utter Pradesh",
    "DL":"Delhi"
}

# OR
df = df.withColumn("State", when(df["State"].isin(state_mapping.keys()), state_mapping[df["State"]]).otherwise(df["State"]))

# COMMAND ----------

df3 = spark.read.format("csv").option("Header", True).load("dbfs:/FileStore/demo_broadcast.csv")

# COMMAND ----------

mapping_state = {
    "TN":"Tamil Nadu",
    "UP":"Utter Pradesh",
    "GJ":"Gujrat"
}

# COMMAND ----------

def f_mapping_state(str_input):
    return mapping_state[str_input]

# COMMAND ----------

from pyspark.sql.functions import udf, col
f_mapping_state_udf = udf(lambda x: f_mapping_state(x))

# COMMAND ----------

df_output = df3.select("ID", "Name", "Age", f_mapping_state_udf(col("state")))


# COMMAND ----------

display(df_output)

# COMMAND ----------

# Broadcast variable - 
In PySpark, a broadcast variable is a read-only variable that can be efficiently shared across multiple nodes in a distributed cluster. It is used to cache a value or data on each node, making it accessible for tasks running on those nodes without the need to transfer the data over the network repeatedly. 
Broadcast variables are particularly useful when working with large datasets or shared data that can be reused across multiple stages of a Spark application.

The primary use case for broadcast variables is to optimize the performance of operations that involve a small dataset or lookup data used in a distributed computation. Instead of sending the same data to all worker nodes for each task, you can broadcast the data once and have it available locally on each node, reducing data transfer and improving performance.

Here's how you can create and use a broadcast variable in PySpark:

Creating a Broadcast Variable:
You can create a broadcast variable by calling the SparkContext.broadcast() method and passing the data you want to broadcast as an argument. For example:


sc = SparkContext("local", "broadcast_example")
data_to_broadcast = [1, 2, 3, 4]
broadcast_var = sc.broadcast(data_to_broadcast)
Using a Broadcast Variable:
Once a broadcast variable is created, you can use it within your Spark transformations and actions. The data will be available locally on each worker node, improving performance. For example:

rdd = sc.parallelize([5, 6, 7, 8])
result = rdd.map(lambda x: x * broadcast_var.value).collect()
In this example, the broadcast_var.value attribute provides access to the broadcasted data.

Cleaning up Broadcast Variables:
It's essential to clean up broadcast variables when you no longer need them to free up resources. You can do this by calling the unpersist() method:

broadcast_var.unpersist()
Broadcast variables are particularly helpful when working with lookup tables, reference data, or any small dataset that is reused across tasks in a Spark job, reducing the need for redundant data transfers and improving performance.


# COMMAND ----------

# broadcase variable present in driver node has been sent to all worker nodes in worker nodes cache memory , this has been caches only one time
# we already send the data to worker nodes thats why, it wont take much time to process the same thing again.

# COMMAND ----------

mapping_state = {
    "TN":"Tamil Nadu",
    "UP":"Utter Pradesh",
    "GJ":"Gujrat"
}

# COMMAND ----------

from pyspark.sql.functions import udf, col, broadcast
broadcast_mapping_state = sc.broadcast(mapping_state)
def f_mapping_state_udf_broadcast(str_input):
    return broadcast_mapping_state.values[str_input]

# COMMAND ----------

f_mapping_state_udf_broadcast_udf = udf(f_mapping_state_udf_broadcast)

# COMMAND ----------

df_output1 = df3.select("ID", "Name", "Age", f_mapping_state_udf(col("state")))
display(df_output1)

# COMMAND ----------

# caching means saving the data
# unpersist means release the memory
# destroy will delete the variable from cache memory
# broadcast variable and broadcast join concepts are same, in join we are joining bigger table with smaller one.


# COMMAND ----------

broadcast_mapping_state.unpersist()

# COMMAND ----------

broadcast_mapping_state.destroy()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Question 6 incremental load

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 6 - How to incremental and full load in pyspark SQL?

# COMMAND ----------

# Read data incrementally and save into delta locaion.

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/FileStore/incremental_30_10_23.csv

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/FileStore/incremental_31_10_23.csv

# COMMAND ----------

# Yesterdays data
df = spark.read.format("csv").option("inferschema", True).option("Header",True).load("dbfs:/FileStore/incremental_30_10_23.csv")
df.show()

# COMMAND ----------

# Todays data
df1 = spark.read.format("csv").option("inferschema", True).option("Header",True).load("dbfs:/FileStore/incremental_31_10_23.csv")
df1.show()

# COMMAND ----------

# overwriting the data by using 'overwrite' method called 'Full Load' method
df.write.mode("overwrite").save("dbfs:/FileStor/incremental_modify")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`dbfs:/FileStor/incremental_modify`

# COMMAND ----------

# by using overwrite method, we can modify the data but it is costly operation which is not suitable for bigger data set, here incremental data came into picture

# COMMAND ----------

# MAGIC %md
# MAGIC ####Incremental load logic

# COMMAND ----------

# Step1 - create a table in sql and save into delta locaion
spark.sql("""
          create table if not exists student_incremental
          (
          ID int,
          Name String,
          Age int,
          Ingest_time timestamp 
          )using delta
          location "dbfs:/FileStore/incremental_modify"

          """)

# COMMAND ----------

# Step 2 - create temporary view for 30_10_23 file 
from pyspark.sql.functions import current_timestamp
df3 = spark.read.format("csv").option("inferschema", True).option("Header",True).load("dbfs:/FileStore/incremental_30_10_23.csv").withColumn("Ingest_time", current_timestamp())
df3.createOrReplaceTempView("student_stage")

# COMMAND ----------

# now we have main table and stging table, 
# student_incremental - main table/target table, in main table, we need to update/save the data
# student_state - staging table or source table

# COMMAND ----------

# step 3 - merge two table i.e student_incremental with student_state for file 30_10_23, later will merge the file 31_10_23
# whenever we are doing incremental load, we should know the primary key or perticular column or dataset

spark.sql("""
          merge into student_incremental a using student_stage b on a.id = b.id
          when matched then update set a.Name = b.name, a.Age = b.Age
          when not matched then insert *
          
          """)

# COMMAND ----------

# MAGIC %sql  -- to check if data is loaded or not
# MAGIC select * from student_incremental

# COMMAND ----------

# step 4 - Again create temporary view for 31_10_23 file which we have alread done in step 2 but this time we are doing for 31st file

from pyspark.sql.functions import current_timestamp
df3 = spark.read.format("csv").option("inferschema", True).option("Header",True).load("dbfs:/FileStore/incremental_31_10_23.csv").withColumn("Ingest_time", current_timestamp())
df3.createOrReplaceTempView("student_stage")

# COMMAND ----------

# Step 5 - merge the files 
spark.sql("""
          merge into student_incremental a using student_stage b on a.id = b.id
          when matched and (a.Name <> b.Name or a.Age <> b.Age)
          then update set a.Name = b.Name, a.Age = b.Age, a.Ingest_time = b.Ingest_time
          when not matched then insert *
          
          """)

# COMMAND ----------

# MAGIC %sql  -- to check if data is loaded or not - data is successfully loaded
# MAGIC select * from student_incremental

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Bing solution for incremental load
# MAGIC

# COMMAND ----------

To perform incremental data loading in PySpark, you can use the Delta Lake library. 
Delta Lake is an open-source storage layer that brings reliability to data lakes. 
It provides ACID transactions, scalable metadata handling, and unifies streaming and batch data processing. Here is a simple code snippet that demonstrates how to perform incremental data loading using Delta Lake:

# COMMAND ----------

# Define the path of the Delta table
delta_path = "dbfs:/FileStore/incremental_30_10_23.csv"

# Read the Delta table into a PySpark DataFrame
df = spark.read.format("delta").load("dbfs:/FileStore/incremental_30_10_23.csv")

# Define the path of the CSV file that contains new data
csv_path = "dbfs:/FileStore/incremental_31_10_23.csv"

# Read the new data into a PySpark DataFrame
new_data = spark.read.option("header", True).option("delimiter", "\t").csv("dbfs:/FileStore/incremental_31_10_23.csv")

# Write the new data to the Delta table using merge
df.write.format("delta").mode("append").merge(new_data, "ID").execute()


# COMMAND ----------


# Define the path of the Delta table
delta_path = "dbfs:/FileStore/incremental_30_10_23.csv"

# Read the existing Delta table into a PySpark DataFrame
df = spark.read.format("delta").load(delta_path)

# Define the path of the CSV file that contains new data
csv_path = "dbfs:/FileStore/incremental_31_10_23.csv"

# Read the new data from the CSV file into a PySpark DataFrame
new_data = spark.read.option("header", True).option("delimiter", "\t").csv(csv_path)

# Write the new data to the Delta table using merge
from pyspark.sql.delta import DeltaTable

delta_table = DeltaTable.forPath(spark, delta_path)
delta_table.alias("existing").merge(
    new_data.alias("updates"),
    "existing.ID = updates.ID"
).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()


# COMMAND ----------

# MAGIC %md
# MAGIC #### chatgpt solution for incremental data load

# COMMAND ----------

Read the existing dataset.
Read the new data to be added.
Identify the unique key (or a combination of keys) in your data that can be used to determine whether a record already exists in the existing dataset.
Perform a left anti-join to identify the records in the new data that do not exist in the existing dataset based on the unique key(s).
Append the new records to the existing dataset.

# COMMAND ----------


# Read the existing dataset
existing_data = spark.read.csv("dbfs:/FileStore/incremental_30_10_23.csv", header=True, inferSchema=True)

# Read the new data received today
new_data = spark.read.csv("dbfs:/FileStore/incremental_31_10_23.csv", header=True, inferSchema=True)

# Identify the unique key column ("ID") to identify existing records
unique_key = "ID"

# Find new records (left anti-join)
new_records = new_data.join(existing_data, unique_key, "left_anti")

# Find records to update (left semi-join)
records_to_update = new_data.join(existing_data, unique_key, "left_semi")

# Append new records to the existing dataset
new_records.write.mode("append").csv("dbfs:/FileStore/incremental_update_mocify.csv", header=True)

# Update existing records with new data
existing_data = existing_data.join(records_to_update, unique_key, "left_outer")
existing_data = existing_data.fillna(new_data, subset=["Name", "Age"])

# Save the updated dataset
existing_data.write.mode("overwrite").csv("dbfs:/FileStore/incremental_update_mocify.csv", header=True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Google Solution

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1. Read the CSV files into Spark DataFrames

# COMMAND ----------

import pyspark.sql.functions as F

# Read the yesterday's CSV file into a DataFrame
df_yesterday = spark.read.csv('dbfs:/FileStore/incremental_30_10_23.csv', header=True)

# Read the today's CSV file into a DataFrame
df_today = spark.read.csv('dbfs:/FileStore/incremental_31_10_23.csv', header=True)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2. Identify the new records

# COMMAND ----------

# Identify the new records in today's DataFrame by filtering out the records that are already present in yesterday's DataFrame
new_records = df_today.filter(~df_today['ID'].isin(df_yesterday['ID']))


# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3. Merge the new records with the existing data

# COMMAND ----------

# Merge the new records with the existing data in yesterday's DataFrame
updated_df = df_yesterday.union(new_records)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4. Write the updated DataFrame to a new CSV file

# COMMAND ----------

# Write the updated DataFrame to a new CSV file
updated_df.write.csv('dbfs:/FileStore/incremental_update_modify_google.csv', header=True)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### complete code

# COMMAND ----------

from pyspark.sql import SparkSession

# Create a SparkSession
spark = SparkSession.builder.appName('Incremental Load').getOrCreate()

# Read the CSV files into Spark DataFrames
df_yesterday = spark.read.csv('yesterday.csv', header=True)
df_today = spark.read.csv('today.csv', header=True)

# Identify the new records
new_records = df_today.filter(~df_today['ID'].isin(df_yesterday['ID']))

# Merge the new records with the existing data
updated_df = df_yesterday.union(new_records)

# Write the updated DataFrame to a new CSV file
updated_df.write.csv('updated.csv', header=True)

# Stop the SparkSession
spark.stop()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### incremental load using merge function

# COMMAND ----------

there is another simple approach to incremental load in PySpark using the merge function. The merge function allows you to join two DataFrames and specify how to handle updates and inserts. Here's an example of how to use the merge function for incremental load:

# COMMAND ----------

# Read the CSV files into Spark DataFrames
df_yesterday = spark.read.csv('dbfs:/FileStore/incremental_30_10_23.csv', header=True)
df_today = spark.read.csv('dbfs:/FileStore/incremental_31_10_23.csv', header=True)

# Merge the DataFrames using 'ID' as the key column
updated_df = df_yesterday.merge(df_today, on='ID', how='outer')

# Fill in missing values with existing data
updated_df = updated_df.fillna(df_yesterday)

# Write the updated DataFrame to a new CSV file
updated_df.write.csv('dbfs:/FileStore/incremental_merge.csv', header=True)

# COMMAND ----------

This code will merge the two DataFrames using 'ID' as the key column, fill in missing values with existing data, and write the updated DataFrame to a new CSV file.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### incremental load using delta table
# MAGIC

# COMMAND ----------

Delta is a storage format that enables scalable, reliable, and fast data processing. It provides a number of features that make it ideal for incremental load, such as:

Transactional consistency: Delta provides transactional consistency, which means that your data is always in a consistent state, even if there are multiple concurrent writers.
Schema evolution: Delta supports schema evolution, which means that you can change the schema of your data without having to recreate the entire table.
Versioning: Delta keeps track of all changes to your data, which means that you can easily revert to a previous version if necessary.
To use Delta for incremental load, you can follow these steps:

1- Create a Delta table to store your data.
2- Write the new data to the Delta table using the append mode.
3- Compaction: Delta periodically compacts the data to improve performance.
4- Query the Delta table to read the updated data.

# COMMAND ----------


# Create a Delta table to store the data
spark.sql('CREATE TABLE IF NOT EXISTS my_delta_table (ID INT, Name STRING, Age INT) USING delta')

# Write the new data to the Delta table using the `append` mode
spark.read.csv('today.csv', header=True).write.format('delta').mode('append').saveIntoTable('my_delta_table')

# Query the Delta table to read the updated data
updated_data = spark.sql('SELECT * FROM my_delta_table')
