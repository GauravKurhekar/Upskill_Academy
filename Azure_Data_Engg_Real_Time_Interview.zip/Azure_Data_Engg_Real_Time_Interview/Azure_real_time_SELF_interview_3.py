# Databricks notebook source
# MAGIC %md
# MAGIC ##### Question 65- How to start spark session?
# MAGIC
# MAGIC

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
spark = SparkSession.builder.appName('Example').getOrCreate()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 66- There is parquet file stored in data lake, 
# MAGIC * 1-write pyspark code to read this file and write the data frame,  
# MAGIC * 2- then write code to remove duplicate records, 
# MAGIC * 3- write back data frame back to data lake

# COMMAND ----------

# Read Parquet file into DataFrame
parquet_file_path = "path/to/your/parquet_file.parquet"
df = spark.read.parquet(parquet_file_path)

# Display DataFrame schema and sample records
df.printSchema()
df.show(5)

# Remove duplicate records
df_no_duplicates = df.dropDuplicates()

# Write DataFrame back to Data Lake as Parquet file
output_parquet_path = "path/to/your/output_directory"
df_no_duplicates.write.mode("overwrite").parquet(output_parquet_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 66- We have below table, write df to group two columns and use collect_list function on third column(see output to check what is requirement)?

# COMMAND ----------

# Define data
data = [("a", "aa", 1),
        ("a", "aa", 2),
        ("b", "bb", 5),
        ("b", "bb", 3),
        ("b", "bb", 4)]
schema = ['col1', 'col2', 'col3']
# Create DataFrame
df5 = spark.createDataFrame(data, schema=schema)
df5.show()
display(df5)

# COMMAND ----------

from pyspark.sql.functions import collect_list
df_group = df.groupBy('col1', 'col2').agg(collect_list('col3')).alias('col3')
df_group.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Solve using spark sql

# COMMAND ----------

df5.createOrReplaceTempview('collect_lst')
result =spark.sql("""
                  select col1, col2, collect_list(col3) as col3 group by col1, col2
                  """)
result.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 67- We have json file having complex data, read this json file using explode function
# MAGIC * {'dept_id': 101, 'e_id':[10101, 10102,10103]}
# MAGIC * {'dept_id': 102, 'e_id':[10201, 10202]}

# COMMAND ----------

# JSON data
json_data = [
    {'dept_id': 101, 'e_id': [10101, 10102, 10103]},
    {'dept_id': 102, 'e_id': [10201, 10202]}
]

# Read JSON data into DataFrame
df = spark.read.json(spark.sparkContext.parallelize(json_data))

# Show DataFrame
df.show(truncate=False)

# COMMAND ----------

from pyspark.sql.functions import explode
# Explode the e_id array and select as emp_id
df = df.selectExpr('dept_id', 'explode(e_id) as emp_id')

# Show DataFrame
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 68- We have below data frame created, write a code to
# MAGIC * 1- To create data frame in pyspark
# MAGIC * 2- Find avg stock value on daily basis for each stock
# MAGIC * 3- Find max avg stock value of each stock

# COMMAND ----------

data = [('2023-01-01', 'APPLE', 150.00), ('2023-01-02', 'APPLE', 200.00), ('2023-01-01', 'GOOGLE', 2300.00), ('2023-01-02', 'GOOGLE', 2500.00), ('2023-01-01', 'MSFT', 300.00), ('2023-01-02', 'MSFT', 500.00)]
schema = ['date','stock', 'value']
df_stock = spark.createDataFrame(data, schema)
df_stock.show()

# COMMAND ----------

from pyspark.sql.functions import to_date, avg, max

# Assuming df_stock is your DataFrame containing stock data

# 1. Convert the date column to DateType
df_date = df_stock.withColumn('Date', to_date('date'))

# 2. Find the average stock value on a daily basis for each stock
df_avg = df_date.groupBy('Date', 'stock').agg(avg('value').alias('avg_val'))

# 3. Find the max average stock value of each stock
df_max = df_avg.groupBy('stock').agg(max('avg_val').alias('max_avg_val'))
df_max.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 69- Find the duplicate records from Emp_table and delete the duplicate records using window function?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE dup_table1 (
# MAGIC     Name VARCHAR(100)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO dup_table1 (Name) VALUES
# MAGIC ('Gaurav'),
# MAGIC ('Vaidehi'),
# MAGIC ('Gaurav'),
# MAGIC ('Monu'),
# MAGIC ('Gaurav');
# MAGIC select * from dup_table1;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC WITH CTE AS (
# MAGIC     SELECT 
# MAGIC         Name,
# MAGIC         ROW_NUMBER() OVER (PARTITION BY Name ORDER BY Name) AS dup_record
# MAGIC     FROM 
# MAGIC         dup_table1
# MAGIC )
# MAGIC DELETE FROM CTE
# MAGIC WHERE dup_record > 1;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 70- We have input table given below? Find product name whose price is consistently increasing than previous price, other products price is not consistently increasing?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE capgi_table (
# MAGIC     Month VARCHAR(20),
# MAGIC     Item VARCHAR(20),
# MAGIC     Price INT
# MAGIC );
# MAGIC
# MAGIC INSERT INTO capgi_table (Month, Item, Price) VALUES
# MAGIC ('Jan', 'Bread', 10),
# MAGIC ('Feb', 'Bread', 12),
# MAGIC ('March', 'Bread', 12),
# MAGIC ('Jan', 'Milk', 60),
# MAGIC ('Feb', 'Milk', 70),
# MAGIC ('March', 'Milk', 80),
# MAGIC ('Jan', 'Cheese', 60),
# MAGIC ('Feb', 'Cheese', 65),
# MAGIC ('March', 'Cheese', 65);
# MAGIC
# MAGIC select * from capgi_table;

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH ItemPrices AS (
# MAGIC     SELECT
# MAGIC         Month,
# MAGIC         Item,
# MAGIC         Price,
# MAGIC         LAG(Price) OVER (PARTITION BY Item ORDER BY Month) AS PrevPrice
# MAGIC     FROM capgi_table
# MAGIC )
# MAGIC SELECT Month, Item, Price
# MAGIC FROM ItemPrices
# MAGIC WHERE Price > PrevPrice
# MAGIC ORDER BY Month;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 71- We have TableA and TableB, how we can find duplicate?
# MAGIC * We can find duplicate using Intersect method

# COMMAND ----------

SELECT column1
FROM tableA
INTERSECT
SELECT column1
FROM tableB;


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 72- How to remove duplicates?
# MAGIC * 1- By using distinct
# MAGIC * 2- By using count(*) and having clause
# MAGIC * 3- By using window_function with help of CTE

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists Duplicates;
# MAGIC CREATE TABLE if not exists Duplicates (
# MAGIC     ID INT,
# MAGIC     Name VARCHAR(50)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (1,'Apple');
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (2,'Banana');
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (3,'Cherry');
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (4,'Apple');
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (5,'Grape');
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (6,'Orange');
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (7,'Apple');
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (8,'Strawberry');
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (9,'Grape');
# MAGIC INSERT INTO Duplicates (ID, Name) VALUES (10,'Apple');
# MAGIC
# MAGIC SELECT * FROM Duplicates;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Method 1 - By using distinct

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct Name from Duplicates;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### By using count(*) and having clause

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC SELECT Name, COUNT(Name) AS duplicate_name
# MAGIC FROM Duplicates
# MAGIC GROUP BY Name
# MAGIC HAVING COUNT(Name) > 1;
# MAGIC
# MAGIC --OR 
# MAGIC select Name, count(*) as duplicate_name from Duplicates 
# MAGIC group by Name
# MAGIC having count(*)>1;
# MAGIC
# MAGIC -- the COUNT(*) function is used to count the number of rows in a result set or the number of records.
# MAGIC --regardless of whether they contain null values. It counts every row, including those where all columns are null.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3- By using window_function with help of CTE

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC WITH cte AS (
# MAGIC     SELECT Name, ROW_NUMBER() OVER (PARTITION BY Name ORDER BY Name) AS duplicate_name 
# MAGIC     FROM Duplicates
# MAGIC )
# MAGIC DELETE FROM cte WHERE duplicate_name > 1;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 73- We have table called emp_pivot(eno int identity(1,1),City varchar(90),year varchar(90),sales money)
# MAGIC #####expected Result
# MAGIC * City,2022,2023
# MAGIC * Hyd,1000,1000
# MAGIC * Bang,3000,2000
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE emp_pivot (
# MAGIC     eno INT,
# MAGIC     City VARCHAR(90),
# MAGIC     year VARCHAR(90),
# MAGIC     sales INT
# MAGIC );
# MAGIC
# MAGIC INSERT INTO emp_pivot VALUES
# MAGIC     (1, 'hyd', '2022', 1000),
# MAGIC     (2, 'hyd', '2023', 1000),
# MAGIC     (3, 'Bang', '2022', 3000),
# MAGIC     (4, 'Bang', '2023', 2000);
# MAGIC
# MAGIC SELECT * FROM emp_pivot;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     City,
# MAGIC     MAX(CASE WHEN Year = '2022' THEN Sales END) AS [2022],
# MAGIC     MAX(CASE WHEN Year = '2023' THEN Sales END) AS [2023]
# MAGIC FROM 
# MAGIC     emp_pivot
# MAGIC GROUP BY 
# MAGIC     City;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 74- Pivot the tables for converting column to rows using pivot table?

# COMMAND ----------


from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Define schema
schema = StructType([
    StructField("product", StringType(), True),
    StructField("amount", IntegerType(), True),
    StructField("country", StringType(), True)
])

# Define data
data = [("banana", 1000, "USA"),
        ("carrot", 1500, "USA"),
        ("banana", 400, "China")]

# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show DataFrame
df.show()


# COMMAND ----------

new_df=df.groupby("product").pivot(" country").agg(SUM("amount"))

Display(new_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 75- Convert the gender from Male to Female and vice versa?
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create table emp_gender(empid int,ename varchar(90),gender varchar(90));
# MAGIC insert into emp_gender values(1,'Ram','Male'),(2,'radha','Female');
# MAGIC select * from emp_gender;

# COMMAND ----------

# MAGIC %sql
# MAGIC     UPDATE emp_gender 
# MAGIC SET gender = 
# MAGIC     CASE 
# MAGIC         WHEN gender = 'Male' THEN 'Female'
# MAGIC         WHEN gender = 'Female' THEN 'Male'
# MAGIC         ELSE gender  -- Handle any other cases here
# MAGIC     END;
# MAGIC     select * FROM emp_gender;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 76- Write a query to find the percentage of people who will vote for BJP in each city and state?
# MAGIC * formula = city, state *100 /total_population

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists tbl1;
# MAGIC CREATE TABLE tbl1 (
# MAGIC     Name VARCHAR(100),
# MAGIC     DOB DATE,
# MAGIC     City VARCHAR(50),
# MAGIC     State VARCHAR(50),
# MAGIC     Party VARCHAR(20)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO tbl1 (Name, DOB, City, State, Party)
# MAGIC VALUES
# MAGIC     ('John Doe', '1990-05-15', 'Delhi', 'Delhi', 'BJP'),
# MAGIC     ('Jane Smith', '1985-08-20', 'Mumbai', 'Maharashtra', 'AAP'),
# MAGIC     ('Alice Brown', '1978-03-10', 'Chennai', 'Tamil Nadu', 'Congress'),
# MAGIC     ('Bob Johnson', '1982-11-05', 'Kolkata', 'West Bengal', 'NCP');
# MAGIC
# MAGIC drop table if exists tbl2;
# MAGIC CREATE TABLE tbl2 (
# MAGIC     City VARCHAR(50),
# MAGIC     State VARCHAR(50),
# MAGIC     Total_Population_of_City INT
# MAGIC );
# MAGIC
# MAGIC INSERT INTO tbl2 (City, State, Total_Population_of_City)
# MAGIC VALUES
# MAGIC     ('Delhi', 'Delhi', 2000000),
# MAGIC     ('Mumbai', 'Maharashtra', 3000000),
# MAGIC     ('Chennai', 'Tamil Nadu', 1500000),
# MAGIC     ('Kolkata', 'West Bengal', 1800000);
# MAGIC   select * from tbl1;
# MAGIC   select * from tbl2;

# COMMAND ----------

# MAGIC %sql
# MAGIC   select * from tbl1;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     t1.city,
# MAGIC     t1.state,
# MAGIC     (COUNT(CASE WHEN t1.party = 'bjp' THEN 1 else 0 END) * 100.0 / t2.total_population_of_city) AS bjp_vote_percentage
# MAGIC FROM
# MAGIC     tbl1 t1
# MAGIC JOIN
# MAGIC     tbl2 t2 ON t1.city = t2.city AND t1.state = t2.state
# MAGIC GROUP BY
# MAGIC     t1.city,
# MAGIC     t1.state,
# MAGIC     t2.total_population_of_city;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 77- Write query to find all the girls who’s age in between 18 to 20 from hyd city?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create table tbl_gender
# MAGIC CREATE TABLE tbl_gender (
# MAGIC     Name VARCHAR(50),
# MAGIC     DOB DATE,
# MAGIC     city VARCHAR(50),
# MAGIC     gender VARCHAR(10),
# MAGIC     state VARCHAR(50)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into tbl_gender
# MAGIC INSERT INTO tbl_gender (Name, DOB, city, gender, state)
# MAGIC VALUES
# MAGIC     ('Alice', '2005-06-15', 'hyd', 'female', 'Telangana'),
# MAGIC     ('Bob', '2002-08-20', 'hyd', 'male', 'Telangana'),
# MAGIC     ('Carol', '2003-05-10', 'hyd', 'female', 'Telangana'),
# MAGIC     ('David', '2001-01-30', 'hyd', 'male', 'Telangana'),
# MAGIC     ('Eve', '2006-11-11', 'hyd', 'female', 'Telangana'),
# MAGIC     ('Grace', '2004-09-05', 'hyd', 'female', 'Telangana');
# MAGIC
# MAGIC select * from tbl_gender;

# COMMAND ----------

# MAGIC %sql --Write query to find all the girls who’s age in between 18 to 20 from hyd city?
# MAGIC SELECT
# MAGIC     Name,DOB,city,gender,state,
# MAGIC     -- Calculate the age using the current date
# MAGIC     DATEDIFF(YEAR, DOB, GETDATE()) AS age
# MAGIC FROM
# MAGIC     tbl_gender
# MAGIC WHERE
# MAGIC     city = 'hyd' AND
# MAGIC     gender = 'female' AND
# MAGIC     -- Calculate the age and filter for ages between 18 and 20 (inclusive)
# MAGIC     DATEDIFF(YEAR, DOB, GETDATE()) BETWEEN 18 AND 20;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 78- Find sum, avg, min, max, count of salary?

# COMMAND ----------

# Sample data for demonstration
emp_data = [(1, "John", 1000), (2, "Jane", 1200), (3, "Alice", 1500), (4, "Bob", 1300)]

# Create a DataFrame
emp_columns = ["EMPNO", "ENAME", "SAL"]
emp_df = spark.createDataFrame(emp_data, emp_columns)

# COMMAND ----------

from pyspark.sql.functions import max, min, avg, sum, count
max_sal = emp_df.select(max("SAL").alias("MAXSALINTABLE")).collect()[0]
min_sal = emp_df.select(min("SAL").alias("MINSALINTABLE")).collect()[0]
avg_sal = emp_df.select(avg("SAL").alias("AVGSALINTABLE")).collect()[0]
count_empno = emp_df.select(count("EMPNO").alias("COUNTINTABLE")).collect()[0]
sum_sal = emp_df.select(sum("SAL").alias("SUMSALINTABLE")).collect()[0]


# COMMAND ----------

display(max_sal);
display(min_sal);
display(avg_sal);
display(count_empno);
display(sum_sal);

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 79- We have csv file called fileA.csv having id, customer_name, address, age, 
# MAGIC * customer_name column having name- first_name, middle_name and last_name, 
# MAGIC * Requirement- 
# MAGIC * 1-Read the file using dataframe using pyspark, 
# MAGIC * 2- Transform the data to split the name in three parts, and 
# MAGIC * 3-Display the output like- id, first_name, middle_name, last_name, address, age?

# COMMAND ----------

from pyspark.sql.functions import split
# Read the CSV file into a DataFrame
file_path = "dbfs:/FileStore/tables/fileA.csv"  # Specify the path to your CSV file
df = spark.read.csv(file_path, header=True, inferSchema=True)
display(df)



# COMMAND ----------

#getItem(n) is a method that is used to extract an element at a specified index n

from pyspark.sql.functions import split

# Split the 'customer_name' column into 'first_name', 'middle_name', and 'last_name'
name_split = split(df['customer_name'], ' ')  # Split the 'customer_name' column by spaces

# Add the split columns to the DataFrame
df = df.withColumn('first_name', name_split.getItem(0)) \
    .withColumn('middle_name', name_split.getItem(1)) \
    .withColumn('last_name', name_split.getItem(2))

# Select the required columns in the desired order
df_transformed = df.select('id', 'first_name', 'middle_name', 'last_name', 'age')

# Display the output
df_transformed.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 80- We  have three tables in sql server Student, teacher, subject, 
# MAGIC * Student having columns- student_id, name, class, 
# MAGIC * teacher having columns- Tid, teacher_name, 
# MAGIC * subject having columns- subid, sub_name,
# MAGIC * I need the following output StudentID,StudentName,Class,TeacherName,subject

# COMMAND ----------

SELECT
    s.student_id AS StudentID,
    s.name AS StudentName,
    s.class AS Class,
    t.teacher_name AS TeacherName,
    sub.sub_name AS Subject
FROM
    Student s
JOIN
    Teacher t ON s.teacher_id = t.Tid
JOIN
    Subject sub ON t.subject_id = sub.subid;


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 81- What is difference between partitioning and bucketing?
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Partitioning

# COMMAND ----------

#Suppose you have a DataFrame containing sales data with columns such as date, product_id, and amount. You might want to partition the data by date so that each partition contains data for a specific date.

# Sample data
data = [
    ('2024-04-15', 101, 50.0),
    ('2024-04-15', 102, 30.0),
    ('2024-04-16', 101, 60.0),
    ('2024-04-16', 103, 70.0),
]

# Create DataFrame
df = spark.createDataFrame(data, ["date", "product_id", "amount"])

# Partition DataFrame by date and save it to disk
df.write.partitionBy("date").parquet("sales_data_partitioned")

# You can read the partitioned data from disk
df_partitioned = spark.read.parquet("sales_data_partitioned")

# Show the partitioned data
df_partitioned.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Bucketing

# COMMAND ----------

# Suppose you want to bucket a DataFrame containing sales data by product_id into 4 buckets.

# Sample data
data = [
    ('2024-04-15', 101, 50.0),
    ('2024-04-15', 102, 30.0),
    ('2024-04-16', 101, 60.0),
    ('2024-04-16', 103, 70.0),
]

# Create DataFrame
df = spark.createDataFrame(data, ["date", "product_id", "amount"])

# Repartition and bucket DataFrame by product_id
df = df.repartition(4, "product_id").sortWithinPartitions("product_id")

# Save the bucketing DataFrame
df.write.bucketBy(4, "product_id").saveAsTable("sales_data_bucketing")

# Read the bucketing data
df_bucketed = spark.table("sales_data_bucketing")

# Show the bucketing data
df_bucketed.show()


# COMMAND ----------

# Load the data files
file1 = spark.read.csv("path_to_10gb_file.csv")
file2 = spark.read.csv("path_to_20gb_file.csv")

# Choose a partition count aligned with your target file size (128 MB)
num_partitions = 225  # or 240

# Repartition the DataFrames to the desired number of partitions
file1 = file1.repartition(num_partitions)
file2 = file2.repartition(num_partitions)

# Perform the join operation
joined_df = file1.join(file2, on="key_column")

# Perform any desired actions with the joined data
joined_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 82- if we have str1 = 'zvva' how to remove duplicate from that string using python, can you show me with using any inbuild function and without using inbuild function.

# COMMAND ----------

str1 = 'zvva' 
new_str = ''
for i in str1:
    if i not in new_str:
        new_str += i
print(new_str) 

# COMMAND ----------

str1 = 'zvva'
new = ''.join(set(str1))
print(new)

# COMMAND ----------

str1 = 'zvva'
new_str = ''.join(sorted(set(str1)))
print(new_str)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 83- Write a program to reverse the string without changing the word order and without using inbuilt function?

# COMMAND ----------

# Method 1 - by using funcion
str1 = "my name is Gaurav"

def reverse_string(str1):
    reversed_str = ""  
    for i in str1:
        reversed_str = i + reversed_str
    return reversed_str

print(reverse_string(str1))


# COMMAND ----------

# Method 2 - by using for loop
str1 = "my name is Gaurav"
reversed_str = ""  

for i in str1:
    reversed_str = i + reversed_str

print(reverse_string(str1))


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 83- I have input in python str1 = "my name is Gaurav", want output as "Gaurav is name my"?

# COMMAND ----------

str1 = "my name is Gaurav"
words = str1.split()  # Split the string into words
reversed_words = words[::-1]  # Reverse the order of the words
output = ' '.join(reversed_words)  # Join the reversed words back into a string
print(output)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 84- Find the count of list in weekdays?

# COMMAND ----------

weekdays = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sun', 'mon', 'mon']

# Create a dictionary to store the counts
weekday_counts = {}

# Count the occurrences of each weekday
for i in weekdays:
    if i in weekday_counts:
        weekday_counts[i] += 1
    else:
        weekday_counts[i] = 1

# Create a list of lists with weekday and count
output = [[day, count] for day, count in weekday_counts.items()]

print(output)


# COMMAND ----------

# Method 2- by using Counter
from collections import Counter

weekdays = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sun', 'mon', 'mon']
new_record = Counter(weekdays)
print(new_record)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 85- Find the customer who's total amount spent is second highest?

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the table
# MAGIC CREATE TABLE CustomerTransactions (
# MAGIC     cust_id INT,
# MAGIC     quantity INT,
# MAGIC     unit_price DECIMAL(10, 2)
# MAGIC );
# MAGIC
# MAGIC -- Insert records into the table
# MAGIC INSERT INTO CustomerTransactions (cust_id, quantity, unit_price) VALUES
# MAGIC (1, 10, 50.40),
# MAGIC (2, 3, 100),
# MAGIC (3, 90, 30.90),
# MAGIC (5, 280, 1.75),
# MAGIC (2, 2, 30),
# MAGIC (1, 100, 300);
# MAGIC select * from CustomerTransactions;

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH CTE AS (
# MAGIC     SELECT cust_id, SUM(quantity * unit_price) AS total_price, 
# MAGIC         ROW_NUMBER() OVER (ORDER BY SUM(quantity * unit_price) DESC) AS rank
# MAGIC     FROM 
# MAGIC         CustomerTransactions
# MAGIC     GROUP BY 
# MAGIC         cust_id
# MAGIC )
# MAGIC SELECT cust_id FROM CTE WHERE rank = 2;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 86- I have EmpInfo11 table having columns Empid, Empname, EmpLname, Dept, Project, Address, Dob, Gender, write a query in sql server to get first four character of Empname and month name from Dob, for ex- output should be - Gaur, October?
# MAGIC * we can solve this by using substrig and datename method
# MAGIC * substring(name, 1,4)
# MAGIC * datename(month, dob)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the EmpInfo11 table
# MAGIC CREATE TABLE EmpInfo11 (
# MAGIC     Empid INT,
# MAGIC     Empname VARCHAR(50),
# MAGIC     EmpLname VARCHAR(50),
# MAGIC     Dept VARCHAR(50),
# MAGIC     Project VARCHAR(50),
# MAGIC     Address VARCHAR(100),
# MAGIC     Dob DATE,
# MAGIC     Gender CHAR(1)
# MAGIC );
# MAGIC
# MAGIC -- Insert sample records into EmpInfo11
# MAGIC INSERT INTO EmpInfo11 (Empid, Empname, EmpLname, Dept, Project, Address, Dob, Gender)
# MAGIC VALUES
# MAGIC (1, 'John', 'Doe', 'IT', 'ProjectA', '123 Main St, CityA', '1990-10-15', 'M'),
# MAGIC (2, 'Jane', 'Smith', 'HR', 'ProjectB', '456 Elm St, CityB', '1985-05-20', 'F'),
# MAGIC (3, 'Michael', 'Johnson', 'Finance', 'ProjectC', '789 Oak St, CityC', '1988-12-03', 'M');
# MAGIC select * from EmpInfo11;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to get first four characters of Empname and month name from Dob
# MAGIC SELECT 
# MAGIC     SUBSTRING(Empname, 1, 4) AS First_Four_Characters_of_Empname,
# MAGIC     DATENAME(MONTH, Dob) AS Month_from_Dob
# MAGIC FROM 
# MAGIC     EmpInfo11;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 87 - Remove the records which is duplicates in Project column.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT Project, COUNT(*) AS Count_of_Projects
# MAGIC FROM EmpInfo11
# MAGIC GROUP BY Project
# MAGIC HAVING COUNT(*) > 1;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Method 2- 
# MAGIC -- Query to remove duplicates from Project column
# MAGIC SELECT DISTINCT Project
# MAGIC FROM EmpInfo11;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 88- Suppose we have another table called EmpPosition11 having column Empid, EmpPosition, DateOfJoining, Salary, write a query to fetch all Employees who hold the managerial position from EmpPosition11 and EmpInfo11 table.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query to fetch all employees holding managerial positions
# MAGIC SELECT 
# MAGIC     E.Empid,E.Empname,E.EmpLname,E.Dept,E.Project,E.Address,E.Dob,E.Gender,P.EmpPosition,P.DateOfJoining,P.Salary
# MAGIC FROM 
# MAGIC     EmpInfo11 E
# MAGIC INNER JOIN 
# MAGIC     EmpPosition11 P ON E.Empid = P.Empid
# MAGIC WHERE 
# MAGIC     P.EmpPosition LIKE '%Manager%';
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 89- Convert the SQL query into pyspark dataframe?
# MAGIC * SELECT * FROM EmpPosition ORDER BY Salary DESC LIMIT N;
# MAGIC

# COMMAND ----------

# Method 1- 
from pyspark.sql.functions import desc

# Assuming df is your PySpark DataFrame containing the EmpPosition table
df = df.select('EmpPosition').orderBy(desc('Salary')).limit(N)

# Method 2- By using orderBy
# Convert SQL query to PySpark DataFrame operations
result_df = EmpPosition.orderBy(EmpPosition["Salary"].desc()).limit(N)

# Show the result DataFrame
result_df.show()

# Method 3- By using sort()

# Convert SQL query to PySpark DataFrame operations
result_df = EmpPosition.sort(desc("Salary")).limit(N)

# Show the result DataFrame
result_df.show()

# COMMAND ----------

# Method 3- By using Window function
from pyspark.sql import SparkSession, Window
from pyspark.sql.functions import col, row_number

# Initialize SparkSession
spark = SparkSession.builder \
    .appName("EmpPosition Analysis") \
    .getOrCreate()

# Assuming Df is your DataFrame
# Replace 'Df' with the actual name of your DataFrame
Df.createOrReplaceTempView('EmpPosition')

# Create a window specification
w = Window.orderBy(col('Salary'))

# Apply window function
Df1 = Df.select('*', row_number().over(w).alias('row_number'))

# Show the result DataFrame
Df1.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 90 - I have one data,  
# MAGIC * data = [['John', 50, 'Male', 'Austin', 70],
# MAGIC *    ['Cataline', 45 ,'Female', 'San Francisco', 80],
# MAGIC * ['Matt', 30 ,'Male', 'Boston', 95],
# MAGIC * ['Oliver',35,'Male', 'New york', 65]], can you please sort this dataframe in pyspark with column age

# COMMAND ----------

#Method 1 - By using .agg method
# Sort DataFrame by Age column
sorted_df = df.select('Name').agg(sort(col('Age')))

# Show the sorted DataFrame
sorted_df.show()

# COMMAND ----------

# Method 2- by using sort method
# Sort DataFrame by Age column in ascending order
sorted_df = df.sort("Age")

# Method 3 - by using orderBy method

# Sort DataFrame by Age column
sorted_df = df.orderBy("Age")

# Show the sorted DataFrame
sorted_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 91- Suppose i have a table called Emptable23 having records - EmpId	EmpName		Salary
# MAGIC * 1	Ross		1000
# MAGIC * 2	Chandler	2000
# MAGIC * 3	Rachel		3000, can you read this table in pyspark dataframe.

# COMMAND ----------

# Define data
data = [(1, "Ross", 1000),
        (2, "Chandler", 2000),
        (3, "Rachel", 3000)]

# Define schema
schema = ["EmpId", "EmpName", "Salary"]

# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show the DataFrame
df.show()

# COMMAND ----------

# Read CSV file into DataFrame
df = spark.read.csv('Emp', inferSchema=True, header=True)

# COMMAND ----------

file_path = "/path/to/employee_data.csv"

# Read CSV file into DataFrame
df = spark.read.csv(file_path, header=True, inferSchema=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 92- If table is stored in sql location then how can you read into dataframe?
# MAGIC

# COMMAND ----------

# JDBC connection properties
jdbc_url = "jdbc:mysql://your_database_host:port/your_database_name"
table_name = "Emptable23"
properties = {
    "user": "your_username",
    "password": "your_password",
    "driver": "com.mysql.jdbc.Driver"
}

# Read data from JDBC into DataFrame
df = spark.read.jdbc(url=jdbc_url, table=table_name, properties=properties)

# Show the DataFrame
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 93- If i want to add date column then how can i add this?

# COMMAND ----------

# To add a new column called "date" to your DataFrame, you can use the withColumn()
# if you want to specify a constant value for all rows 

from pyspark.sql.functions import lit

# Add a new column with a constant date value for all rows
df_with_date = df.withColumn("date", lit("2024-04-27"))

# Show the DataFrame with the new column
df_with_date.show()

# COMMAND ----------

# If you want to generate the date dynamically based on some logic, you can use PySpark's built-in date functions or Python's datetime module to create the date values
from pyspark.sql.functions import current_date

# Add a new column with the current date for all rows
df_with_date = df.withColumn("date", current_date())

# Show the DataFrame with the new column
df_with_date.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 94- Write code in pyspark to find max salary along with Employee name?

# COMMAND ----------

# Group by EmpName and find the maximum salary for each employee
max_salary_df = df.groupBy("EmpName").agg(max("Salary").alias("MaxSalary"))

# Show the DataFrame with max salary for each employee
max_salary_df.show()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT name
# MAGIC FROM employees e1
# MAGIC WHERE age > (SELECT AVG(age) FROM employees e2 WHERE e1.department = e2.department);
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 94- We have table with four columns- EmpId, EmpName, Salary, JoiningDate, joiningdate column having vales as jan, feb, write a query to convert jan to 1, feb to 2 and so on?

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE convert_month (
# MAGIC     EmpId INT,
# MAGIC     EmpName VARCHAR(50),
# MAGIC     Salary INT,
# MAGIC     JoiningDate DATE
# MAGIC );
# MAGIC
# MAGIC INSERT INTO convert_month (EmpId, EmpName, Salary, JoiningDate)
# MAGIC VALUES
# MAGIC (1, 'John', 50000.00, '2023-01-10'),
# MAGIC (2, 'Alice', 60000.00, '2022-11-15'),
# MAGIC (3, 'Bob', 55000.00, '2023-03-20'),
# MAGIC (4, 'Emily', 48000.00, '2022-09-05'),
# MAGIC (5, 'Michael', 65000.00, '2023-05-12');
# MAGIC select * from convert_month;

# COMMAND ----------

# MAGIC %sql
# MAGIC select month(JoiningDate) as month_column 
# MAGIC from convert_month;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     CASE 
# MAGIC         WHEN month_column = 'January' THEN 1
# MAGIC         WHEN month_column = 'February' THEN 2
# MAGIC         WHEN month_column = 'March' THEN 3
# MAGIC         WHEN month_column = 'April' THEN 4
# MAGIC         WHEN month_column = 'May' THEN 5
# MAGIC         WHEN month_column = 'June' THEN 6
# MAGIC         WHEN month_column = 'July' THEN 7
# MAGIC         WHEN month_column = 'August' THEN 8
# MAGIC         WHEN month_column = 'September' THEN 9
# MAGIC         WHEN month_column = 'October' THEN 10
# MAGIC         WHEN month_column = 'November' THEN 11
# MAGIC         WHEN month_column = 'December' THEN 12
# MAGIC     END AS month_number
# MAGIC FROM
# MAGIC     your_table;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 95- I have table called emp_table888 having column empname and in that employee i have string with 50 letters, can you write a query in sql server to find the n character occurances?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE occurance_char (
# MAGIC     emp_id int,
# MAGIC     empname VARCHAR(50)
# MAGIC );
# MAGIC INSERT INTO occurance_char (emp_id, empname) VALUES
# MAGIC (1, 'John Doe'),
# MAGIC (2, 'Jane Smith'),
# MAGIC (3, 'Michael Johnson'),
# MAGIC (4, 'Emma Brown'),
# MAGIC (5, 'David Nguyen');
# MAGIC select * from occurance_char;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     empname,
# MAGIC     (LEN(empname) - LEN(REPLACE(empname, 'n', ''))) AS occurrences_of_n
# MAGIC FROM 
# MAGIC     occurance_char;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 96- I am having data in pyspark dataframe having 10 students data and column name is id and total_marks I want to make the category like category 1,2,3,4,5,
# MAGIC * cat1- <50-fail,
# MAGIC * cat2- 50-60 3rd class,
# MAGIC * cat3 - 60-70 2nd class,
# MAGIC * cat4- 70-75 1st class,
# MAGIC * cat5- above 75, 1st class with distinction, and show the result with column id, total_marks, category.

# COMMAND ----------

from pyspark.sql.functions import col, when
# Sample data
data = [(1, 45), (2, 55), (3, 65), (4, 72), (5, 80),
        (6, 40), (7, 58), (8, 67), (9, 73), (10, 85)]

# Create DataFrame
df = spark.createDataFrame(data, ["id", "total_marks"])
df.show()
df = df.withColumn('category',
                   when(col('total_marks') < 50, 'Fail')
                   .when((col('total_marks') >= 50) & (col('total_marks') <= 60), 'Third Class')
                   .when((col('total_marks') > 60) & (col('total_marks') <= 70), 'Second Class')
                   .when((col('total_marks') > 70) & (col('total_marks') <= 75), 'First Class')
                   .when(col('total_marks') > 75, 'Distinction')
                   .otherwise('Category Not Available'))

df2 = df.select('id', 'total_marks', 'category')
df2.show()

# COMMAND ----------

from pyspark.sql.functions import expr

# Sample data
data = [(1, 45), (2, 55), (3, 65), (4, 72), (5, 80),
        (6, 40), (7, 58), (8, 67), (9, 73), (10, 85)]

# Create DataFrame
df = spark.createDataFrame(data, ["id", "total_marks"])

# Define SQL expressions for category
category_expr = """
CASE 
    WHEN total_marks < 50 THEN 'Fail'
    WHEN total_marks >= 50 AND total_marks < 60 THEN '3rd Class'
    WHEN total_marks >= 60 AND total_marks < 70 THEN '2nd Class'
    WHEN total_marks >= 70 AND total_marks < 75 THEN '1st Class'
    ELSE '1st Class with Distinction'
END AS category
"""

# Add category column using selectExpr()
df = df.selectExpr("*", category_expr)

# Show the result
df.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 97- fiter out the null values and show only not-null values?

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Not_null_table (
# MAGIC     student_id INT,
# MAGIC     student_name VARCHAR(50),
# MAGIC     age INT,
# MAGIC     grade VARCHAR(1)
# MAGIC );
# MAGIC INSERT INTO Not_null_table (student_id, student_name, age, grade) VALUES
# MAGIC (1, 'John', 20, 'A'),
# MAGIC (2, 'Alice', NULL, 'B'),
# MAGIC (3, 'Bob', 22, NULL),
# MAGIC (4, 'Emily', 21, 'C'),
# MAGIC (5, NULL, 19, 'A');
# MAGIC select * from Not_null_table;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Not_null_table where student_name is not null;

# COMMAND ----------

select * from Not_null_table where student_name is not null and age is not null and grade is not null;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM Not_null_table
# MAGIC WHERE NULLIF(student_name, '') IS NOT NULL
# MAGIC   AND NULLIF(age, '') IS NOT NULL
# MAGIC   AND NULLIF(grade, '') IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Question 98- I have marks table having two columns- STUDENT_ID, MARKS having following values,i want to find the STUDENT_ID who is having greater than equal to 500 marks, show the result in column STUDENT_ID, STUDENT_TOTAL_MARKS and STUDENT_TOTAL_MARKS in descending order
# MAGIC * for ex-OUTPUT= 1 because 200+300 is greater that equal to 500

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE marks1 (
# MAGIC     STUDENT_ID INT,
# MAGIC     MARKS INT
# MAGIC );
# MAGIC
# MAGIC INSERT INTO marks1 (STUDENT_ID, MARKS) VALUES
# MAGIC (1, 250),
# MAGIC (1, 300),
# MAGIC (2, 450),
# MAGIC (3, 500),
# MAGIC (4, 300),
# MAGIC (4, 350),
# MAGIC (5, 100),
# MAGIC (5, 200);
# MAGIC select * from marks1;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT STUDENT_ID, SUM(MARKS) AS STUDENT_TOTAL_MARKS
# MAGIC FROM marks1
# MAGIC GROUP BY STUDENT_ID
# MAGIC HAVING SUM(MARKS) >= 500
# MAGIC ORDER BY STUDENT_TOTAL_MARKS DESC;
# MAGIC