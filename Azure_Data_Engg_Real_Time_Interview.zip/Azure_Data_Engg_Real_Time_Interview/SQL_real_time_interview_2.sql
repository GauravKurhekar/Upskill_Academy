-- Databricks notebook source
-- MAGIC %md
-- MAGIC ##### Question 31- find employee in each department who is having salaries more than their average salary of department wise?

-- COMMAND ----------

drop table if exists Emp_avg;
CREATE TABLE Emp_avg (
    EmpID INT,
    EmpName VARCHAR(50),
    DeptName VARCHAR(50),
    Salary DECIMAL(10, 2)
);

INSERT INTO Emp_avg (EmpID, EmpName, DeptName, Salary) VALUES
(101, 'John', 'HR', 50000.00),
(102, 'Alice', 'HR', 55000.00),
(103, 'Bob', 'Finance', 60000.00),
(104, 'Emily', 'Finance', 62000.00),
(105, 'Mike', 'IT', 70000.00),
(106, 'Sara', 'IT', 75000.00);

select * from Emp_avg;

-- COMMAND ----------

select E.EmpID, E.EmpName, E.DeptName, E.Salary 
from Emp_avg as E where E.Salary > (select AVG(Salary) from Emp_avg where DeptName= E.DeptName)

-- COMMAND ----------

-- if we are retrieving data from all columns then instead of all column names, we can give alias name with dot(.) E.*
select E.* from Emp_avg as E where E.Salary > (select AVG(Salary) from Emp_avg where DeptName= E.DeptName)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 32- find employee in each department who is having salaries less than their average salary of department wise?

-- COMMAND ----------

select E.* from Emp_avg as E where E.Salary< (select avg(Salary) from Emp_avg where DeptName = E.DeptName)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 33- Cricket match schedule?
-- MAGIC

-- COMMAND ----------

create table matchs(country varchar(90));
insert into matchs values('ind'),('sl'),('eng'),('nz'),('aus'),('pak'),('nepal');
select * from matchs;

-- COMMAND ----------

--Method 1 
SELECT 
    m1.country AS Team1, 
    m2.country AS Team2
FROM 
    matchs m1 
INNER JOIN 
    matchs m2 ON m1.country <> m2.country
ORDER BY 
    Team1, Team2;

-- COMMAND ----------

-- Method 2
select M1.country + 'VS' + M2.country as Schedule_Matches 
from matchs as M1 
join matchs as M2
on M1.country<>M2.country;

-- OR

  select a.country+ ' vs ' +b.country as schedule from matchs as a join matchs as b on a.country<>b.country

  -- OR 

select m1.country as country1, m2.country as country2     -- when use cross join then use where condition
from matchs m1 cross join matchs m2                       -- when use inner join then use on condition
where m1.country<> m2.country;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 34- Find maximum salary of employee with his name?

-- COMMAND ----------

CREATE TABLE emp_table (
    Ename VARCHAR(50),
    Deptno INT,
    Salary DECIMAL(10, 2)
);

-- Insert 15 values into emp_table
INSERT INTO emp_table (Ename, Deptno, Salary) VALUES
('John', 10, 50000.00),
('Alice', 20, 60000.00),
('Bob', 10, 55000.00),
('Emily', 30, 62000.00),
('Mike', 20, 70000.00),
('Sara', 30, 75000.00),
('Tom', 20, 48000.00),
('Emma', 10, 52000.00),
('David', 30, 68000.00),
('Lily', 20, 58000.00),
('Chris', 10, 54000.00),
('Olivia', 20, 72000.00),
('Sophia', 10, 56000.00),
('Daniel', 30, 71000.00),
('Grace', 20, 69000.00);
select * from emp_table;

-- COMMAND ----------

--If we use below query, it will print only max salary but not name
select max(Salary) as max_salary from emp_table

-- COMMAND ----------

--Therefore we need to use subquery
select * from emp_table where Salary = (select max(Salary) from emp_table);

-- COMMAND ----------

with CTE 
  as
  (
  select *,ROW_NUMBER() over(order by salary desc) as hig_sal from emp_table
  )
  select * from CTE where hig_sal=1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 35- Find the second highest salary?

-- COMMAND ----------

-- Method 1 - By using Max function
select max(Salary) as second_hig_salary from emp_table where Salary<(select max(Salary) from emp_table);

-- COMMAND ----------

-- Method 2 - By using CTE function
with CTE as (
  select Salary, dense_rank() over(order by Salary desc) as second_hig_sal from emp_table
)
select Salary from CTE where second_hig_sal=2

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 36- Write a program in pyspark to find SUM, AVERAGE, MIN, MAX, COUNT of salary?

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql import SparkSession
-- MAGIC from pyspark.sql.functions import max, min, avg, count, sum
-- MAGIC
-- MAGIC # Create a Spark session
-- MAGIC spark = SparkSession.builder.appName("AggregateExample").getOrCreate()
-- MAGIC
-- MAGIC # Sample data for demonstration
-- MAGIC emp_data = [(1, "John", 1000), (2, "Jane", 1200), (3, "Alice", 1500), (4, "Bob", 1300)]
-- MAGIC
-- MAGIC # Create a DataFrame
-- MAGIC emp_columns = ["EMPNO", "ENAME", "SAL"]
-- MAGIC df = spark.createDataFrame(emp_data, emp_columns)
-- MAGIC display(df)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC # Calculate the required aggregate values
-- MAGIC max_sal = emp_df.select(max("SAL").alias("MAXSALINTABLE")).collect()[0]
-- MAGIC min_sal = emp_df.select(min("SAL").alias("MINSALINTABLE")).collect()[0]
-- MAGIC avg_sal = emp_df.select(avg("SAL").alias("AVGSALINTABLE")).collect()[0]
-- MAGIC count_empno = emp_df.select(count("EMPNO").alias("COUNTINTABLE")).collect()[0]
-- MAGIC sum_sal = emp_df.select(sum("SAL").alias("SUMSALINTABLE")).collect()[0]

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 37- Date question in SQL?

-- COMMAND ----------

select getdate() as todays_date_time;

select getutcdate() as global_date;

select year(getdate()) as year_date;

select month(getdate()) as month_date;

select day(getdate()) as day_date;

select datename(mm,getdate()) as month_date;

select DATENAME(yyyy, getdate()) as year;

select datename(dw,getdate()) as day_of_week;

select year(getdate()) as year_date,month(getdate()) as month_date,day(getdate()) as day_date, datename(mm,getdate()) as month_date,
datename(dw,getdate()) as day_of_week;

-- COMMAND ----------

--------------------------date add--------------------------------------------------------
select DATEADD(dd,1,getdate()) as date_add;

select DATEADD(mm,2,getdate()) as month_add;

select DATEADD(yy,2,getdate()) as year_add;

select DATEADD(mm,-2,getdate()) as month_sub;

select dateadd(yy, -2, getdate()) as year_sub;

select dateadd(dd, -2, getdate()) as day_sub;

-- COMMAND ----------

------------datedifferent-------------------------------------------------------
-- Difference between dateadd and datediff is- in dateadd, we mention number for ex- (mm,-2,getdate()
--and in datediff we mention complete year, or column name of table(yy,'1947-08-15',getdate())

select DATEDIFF(yy,'1947-08-15',getdate()) as year_diff;

select DATEDIFF(mm,'1947-08-15',getdate()) as month_diff;

select DATEDIFF(dd,'1947-08-15',getdate()) as day_diff;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 38- Find experience of employee?

-- COMMAND ----------

-- Create a table to store employee data
CREATE TABLE Employee_date (
    EmployeeID INT,
    EmployeeName VARCHAR(100),
    DOB DATE,
    DOJ DATE
);

-- Insert up to 10 records
INSERT INTO Employee_date (EmployeeID,EmployeeName, DOB, DOJ)
VALUES (1,'John Doe', '1990-05-15', '2010-08-20'),
       (2,'Jane Smith', '1985-02-28', '2009-07-10'),
       (3,'Mike Johnson', '1992-11-10', '2015-04-05'),
       (4,'Sarah Davis', '1988-09-03', '2012-11-30'),
       (5,'David Wilson', '1995-06-20', '2018-02-15'),
       (6,'Emily Thompson', '1991-03-12', '2013-09-25'),
       (7,'Michael Brown', '1987-12-07', '2011-05-01'),
       (8,'Jessica Lee', '1994-08-18', '2017-01-10'),
       (9,'Andrew Miller', '1989-04-25', '2014-06-05'),
       (10,'Olivia Clark', '1993-01-08', '2016-11-20');
select * from Employee_date;

-- COMMAND ----------

--Method 1 - To find diference in year
select *, DATEDIFF(yy, DOJ, getdate()) as year_of_exp from Employee_date;

--Method 2 - To find diference in year for any candidate
select *, DATEDIFF(yy, DOJ, getdate()) as year_of_exp from Employee_date where EmployeeID = 1;

--Method 3 - To find diference in year for all candidate
select EmployeeID, DATEDIFF(yy, DOJ, getdate()) as year_of_exp from Employee_date where EmployeeID = 1;

--Method 4 - To find diference in months for any candidate
select *, DATEDIFF(MM, DOJ, getdate()) as year_of_exp_in_month from Employee_date;

--Method 5 - To find diference in Days for any candidate
select *, DATEDIFF(DD, DOJ, getdate()) as year_of_exp_in_days from Employee_date;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 39- Find the Employee whose experience is more than 10 years?

-- COMMAND ----------

select *, datediff(YY,DOJ, getdate()) as year_of_exp from employee_date where datediff(YY, DOJ, getdate())>10;
--OR

select EmployeeName, datediff(YY, DOJ, getdate()) as year_of_exp from Employee_date where datediff(YY,DOJ, getdate())>10;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 40- Write SQL query to find age of employee?

-- COMMAND ----------

select *, DATEDIFF(yy, DOB, getdate())as age from Employee_date;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 41- Write SQL query to find age of employee whose age is more than 30?

-- COMMAND ----------

select *, datediff(YY,DOB, getdate()) as Age from Employee_date where datediff(YY,DOB, getdate())>30;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 42- Write SQL query to find age and experience of employee?

-- COMMAND ----------

select *,DATEDIFF(yy,dob,getdate()) as Age ,DATEDIFF(yy,doj,getdate()) as Experience from Employee_date;

select *,DATEDIFF(yy,dob,getdate()) as Age,DATEDIFF(yy,doj,getdate()) as Experience,getdate() as todate from Employee_date;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 43- Find Employee rank with help of row_number(), rank() and dense_rank()

-- COMMAND ----------

CREATE TABLE Marks (
  StudentName VARCHAR(50),
  Marks INT
);

INSERT INTO Marks (StudentName, Marks) VALUES ('John', 80);
INSERT INTO Marks (StudentName, Marks) VALUES ('Alice', 75);
INSERT INTO Marks (StudentName, Marks) VALUES ('Bob', 90);
INSERT INTO Marks (StudentName, Marks) VALUES ('Sarah', 95);
INSERT INTO Marks (StudentName, Marks) VALUES ('Michael', 95);
INSERT INTO Marks (StudentName, Marks) VALUES ('Emma', 88);
INSERT INTO Marks (StudentName, Marks) VALUES ('David', 93);
INSERT INTO Marks (StudentName, Marks) VALUES ('Olivia', 80);
INSERT INTO Marks (StudentName, Marks) VALUES ('James', 95);
INSERT INTO Marks (StudentName, Marks) VALUES ('Sophia', 93);
INSERT INTO Marks (StudentName, Marks) VALUES ('William', 84);
select * from marks;

-- COMMAND ----------

select *, row_number() over (order by Marks desc) as row_rank, rank() over (order by Marks desc) as rank_rank, dense_rank() over (order by Marks desc) as dense_Rankk from marks;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 44- If Employee Salary = 30000 then How to get above and below salary of perticuar employee i.e >30000 and <30000?

-- COMMAND ----------

select * from employee where salary < (select salary from employee where emp_no = 7698) order by salary;

select * from employee where salary > (select salary from employee where emp_no = 7698) order by salary;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 45- How to get maximum salary of employee from table?
-- MAGIC

-- COMMAND ----------

drop table if exists Emp_avg12;
CREATE TABLE Emp_avg12 (
    EmpID INT,
    EmpName VARCHAR(50),
    DeptName VARCHAR(50),
    Salary DECIMAL(10, 2)
);

INSERT INTO Emp_avg12 (EmpID, EmpName, DeptName, Salary) VALUES
(101, 'John', 'HR', 50000.00),
(102, 'Alice', 'HR', 55000.00),
(103, 'Bob', 'Finance', 60000.00),
(104, 'Emily', 'Finance', 62000.00),
(105, 'Mike', 'IT', 70000.00),
(106, 'Sara', 'IT', 75000.00);

select * from Emp_avg12;

-- COMMAND ----------

-- Method 1- using max aggregate function
select max(Salary) as max_salary from emp_avg12;

-- COMMAND ----------

-- Method 2- using sub-query 
select * from emp_avg12 where Salary = (select max(Salary) from emp_avg12);

-- COMMAND ----------

--Method 3- using CTE
with cte as(
select *, ROW_NUMBER() over (order by Salary desc) as max_sal from emp_avg12
)
select * from cte where max_sal = 1;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 46- How to get second highest salary?
-- MAGIC

-- COMMAND ----------

-- Method 1 - by using max function
select max(Salary) as second_hig_salary from emp_avg12 where salary<(select max(Salary) from emp_avg12);

-- COMMAND ----------

-- Method 2 - by using CTE
with CTE as (
  select Salary, dense_rank() over (order by Salary desc) as second_hig_salary from emp_avg12
)
select Salary from CTE where second_hig_salary= 2;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 47- Find the rolling average?

-- COMMAND ----------

CREATE TABLE posts (
    user_id INTEGER,
    date DATE,
    post_count INTEGER
);

INSERT INTO posts (user_id, date, post_count)
VALUES
    (1, '2023-07-01', 5),
    (1, '2023-07-02', 7),
    (1, '2023-07-03', 3),
    (1, '2023-07-04', 10),
    (1, '2023-07-05', 6),
    (2, '2023-07-01', 8),
    (2, '2023-07-02', 4),
    (2, '2023-07-03', 2),
    (2, '2023-07-04', 9),
    (2, '2023-07-05', 5);

select * from posts;

-- COMMAND ----------

SELECT
    user_id,
    date,
    post_count,
    ROUND(AVG(post_count) OVER (PARTITION BY user_id ORDER BY date ), 2) AS rolling_average
FROM
    posts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 48- From below table, i want to find top 2 customers every months with highest sales?

-- COMMAND ----------

CREATE TABLE SalesData (
    ID INT,
    Months VARCHAR(20),
    Sales INT
);
INSERT INTO SalesData (ID, Months, Sales)
VALUES
    (100, 'January', 200),
    (101, 'January', 300),
    (102, 'January', 400),
    (100, 'January', 300),
    (105, 'February', 600),
    (103, 'February', 700),
    (104, 'February', 200);
select * from SalesData;

-- COMMAND ----------

WITH TopCustomers AS (
    SELECT
        ID, Months,Sales,
        ROW_NUMBER() OVER (PARTITION BY Months ORDER BY Sales DESC) AS rank
    FROM
        SalesData
)
SELECT
    ID,Months,Sales
FROM
    TopCustomers
WHERE
    rank <= 2;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 50 SQL Queries

-- COMMAND ----------

drop table if exists Empdetails2;
CREATE TABLE if not exists Empdetails2 (
    EmpId INT,
    FullName VARCHAR(50),
    ManagerId INT,
    DateOfJoining DATE,
    City VARCHAR(50)
);
INSERT INTO Empdetails2 (EmpId, FullName, ManagerId, DateOfJoining, City)
VALUES
    (121, 'John Snow', 321, '2019-01-31', 'Toronto'),
    (321, 'Walter White', 986, '2020-01-30', 'California'),
    (421, 'Kuldeep Rana', 876, '2021-11-27', 'New Delhi');
select * from Empdetails2;

-- COMMAND ----------

CREATE TABLE Empsalary2 (
    EmpId INT,
    Project VARCHAR(255),
    Salary DECIMAL(10, 2),
    Variable DECIMAL(10, 2)
);
INSERT INTO Empsalary2 (EmpId, Project, Salary, Variable)
VALUES
    (121, 'P1',8000, '500'),
    (321, 'P2', 10000, '1000'),
    (421, 'P1', 12000, '0');
select * from Empsalary2;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q 1. Write an SQL query to fetch the EmpId and FullName of all the employees working under the Manager with id – ‘986’.

-- COMMAND ----------

select Empid, FullName from Empdetails where ManagerId = '986';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q 2. Write an SQL query to fetch the different projects available from the EmployeeSalary table.

-- COMMAND ----------

select distinct project from Empsalary;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q 3. Write an SQL query to fetch the count of employees working in project ‘P1’.

-- COMMAND ----------

select count(Empid)from Empsalary where Project = 'P1'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q 4. Write an SQL query to find the maximum, minimum, and average salary of the employees.

-- COMMAND ----------

select max(Salary) as max_Salary, min(Salary) as min_salary, AVG(Salary) as avg_Sal from Empsalary;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q 5. Write an SQL query to find the employee id whose salary lies in the range of 9000 and 15000.

-- COMMAND ----------

select Empid, Salary from Empsalary where Salary between 9000 and 15000;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Q 6. Write an SQL query to fetch those employees who live in Toronto and work under the manager with ManagerId – 321.

-- COMMAND ----------

select Empid, City,ManagerId from Empdetails where City = 'Toronto' and ManagerId = '321';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 7. Write an SQL query to fetch all the employees who either live in California or work under a manager with ManagerId – 321.
-- MAGIC

-- COMMAND ----------

select Empid, City,ManagerId from Empdetails where City = 'Toronto' or ManagerId = '321';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 8. Write an SQL query to fetch all those employees who work on Projects other than P1.

-- COMMAND ----------

SELECT EmpId FROM Empsalary WHERE Project <> 'P1';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 9. Write an SQL query to display the total salary of each employee adding the Salary with Variable value.

-- COMMAND ----------

SELECT Empid, Salary + Variable as total_salary from Empsalary;
--OR
SELECT Empid, (Salary + Variable) as total_salary from Empsalary;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 10. Write an SQL query to fetch the employees whose name begins with any two characters followed by a text “hn” and ends with any sequence of characters.

-- COMMAND ----------

SELECT FullName from Empdetails where FullName like '__hn%';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 11. Write an SQL query to fetch all the EmpIds which are present in either of the tables – ‘EmployeeDetails’ and ‘EmployeeSalary’.

-- COMMAND ----------

SELECT EmpId FROM Empdetails
UNION 
SELECT EmpId FROM Empsalary;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 12. Write an SQL query to fetch common records between two tables.

-- COMMAND ----------

SELECT * from Empdetails
intetrsect
select * from Empsalary

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 13. Write an SQL query to fetch records that are present in one table but not in another table.

-- COMMAND ----------

SELECT * FROM Empdetails
MINUS
SELECT * FROM Empsalary;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 14. Write an SQL query to fetch the EmpIds that are present in both the tables –  ‘EmployeeDetails’ and ‘EmployeeSalary.

-- COMMAND ----------

-- Method 1 - By using inner query
select Empid from Empdetails where Empid in(select Empid from Empsalary);

-- COMMAND ----------

--Method 2 - By using self join
select E.Empid from Empdetails E join Empsalary S
on E.EmpId = S.Empid;

-- COMMAND ----------

--Method 3- By using Intersect method
select Empid from Empsalary 
intersect
select Empid from Empdetails

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 15. Write an SQL query to fetch the EmpIds that are present in EmployeeDetails but not in EmployeeSalary.

-- COMMAND ----------

--Method 1- By using inner query
select Empid from Empdetails where Empid  not in(select Empid from Empsalary);

-- COMMAND ----------

--Method 2 - By using self join and where S.Empsalary is null 
select E.Empid from Empdetails E join Empsalary S
on E.EmpId = S.Empid
where S.Empid is Null;

-- COMMAND ----------

--Method 3- By using Except method
SELECT EmpId
FROM Empdetails
EXCEPT
SELECT EmpId
FROM Empsalary;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 16. Write an SQL query to fetch the employee’s full names and replace the space with ‘-’.

-- COMMAND ----------

select REPLACE(FullName, ' ', '-') from Empdetails;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 17. Write an SQL query to fetch the position of a given character(s) in a field.

-- COMMAND ----------

SELECT
    EmpId,
    FullName,
    -- Searching for 'Snow' in the FullName column and returning the position.
    CHARINDEX('Snow', FullName) AS Position
FROM
    Empdetails;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 18. Write an SQL query to display both the EmpId and ManagerId together.

-- COMMAND ----------

SELECT CONCAT(EmpId, ManagerId) as NewId
FROM Empdetails;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 19. Write a query to fetch only the first name(string before space) from the FullName column of the EmployeeDetails table.

-- COMMAND ----------

-- we are required to first fetch the location of the space character in the FullName field and then extract the first name out of the FullName field.
-- For finding the location we will use CHARINDEX in SQL SERVER and for fetching the string before space, we will use the SUBSTRING method.
select SUBSTRING(FullName, 1, 3) from Empdetails;

-- COMMAND ----------

select CHARINDEX(' ', FullName) from Empdetails;

-- COMMAND ----------

SELECT SUBSTRING(FullName, 1, CHARINDEX(' ',FullName)) 
FROM Empdetails;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 20. Write an SQL query to uppercase the name of the employee and lowercase the city values.

-- COMMAND ----------

SELECT UPPER(FullName), LOWER(City) 
FROM Empdetails;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 21. Write an SQL query to find the count of the total occurrences of a particular character – ‘n’ in the FullName field.

-- COMMAND ----------

SELECT 
    SUM(LEN(FullName) - LEN(REPLACE(FullName, 'n', ''))) AS TotalOccurrencesOfN
FROM 
    Empdetails1;

--The REPLACE function replaces all occurrences of the character 'n' with an empty string in the FullName column.
--The difference in lengths between the original string and the string with all occurrences of 'n' removed gives the total count of occurrences of 'n'.
--The SUM function is used to sum up the counts from all rows.

-- COMMAND ----------

CREATE PROCEDURE InsertIntoTempTable
    @temp_data INT
AS
BEGIN
    INSERT INTO temp_table (temp_data)
    VALUES (@temp_data);
END;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 22. Write an SQL query to update the employee names by removing leading and trailing spaces.

-- COMMAND ----------

UPDATE Empdetails1
SET FullName = LTRIM(RTRIM(FullName));

--The LTRIM function removes any leading spaces from the FullName column.
--The RTRIM function removes any trailing spaces from the result of the LTRIM operation.
--The UPDATE statement updates the FullName column in the Empdetails table with the cleaned-up names.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 23. Fetch all the employees who are not working on any project.
-- MAGIC

-- COMMAND ----------

select EmpId from Empsalary1 where Project is null;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 24. Write an SQL query to fetch employee names having a salary greater than or equal to 5000 and less than or equal to 10000.

-- COMMAND ----------

select E.Empid, E.FullName from Empdetails1 E 
join Empsalary1 S on
E.empid = S.empid
where S.Salary >=5000 and S.Salary<=10000

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 25. Write an SQL query to find the current date-time.

-- COMMAND ----------

select getdate()

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 26. Write an SQL query to fetch all the Employee details from the EmployeeDetails table who joined in the Year 2020.

-- COMMAND ----------

select empid from Empdetails1 where DateOfJoining between '2020-01-01' and '2020-12-31';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 27. Write an SQL query to fetch all employee records from the EmployeeDetails table who have a salary record in the EmployeeSalary table.

-- COMMAND ----------

select e.empid, e.fullname, s.salary from Empdetails2 e
join empsalary2 s on e.empid = s.empid


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 28. Write an SQL query to fetch the project-wise count of employees sorted by project’s count in descending order.

-- COMMAND ----------

SELECT Project, count(EmpId) EmpProjectCount
FROM Empsalary2
GROUP BY Project
ORDER BY EmpProjectCount DESC;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 29. Write a query to fetch employee names and salary records. Display the employee details even if the salary record is not present for the employee.

-- COMMAND ----------

select e.empid, e.fullname, s.salary from Empdetails2 e
join Empsalary2 s 
on e.empid = s.empid

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 30. Write an SQL query to join 3 tables

-- COMMAND ----------

select * from tableeAA as a
join tableeBB as b on a.A_id = b.B_id
join tableeCC as c on a.A_id = c.C_id

-- COMMAND ----------

SELECT column1, column2
FROM TableA
JOIN TableB ON TableA.Column3 = TableB.Column3
JOIN TableC ON TableA.Column4 = TableC.Column4;