-- Databricks notebook source
-- Create table COMPANY2 for practice
CREATE TABLE COMPANY2(
EMPLOYEE_ID INT,
EMPLOYEE_NAME VARCHAR(10),
DEPARTMENT_NAME VARCHAR(10),
SALARY INT);

-- COMMAND ----------

INSERT INTO COMPANY2 VALUES(1,'RAM','HR',10000);
INSERT INTO COMPANY2 VALUES(2,'AMRIT','MRKT',20000);
INSERT INTO COMPANY2 VALUES(3,'RAVI','HR',30000);
INSERT INTO COMPANY2 VALUES(4,'NITIN','MRKT',40000);
INSERT INTO COMPANY2 VALUES(5,'VARUN','IT',50000);
INSERT INTO COMPANY2 VALUES(6,'ASHA','HR',40000);
INSERT INTO COMPANY2 VALUES(7,'SHINDE','HR',50000);
INSERT INTO COMPANY2 VALUES(8,'ARJUN','IT',70000);

INSERT INTO COMPANY2 VALUES(1,'MAYUR','IT',50000);
INSERT INTO COMPANY2 VALUES(2,'SHINDE','MRKT',30000);
INSERT INTO COMPANY2 VALUES(3,'MANU','HR',40000);
INSERT INTO COMPANY2 VALUES(4,'ASHU','MRKT',50000);

-- COMMAND ----------



-- COMMAND ----------

SELECT * FROM COMPANY2;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--Question -1 - Find 2nd Highest Salary usig SQL?

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####-- 1st method to find 2nd higest salary

-- COMMAND ----------

select max(salary) from COMPANY where salary not in (select max(salary) from COMPANY)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####-- 2nd method to find 2nd higest salary with using cte

-- COMMAND ----------

with cte as
(
  select row_number() over (order by salary desc) as rank, EMPLOYEE_NAME, SALARY
  from COMPANY
)
select salary from cte where rank = 2;

--OR
--with cte as
--(
--  select salary, row_number() over (order by salary desc) as rank
--  from COMPANY
--)
--select salary from cte where rank = 2;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 3rd Method using Top  

-- COMMAND ----------

with cte as
(
  select top 2 * from COMPANY order by salary desc
)
select top 1 salary from cte order by salary asc;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### -- To find fifth higest salary

-- COMMAND ----------

with cte as
(
  select row_number() over (order by salary desc) as rank, EMPLOYEE_NAME, SALARY
  from COMPANY
)
select salary from cte where rank = 5;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question -1 - Find 2nd/ second Highest Salary departmet wise using Pyspark?

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql.functions import rank, dense_rank, desc
-- MAGIC from pyspark.sql.window import Window
-- MAGIC
-- MAGIC # Sample data (replace with your actual DataFrame)
-- MAGIC data = [("IT", 5000),
-- MAGIC         ("IT", 6000),
-- MAGIC         ("HR", 4500),
-- MAGIC         ("HR", 5500),
-- MAGIC         ("Finance", 7000),
-- MAGIC         ("Finance", 8000)]
-- MAGIC
-- MAGIC columns = ["department", "salary"]
-- MAGIC
-- MAGIC # Create DataFrame
-- MAGIC df = spark.createDataFrame(data, columns)
-- MAGIC
-- MAGIC # Define Window specification
-- MAGIC window_spec = Window.partitionBy("department").orderBy(desc("salary"))
-- MAGIC
-- MAGIC # Add a rank column based on the salary within each department
-- MAGIC df = df.withColumn("salary_rank", rank().over(window_spec))
-- MAGIC
-- MAGIC # Filter for the second-highest salary in each department
-- MAGIC result_df = df.filter(df.salary_rank == 2)
-- MAGIC
-- MAGIC # Select relevant columns for the final result
-- MAGIC result_df.select("department", "salary").show()
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### --Question 2- Find Department wise Highest Salary?

-- COMMAND ----------


--Note- here in company table, we have emp_id 1,2,3 are having multiple count
select EMPLOYEE_ID, max(salary) from COMPANY group by(EMPLOYEE_ID)
select EMPLOYEE_ID, MIN(salary) from COMPANY group by(EMPLOYEE_ID)
select EMPLOYEE_ID, AVG(salary) from COMPANY group by(EMPLOYEE_ID)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 2- Write a program in sql to find the employees whose salary is more than their manager salary department wise?

-- COMMAND ----------

-- Create the employees table
CREATE TABLE employees1 (
    employee_id INT,
    employee_name VARCHAR(50),
    salary INT,
    manager_id INT,
    department VARCHAR(50)
);

-- Insert sample data
INSERT INTO employees1 VALUES (1, 'John', 60000, NULL, 'IT');
INSERT INTO employees1 VALUES (2, 'Jane', 55000, 1, 'IT');
INSERT INTO employees1 VALUES (3, 'Bob', 70000, NULL, 'HR');
INSERT INTO employees1 VALUES (4, 'Alice', 65000, 3, 'HR');
INSERT INTO employees1 VALUES (5, 'Charlie', 80000, 3, 'Finance');
INSERT INTO employees1 VALUES (6, 'David', 75000, 5, 'Finance');


-- COMMAND ----------

-- Query to find employees whose salary is more than their manager's salary
SELECT 
    e.employee_id,
    e.employee_name,
    e.salary AS employee_salary,
    m.salary AS manager_salary,
    e.department
FROM 
    employees1 e
JOIN 
    employees1 m ON e.manager_id = m.employee_id
WHERE 
    e.salary > m.salary;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 2- Write a program using Pyspark to find the employees whose salary is more than their manager salary department wise?

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql.window import Window
-- MAGIC from pyspark.sql.functions import lag
-- MAGIC
-- MAGIC # Sample data (replace with your actual DataFrame)
-- MAGIC data = [
-- MAGIC     (1, 'John', 60000, None, 'IT'),
-- MAGIC     (2, 'Jane', 55000, 1, 'IT'),
-- MAGIC     (3, 'Bob', 70000, None, 'HR'),
-- MAGIC     (4, 'Alice', 65000, 3, 'HR'),
-- MAGIC     (5, 'Charlie', 80000, 3, 'Finance'),
-- MAGIC     (6, 'David', 75000, 5, 'Finance')
-- MAGIC ]
-- MAGIC
-- MAGIC columns = ["employee_id", "employee_name", "salary", "manager_id", "department"]
-- MAGIC
-- MAGIC # Create DataFrame
-- MAGIC df = spark.createDataFrame(data, columns)
-- MAGIC
-- MAGIC # Define a Window specification to partition by department
-- MAGIC window_spec = Window().partitionBy("department").orderBy("employee_id")
-- MAGIC
-- MAGIC # Add a column for the manager's salary using lag function
-- MAGIC df = df.withColumn("manager_salary", lag("salary").over(window_spec))
-- MAGIC
-- MAGIC # Filter for employees whose salary is more than their manager's salary
-- MAGIC result_df = df.filter(df.salary > df.manager_salary)
-- MAGIC
-- MAGIC # Select relevant columns for the final result
-- MAGIC result_df.select("employee_id", "employee_name", "salary", "manager_salary", "department").show()
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### --Question 3 - Find Duplicate Records?

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### -- Method 1- To find all the records with duplicate and single records with count value

-- COMMAND ----------

--select * from company

select employee_name, count(EMPLOYEE_NAME) from company group by employee_name


-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--Method 2 - Use count >1 to segregate the duplicate records

-- COMMAND ----------


select employee_name, count(employee_name) from company group by(EMPLOYEE_NAME) having count(EMPLOYEE_NAME)>1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Method 3--Find duplicate with cte, showing proper column name

-- COMMAND ----------


with cte 
as (
  select employee_name, count(employee_name) from company group by(EMPLOYEE_NAME) having count(EMPLOYEE_NAME)>1
)
select employee_name from cte

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####-- Question 4- Find Even or Odd Number?

-- COMMAND ----------


select CASE WHEN EMPLOYEE_ID%2=1 then 'Odd' else 'Even' END as Result from company;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC n = 5
-- MAGIC for i in lst:
-- MAGIC     if i % 2 == 0:
-- MAGIC         return True
-- MAGIC     else:
-- MAGIC         return False
-- MAGIC

-- COMMAND ----------

select EMPLOYEE_ID, case when employee_id%2=1 then 'Odd' else 'Even' end as Result from company order by(EMPLOYEE_ID)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--Question 5- Concat Two Columns

-- COMMAND ----------


select concat(employee_name, '(',substr(department_name, 1,2), ')') as Result from company;
--here 1,2 is starting position and how many string you want to display and () is for open, close bracket

-- COMMAND ----------

--complete query
select EMPLOYEE_NAME,DEPARTMENT_NAME, concat(employee_name, '(',substr(department_name, 1,2), ')') as Result from company2;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### --Question 6 - Find Pattern Matching, Find employee name whose name contain N letter in last?     

-- COMMAND ----------

select * from company2 where EMPLOYEE_NAME like '%N'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--Find the employee name whose name contain N letter in between anywhere in the name?

-- COMMAND ----------

-- lower() function is to lower the string
select * from company2 where lower(EMPLOYEE_NAME) like '%a%'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--Find the employee name whose name start with N letter?

-- COMMAND ----------

-- lower() function is to lower the string
select * from company2 where lower(EMPLOYEE_NAME) like 'a%'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--Find the employee name whose name start with A letter and department name start with I ?

-- COMMAND ----------

-- lower() function is to lower the string
select * from company2 where lower(EMPLOYEE_NAME) like 'a%' and lower(DEPARTMENT_NAME) like 'i%'


-- COMMAND ----------

create table Student1
(
id int, 
student string
);
insert into Student1 values(1, 'Aman'), (2, 'Baman'), (3, 'Chaman'), (4, 'Daman'), ((5, 'Eman'))

-- COMMAND ----------

select * from Student1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--Question 7 - Swap Consecutive Rows 
-- MAGIC --Want to swap two rows and make odd rows to even and even rows to odd?

-- COMMAND ----------

--logic = even = even-1 for ex - 2-1 =1 which is odd
--        odd = odd+1 1+1 = 2 which is even
-- logic SS is in word doc

SELECT 
  CASE 
    WHEN id % 2 = 1 THEN (id + 1)
    WHEN id % 2 = 0 THEN (id - 1)
  END AS id,
  student
FROM Student1
ORDER BY id;

--here we have not used any pre-defined function or windows functions

-- COMMAND ----------

SELECT 
  CASE 
    WHEN id % 2 = 1 and id!= (select max(id) from Student1)THEN (id + 1) 
    WHEN id % 2 = 0 THEN (id - 1)
  END AS id,
  student
FROM Student1
ORDER BY id;

-- COMMAND ----------

-- by using window function
with cte as (
  select student, case when id%2=1 then id+1 when id%2=0 then id-1 end as new_id from Student1
)
select row_number() over(order by new_id) as ID, student from cte

-- COMMAND ----------

create table if not exists TableA1
(
  id int, 
  name string
);
insert into TableA1 values(1,'Gaurav'), (2, 'Kurhekar')

-- COMMAND ----------

create table if not exists TableB1
(
  id int, 
  name string
);
insert into TableB1 values(1,'Gaurav'), (2, 'Kurhekar'), (3, 'Vaidehi')

-- COMMAND ----------

select * from TableB1


-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####-- Quetion 9- Find records which are present in table B but not in table A all question solve without using joins?
-- MAGIC --**except work as left anti join**, it combine two select statement and return rows from only first select statement

-- COMMAND ----------

select id, name from TableB
except
select id, name from TableA


-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--2- Find the records which are common in both the tables?
-- MAGIC --**intersect used as inner join**- used to combine two select statement and return rows which are common 

-- COMMAND ----------

select id, name from TableA
intersect
select id, name from TableB


-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--3- Find out all the records from both the tables?
-- MAGIC --**union** combine result set of two or more statement

-- COMMAND ----------

select id, name from TableA
union
select id, name from TableB


-- COMMAND ----------

drop table if exists TableB1

-- COMMAND ----------

create table if not exists TableC
(
  id int, 
  name string
);
insert into TableC values(1,'Gaurav'), (2, 'Kurhekar'), (3, 'Vaidehi')

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--Question 10 - Print numbers from 1 to 50 any series?
-- MAGIC -- in python or any other language, we can use loop, in sql, will use same loop concept using cte

-- COMMAND ----------

-- MAGIC %python
-- MAGIC i = 1
-- MAGIC while i<10:
-- MAGIC     print(i)
-- MAGIC     i+=1

-- COMMAND ----------

-- MAGIC %python
-- MAGIC for i in range(2, 50, 10):
-- MAGIC     print(i)

-- COMMAND ----------

WITH RECURSIVE cte AS (
  SELECT 1 AS number
  UNION ALL
  SELECT number + 1 FROM cte WHERE number < 50
)
SELECT number FROM cte;

-- this logic called recursive cte as we are using cte inside cte

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### -- Print 1 to 50 Even number

-- COMMAND ----------

WITH RECURSIVE even_numbers_cte AS (
  SELECT 0 AS number
  UNION ALL
  SELECT number + 2 FROM even_numbers_cte WHERE number < 50
)
SELECT number FROM even_numbers_cte;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####-- Print 1 to 50 odd number?

-- COMMAND ----------

with RECURSIVE cte
as 
(
  select 1 as ID
  union all
  select id+2 from cte
  where id<50
)
select * from cte



-- COMMAND ----------

-- Table created for self join
CREATE TABLE Employee2 (
    ID INT NOT NULL,
    Name VARCHAR(255),
    Salary FLOAT,
    ManagerID INT
);

INSERT INTO Employee2 (ID, Name, Salary, ManagerID)
VALUES
    (1, 'John Doe', 60000, NULL),
    (2, 'Jane Smith', 55000, 1),
    (3, 'Bob Johnson', 50000, 1),
    (4, 'Alice Brown', 70000, 2),
    (5, 'Charlie Davis', 65000, 2),
    (6, 'Eva White', 48000, 3),
    (7, 'David Lee', 52000, 3);

-- COMMAND ----------

select * from Employee2


-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####--Question 11 - self join - Write a sql query to find out employee who earns more than their managers?

-- COMMAND ----------


select E1.ID, E1.Name from Employee2 as E1
join
Employee2 as E2
on
E1.ManagerID = E2.ID
where E1.Salary>E2.Salary


-- COMMAND ----------

CREATE TABLE Student2 (
    Row INT not null,
    Name VARCHAR(255),
    Marks INT,
    Year INT
);

INSERT INTO Student2 (Row, Name, Marks, Year)
VALUES
    (1, 'John Doe', 85, 2023),
    (2, 'Jane Smith', 90, 2023),
    (3, 'Bob Johnson', 75, 2023),
    (4, 'Alice Brown', 80, 2023),
    (5, 'Charlie Davis', 95, 2023),
    (6, 'Eva White', 78, 2023),
    (7, 'David Lee', 88, 2023),
    (8, 'John Doe', 82, 2022),
    (9, 'Jane Smith', 88, 2022),
    (10, 'Bob Johnson', 70, 2022),
    (11, 'Alice Brown', 75, 2022),
    (12, 'Charlie Davis', 92, 2022),
    (13, 'Eva White', 76, 2022),
    (14, 'David Lee', 85, 2022);


-- COMMAND ----------

select * from Student2


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###### the LAG function is used to access data from a previous row in a result set without using a self-join. 
-- MAGIC It is particularly useful for performing calculations that involve comparing current row values with values from a preceding row. 
-- MAGIC The LAG function is commonly used with the OVER clause to define the window of rows for the calculation.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 12- Write sql query to display name, marks, previous marks for those students whose marks are greater than or equal to previous year marks?
-- MAGIC Lag Function Based Question - 
-- MAGIC

-- COMMAND ----------

with cte as (
  select Name, Marks, Year, lag(Marks) over (partition by Name order by Year) as Previous_Marks from Student2
)
select Name, Marks, Year from cte where Marks > Previous_Marks

-- COMMAND ----------

with cte as (
  select Name, Marks, Year, lag(Marks) over (partition by Name order by Year) as Previous_Marks from Student2
), cte_a
as (
  select Name, Marks, Year, row_number() over (partition by Name order by Marks Year desc) as Year_number from cte where Marks > Previous_Marks
)
select Name, Marks, Year from cte_a

-- COMMAND ----------

CREATE TABLE TableA6 (
    id INT
);

-- Insert values into TableA5
INSERT INTO TableA6 VALUES (1),(2),(3),(5),(6),(10),(11),(12),(13),(14),(18);

-- Select all records from TableA4 (assuming you meant TableA5)
SELECT * FROM TableA6;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 13- We have id from 1 to 18 and some id's are missing, find the Missing ID's 
-- MAGIC we can find it by Recursive CTE, union all and except function

-- COMMAND ----------

--Logic- step1- give the range to id column - 
-- have solved this question in SSMS

with cte as (
  select 1 as ID_new
  union all
  select ID_new + 1 from cte
  where ID_new<18
)
select ID_new from cte
except
select id from TableA6        

-- OR

--  WITH AllIDs AS (
--     SELECT 1 AS ID
--   UNION ALL
--  SELECT ID + 1
--    FROM AllIDs
--  WHERE ID < 18
 -- )
--  SELECT ID
--  FROM AllIDs
--  WHERE ID NOT IN (SELECT ID FROM TableA6);

--SELECT ID
--FROM AllIDs
--WHERE ID NOT IN (SELECT ID FROM TableA6);

-- COMMAND ----------

create table TableC1
(
  country varchar(255)
);
insert into TableC1 values ('India'),('Newziland'),('China'),('Shrilanka');
select * from TableC1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 14- Find out all possible pairs
-- MAGIC * we can solve this by using cross join
-- MAGIC --question is in word file

-- COMMAND ----------

-- Method 1 
SELECT t1.country AS Pair1, t2.country AS Pair2
FROM TableC1 t1
CROSS JOIN TableC1 t2
WHERE t1.country <> t2.country;

-- COMMAND ----------

--Method 2 
select  t1.country + ' - ' +  t2.country as country_pair
from TableC1 t1
cross join TableC1 t2
where t1.country<> t2.country;


-- COMMAND ----------

with cte as (
  select country, row_number() over(order by Country) as id from TableC1
)
select concat(c1.country, '-', c2.country) as Country_pair 
from cte c1 
inner join 
cte c2
on c1.id < c2.id

-- COMMAND ----------

-- if you want to pair same same contry then use <=
with cte as (
  select country, row_number() over(order by Country) as id from TableC1
)
select concat(c1.country, '-', c2.country) as Country_pair 
from cte c1 
inner join 
cte c2
on c1.id <= c2.id

-- COMMAND ----------

CREATE TABLE Table_swap (
  ID_A INT,
  ID_B INT
);

-- Insert values into TableD
INSERT INTO Table_swap (ID_A, ID_B) VALUES (1, 101), (2, 102), (3, 103), (4, 104);


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 15- Swap columns
-- MAGIC --question is in word file

-- COMMAND ----------


UPDATE Table_swap3
SET ID_A = ID_B,
    ID_B = ID_A;

select * from Table_swap;

-- COMMAND ----------

CREATE TABLE TableA8 (
  name VARCHAR(50),
  id INT
);

-- INSERT VALUES
INSERT INTO TableA8 (name, id) VALUES ('X', 3), ('X', 4), ('X', 5), ('y', 2), ('y', 3);

-- SELECT TO VIEW INSERTED VALUES
SELECT * FROM TableA8;


-- COMMAND ----------

CREATE TABLE TableB9 (
  name VARCHAR(50),
  id INT
);

-- INSERT VALUES
INSERT INTO TableB9 (name, id) VALUES ('X', 1), ('X', 2), ('y', 1);

-- SELECT TO VIEW INSERTED VALUES
SELECT * FROM TableB9;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 16- join table A and Table B and get desire output?
-- MAGIC -- table in word file

-- COMMAND ----------

with cte_a as (
  select name, id, row_number() over(partition by name order by id) as ID_A from TableA8
)
,cte_b as (
  select name, id, row_number() over(partition by name order by id) as ID_B from TableB9
)
select a.name, a.id from cte_a inner join cte_b on a.id = b.id and a.name = b.name

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 17- Print Prime Numbers in range?

-- COMMAND ----------

WITH RECURSIVE CTE AS (
  SELECT 2 AS Number
  UNION
  SELECT Number + 1 FROM CTE WHERE Number < 100
)

SELECT DISTINCT n1.Number AS PrimeNumber
FROM CTE n1
LEFT JOIN CTE n2 
ON n1.Number > 1 AND n1.Number > n2.Number AND n1.Number % n2.Number = 0
WHERE n2.Number IS NULL;

-- COMMAND ----------

-- Create the table
CREATE TABLE Student5 (
    ID INT NOT NULL,
    Name VARCHAR(255),
    Department VARCHAR(50),
    Marks INT
);

-- Insert 6 rows of data
INSERT INTO Student5 (ID, Name, Department, Marks)
VALUES
    (1, 'John Doe', 'Mathematics', 85),
    (2, 'Jane Smith', 'Physics', 78),
    (3, 'Bob Johnson', 'Mathematics', 92),
    (4, 'Alice Brown', 'Physics', 75),
    (5, 'Charlie Davis', 'Computer Science', 88),
    (6, 'Eva White', 'Mathematics', 65);

-- Display the data
SELECT * FROM Student5;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####Question 18- Write sql query to print records based on total marks in each departments in desending orders, print name first who has higest marks dept wise? 

-- COMMAND ----------

--Method 1 

SELECT department, name, SUM(marks) AS total_marks
FROM Student5
GROUP BY department, name
ORDER BY department, total_marks DESC;

-- COMMAND ----------

--Method 2 by using CTE
with cte as (
  select Department, sum(Marks) as total_marks from Student5 group by Department
)
select Name, s.Department, total_marks from cte c inner join Student s on c.Department = s.Department order by c.total_marks desc


-- COMMAND ----------

CREATE TABLE Student8 (
    ID INT NOT NULL,
    Name VARCHAR(255)
);

INSERT INTO Student8 VALUES (1, 'Gaurav'), (2, 'Vaidu'), (3, 'Monu'), (4, 'Vaidehi');

SELECT * FROM Student8;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####Question 19 - Find those records whose first name start from consonent and end with vowels?
-- MAGIC Regular Expression Based
-- MAGIC

-- COMMAND ----------

SELECT *
FROM Student8
WHERE Name LIKE '[^aeiouAEIOU]%[aeiouAEIOU]'

--^ means all the letters except aeiouAEIOU

-- COMMAND ----------

SELECT *
FROM Student8
WHERE LOWER(Name) LIKE '[bcdfghjklmnpqrstvwxyz]%[aeiou]'
   OR LOWER(Name) LIKE '[bcdfghjklmnpqrstvwxyz]%[aeiou][^aeiou]%';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 20 - How to create table from existing table, we just require schema of existing table and not the data?

-- COMMAND ----------

 CREATE TABLE new_table_name AS
SELECT *
FROM existing_table_name
WHERE 1=0;

-- COMMAND ----------

CREATE TABLE Employee7 (
    id INT NOT NULL,
    name VARCHAR(255),
    salary FLOAT
);

-- Insert 12 rows of data with some duplicates
INSERT INTO Employee7 (id, name, salary)
VALUES
    (1, 'John Doe', 60000.00),
    (2, 'Jane Smith', 55000.00),
    (3, 'Bob Johnson', 50000.00),
    (4, 'Alice Brown', 70000.00),
    (5, 'Charlie Davis', 65000.00),
    (6, 'Eva White', 48000.00),
    (7, 'David Lee', 52000.00),
    (8, 'John Doe', 60000.00),  -- Duplicate
    (9, 'Jane Smith', 55000.00),  -- Duplicate
    (10, 'Bob Johnson', 50000.00),  -- Duplicate
    (11, 'Alice Brown', 70000.00),  -- Duplicate
    (12, 'Charlie Davis', 65000.00);  -- Duplicate

-- Display the data
SELECT * FROM Employee7;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 21 - Delete Duplicates Records? 

-- COMMAND ----------

with cte as (
  select id, name, salary, row_number() over (partition by id, name, salary order by salary) as Duplicate from Employee7
)
select * from cte where Duplicate=1

-- COMMAND ----------

CREATE TABLE table_a1 (
    id_1 INT
);

-- Insert values
INSERT INTO table_a1 VALUES (1), (2), (3), (NULL), (NULL);

-- Select to display the data
SELECT * FROM table_a1;

-- COMMAND ----------

drop table if exists table_b1

-- COMMAND ----------

CREATE TABLE table_b1 (
    id_2 INT
);

-- Insert values
INSERT INTO table_b1 VALUES (1), (2),(NULL);

-- Select to display the data
SELECT * FROM table_b1;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####Question 23 - Null Safe Joins? 

-- COMMAND ----------

select * from table_a1 a
inner join
table_b1 b
on a.id_1 = b.id_2;

-- COMMAND ----------

-- above query not print null so we can write like
select * from table_a1 a
inner join
table_b1 b
on a.id_1 = b.id_2 or (a.id_1 is null and b.id_2 is null);

-- COMMAND ----------

create table Student11
(id int, name varchar(30));
insert into Student11 values(1,'ABC'),(2,'ABC_D'),(3,'A_BCD'),(4,'A_BC_D')
select * from Student11;

-- COMMAND ----------

drop table if exists Student11

-- COMMAND ----------

CREATE TABLE Student11 (
    id INT,
    name VARCHAR(30)
);

-- Insert values
INSERT INTO Student11 (id, name) VALUES (1, 'ABC'), (2, 'ABC_D'), (3, 'A_BCD'), (4, 'A_BC_D');

-- Select to display the data
SELECT * FROM Student11;

-- COMMAND ----------

select * from Student11 where name like 'A[_]%'

-- COMMAND ----------

CREATE TABLE Purchase (
    user_id INT,
    product_id INT,
    purchase_date DATE
);

-- Insert values
INSERT INTO Purchase (user_id, product_id, purchase_date)
VALUES
    (1, 101, '2023-01-01'),
    (1, 102, '2023-01-02'),
    (2, 101, '2023-01-03'),
    (2, 103, '2023-01-04'),
    (3, 102, '2023-01-05'),
    (3, 104, '2023-01-06'),
    (4, 101, '2023-01-07'),
    (4, 105, '2023-01-08'),
    (5, 102, '2023-01-09'),
    (5, 106, '2023-01-10');

-- COMMAND ----------

select * from Purchase;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 27- Write a query to find user who purchase different product on different date?

-- COMMAND ----------

SELECT user_id
FROM Purchase
GROUP BY user_id
HAVING COUNT(DISTINCT product_id) > 1 AND COUNT(DISTINCT purchase_date) > 1;

-- COMMAND ----------

with cte as (
select *, dense_rank() over(partition by user_id, product_id order by purchase_date) as R1 from Purchase
)
select user_id from cte group by user_id having max(R1)=1 and count(distinct purchase_date)>1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 28 - How we can calculate factorial of given number for ex - 5 factorial is 5*4*3*2*1 = 120?

-- COMMAND ----------

DECLARE @n INT = 5;
DECLARE @factorial INT = 1;

WHILE @n > 1
BEGIN
    SET @factorial = @factorial * @n;
    SET @n = @n - 1;
END

SELECT @factorial AS 'Factorial is';

-- COMMAND ----------

with cte as (
  select 5 as n, 1 as f
  union all
  select n-1, f*n from cte where n>1
) select * from cte

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 29- We have 2 column here, generate debit when it debited, generate credit when it credited?
-- MAGIC

-- COMMAND ----------

-- Create the transactions table
CREATE TABLE transactions (
    ename VARCHAR(255),
    amount INT
);

-- Insert sample data into the table
INSERT INTO transactions (ename, amount)
VALUES 
    ('Alice', 100),
    ('Bob', -50),
    ('Charlie', 200),
    ('David', -75),
    ('Eva', 150);
select * from transactions;

-- COMMAND ----------

-- Method 1 - 
SELECT 
    ename, 
    amount, 
    CASE
        WHEN amount > 0 THEN 'debited'
        WHEN amount < 0 THEN 'credited'
        ELSE 'remain_same'
    END AS transaction_type
FROM 
    transactions;

-- COMMAND ----------

	-- Method 2
  SELECT ename,
       amount,
       CASE WHEN amount > 0 THEN amount ELSE 0 END AS debit,
       CASE WHEN amount < 0 THEN -amount ELSE 0 END AS credit
FROM transactions;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Question 30 - Update transaction_type column using update statement?

-- COMMAND ----------

CREATE TABLE transactions1 (
    id INT,
    amount INT,
    transaction_type VARCHAR(10)
);

-- Insert 8 rows of data into the 'transactions' table
INSERT INTO transactions1 (id, amount)
VALUES
    (1, 100),
    (2, -50),
    (3, 200),
    (4, -75),
    (5, 0),
    (6, 150),
    (7, -30),
    (8, 0);
select * from transactions1;

-- COMMAND ----------

UPDATE transactions1
SET transaction_type = CASE
                        WHEN amount > 0 THEN 'Credit'
                        WHEN amount < 0 THEN 'Debit'
                        ELSE 'No Transaction'
                    END;